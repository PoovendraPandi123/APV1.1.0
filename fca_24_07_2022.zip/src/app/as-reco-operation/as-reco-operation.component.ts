import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ChartType} from 'chart.js';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/as.auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-as-reco-operation',
  templateUrl: './as-reco-operation.component.html',
  styleUrls: ['./as-reco-operation.component.css']
})
export class AsRecoOperationComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public barChartLabels = [] as any;
  public barChartData: any;
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Difference',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": false
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'National Account Code',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": false
        }
      }]
    },
    title : {
      display : true,
      text : "Top 10 Customers with Max Difference",
      fontSize : 16,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLegend: any;
  public barColorOptions: any;
  public barChartType: ChartType = 'bar';
  public pieChartData: any;
  public pieChartLabels = [] as any;
  public pieChartOptions: any;
  public pieChartLegend: any;
  public pieColorOptions: any;
  public pieChartType: ChartType = 'doughnut';
  public userModelList: any;
  public userId: any;
  public tenantId: any;
  public groupId: any;
  public entityId: any;
  public mProcessingLayerId: any;
  public mProcessingSubLayerId: any;
  public processingLayerIdsUser: any;
  public displayNAD:boolean = false;
  public displayFilterNAD:boolean = false;
  public displayNadGrid:boolean = false;
  public displayTanSearchDetails: boolean = false;
  public pagination : boolean = false;
  public paginationSize : Number = 0;
  public externalRowData: any;
  public externalColumnDefs: any;
  public internalRowData: any;
  public internalColumnDefs: any;
  public externalGridApi: any;
  public externalGridColumnApi: any;
  public internalGridApi: any;
  public internalGridColumnApi: any;
  public formAsTanGridApi: any;
  public formAsTanGridColumnApi: any;
  public erpTanGridApi: any;
  public erpTanGridColumnApi: any;
  public displayTanDetails: boolean = false;
  public displayTanGrid: boolean = false;
  public selectedExternalRowData: any;
  public SelectedinternalRowData: any;
  public totalERPValue: any;
  public totalASValue: any;
  public totalOverallDifferenceValue: any;
  public missingTANASValue: any;
  public displayPieChart: boolean = false;
  public erpTotal:any;
  public asTotal:any;
  public difference:any;
  public nadList: any;
  public selectNad: any;
  public asTanTotal: any;
  public erpTanTotal: any;
  public tanDifference: any;
  public enteredNAC:any;
  public selectedTan: any;
  public erpSearchTanTotal: any;
  public asSearchTanTotal: any;
  public tanSearchDifference: any;
  public searchExternalRowData: any;
  public searchInternalRowData: any;
  public displayTanSearchGrid: boolean = false;
  public enteredTAN: any;
  public asSearchTanGridApi: any;
  public asSearchTanGridColumnApi: any;
  public erpSearchTanGridApi: any;
  public erpSearchTanGridColumnApi: any;
  public fromDate: any;
  public toDate: any;
  public displayKpiCards: boolean = false;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.pagination = true;
    this.paginationSize = 10;
    // this.getNadCode();
    this.selectNad = {
      "nad_code": "0"
    };
    this.totalERPValue = "Loading...";
    this.totalASValue = "Loading...";
    this.totalOverallDifferenceValue = "Loading...";
    this.missingTANASValue = "Loading...";
    this.fromDate = "Empty";
    this.toDate = "Empty";
    // this.displayKPI();
  }

  searchClick()
  {
    if (this.fromDate === "Empty" || this.toDate === "Empty")
    {
      alert("Kindly choose From and To Date!!!");
    }
    else
    {
      this.displayKpiCards = true;
      this.displayFilterNAD = true;
      this.displayTanSearchDetails = true;
      this.displayKPI();
    }
  }


  displayKPI()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "fromDate" : this.fromDate,
      "toDate" : this.toDate
    }

    this.obj_auth_service.getKPIFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("KPI Response: ", response_data);
        if(response_data["Status"] === "Success")
        {

          if (response_data["data"]["kpi_erp"].split(" ")[1] == "0.00" && response_data["data"]["kpi_as"].split(" ")[1] == "0.00" && response_data["data"]["kpi_missing_tan"].split(" ")[1] == "0.00" && response_data["data"]["erp_difference_as"].split(" ")[1] == "0.00")
          {
            this.displayFilterNAD = false;
            this.displayTanSearchDetails = false;
            this.displayTanDetails = false;
            this.displayNAD = false;
            this.displayNadGrid = false;
            this.displayTanGrid = false;
            this.displayTanSearchGrid = false;
            let kpiERP = '<strong>' + response_data["data"]["kpi_erp"] + '</strong>';
            let kpiAS = '<strong>' + response_data["data"]["kpi_as"] + '</strong>';
            let kpiMissingTAN = '<strong>' + response_data["data"]["kpi_missing_tan"] + '<strong>';
            let erpDiffas = '<strong>' + response_data["data"]["erp_difference_as"] + '</strong>';
            this.totalERPValue = kpiERP;
            this.totalASValue = kpiAS;
            this.missingTANASValue = kpiMissingTAN;
            this.totalOverallDifferenceValue = erpDiffas;
          }
          else
          {
            let kpiERP = '<strong>' + response_data["data"]["kpi_erp"] + '</strong>';
            let kpiAS = '<strong>' + response_data["data"]["kpi_as"] + '</strong>';
            let kpiMissingTAN = '<strong>' + response_data["data"]["kpi_missing_tan"] + '<strong>';
            let erpDiffas = '<strong>' + response_data["data"]["erp_difference_as"] + '</strong>';
            this.totalERPValue = kpiERP;
            this.totalASValue = kpiAS;
            this.missingTANASValue = kpiMissingTAN;
            this.totalOverallDifferenceValue = erpDiffas;
            this.displayCustomerDifference();
          }
        }
        this.ngxService.stop();
      }
    )

  }

  displayCustomerDifference(){
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "fromDate" : this.fromDate,
      "toDate" : this.toDate
    }

    this.obj_auth_service.getCustomerDifferenceFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        console.log("Customer Response: ", response_data);
        this.displayNAD = true;
        this.barChartLabels = response_data["label"];
        this.barChartData = [
          {
            data : response_data["data"]
          }
        ];
        this.barColorOptions = [
          {
            backgroundColor: ['#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf', '#547caf']
          }
        ];

        this.ngxService.stop();
      }
      
    )

  }

  displayPieChartTAN(nationalAccountCode)
  {
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "customerNAC" : nationalAccountCode,
      "fromDate" : this.fromDate,
      "toDate" : this.toDate
    }

    this.obj_auth_service.getTanFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        console.log("Bar Chart Click Response: ", response_data);
        this.displayPieChart = true;
        this.displayFilterNAD = true;
        this.pieChartLabels = response_data["label"];
        this.pieChartData = [
          {
            data : response_data["data"]
          }
        ];
        this.pieChartOptions = {
            scaleShowVerticalLines: false,
            responsive: true,
            title : {
              display : true,
              text : "ERP TAN Numbers Total Value (NAC-" + nationalAccountCode + ")",
              fontSize : 16,
              fontColor : '#004e98',
            },
            legend : {
              position : "right",
              display : true
            }
          };
      }
    )
  }

  onBarChartClick(event: any)
  {
    if (event.active.length > 0) {
      const chart = event.active[0]._chart;
        const activePoints = chart.getElementAtEvent(event.event);
        if ( activePoints.length > 0) 
        {
          // get the internal index of slice in pie chart
          const clickedElementIndex = activePoints[0]._index;
          const label = chart.data.labels[clickedElementIndex];
          // get value by index
          const value = chart.data.datasets[0].data[clickedElementIndex];
          // console.log(clickedElementIndex, label, value);
          console.log(label);

          this.enteredNAC = label;
          this.getSelectedNadCode();
        }
    }
  }

  getNadCode()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId
    }

    this.obj_auth_service.getNadListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        console.log("Nad Code List Response: ", response_data);
        console.log("Nad Data: ", response_data["nad_code_list"]["data"]);
        this.nadList = response_data["nad_code_list"]["data"];
        // console.log(this.nadList);
        this.ngxService.stop();
      }
    )
  }


  getSelectedNadCode()
  {
    this.ngxService.start();
    this.displayTanDetails = false;
    this.displayTanGrid = false;
    this.displayNadGrid = true;
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "nadCode" : this.enteredNAC,
      "fromDate" : this.fromDate,
      "toDate" : this.toDate
    }

    this.obj_auth_service.getNadDataFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        console.log(response_data);

        let externalRecordsAllColumnDefs = response_data["as_records"]["headers"];
        let externalRecordsAllrowData = response_data["as_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["erp_records"]["headers"];
        let internalRecordsAllrowData = response_data["erp_records"]["data"];

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.externalColumnDefs = externalRecordsAllColumnDefs;
        this.externalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = false;
              // item["maxWidth"] = 40;
              // item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.internalColumnDefs = internalRecordsAllColumnDefs;
        this.internalRowData = internalRecordsAllrowData;

        this.erpTotal = '<strong>' + response_data["int_sum"] + '</strong>';
        this.asTotal = '<strong>' + response_data["ext_sum"] + '</strong>';
        this.difference = '<strong>' + response_data["erp_diff_as_nac"] + '</strong>';

        this.displayPieChartTAN(this.enteredNAC);

        this.ngxService.stop();
      }
    )
  }

  onPieChartClick(params)
  {

  }

  onExternalGridReady(params)
  {
    this.externalGridApi = params.api;
    this.externalGridColumnApi = params.columnApi;
  }

  onExternalExportButtonClick(){
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'TanReport_Form26AS_NAC_' + this.enteredNAC + '.csv'
    };
    this.externalGridApi.exportDataAsCsv(params);
  }

  onInternalGridReady(params)
  {
    this.internalGridApi = params.api;
    this.internalGridColumnApi = params.columnApi;
  }

  onInternalExportButtonClick(){
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'TanReport_ERP_TDS_TAN_' + this.selectedTan + '.csv'
    };
    this.internalGridApi.exportDataAsCsv(params);
  }

  onFormAsTanGridReady(params)
  {
    this.formAsTanGridApi = params.api;
    this.formAsTanGridColumnApi = params.columnApi;
  }

  onAsTanExportButtonClick(){
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'TanReport_Form26AS_TAN_' + this.selectedTan + '.csv'
    };
    this.formAsTanGridApi.exportDataAsCsv(params);
  }

  onErpTanGridReady(params)
  {
    this.erpTanGridApi = params.api;
    this.erpTanGridColumnApi = params.columnApi;
  }

  onErpTanExportButtonClick(){
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'TanReport_ERP_TDS_NAC_' + this.enteredNAC + '.csv'
    };
    this.erpTanGridApi.exportDataAsCsv(params);
  }

  onExternalSelectionChanged(params)
  {
    this.selectedExternalRowData = params.api.getSelectedRows();
    console.log(this.selectedExternalRowData);

    if (this.selectedExternalRowData.length == 0)
    {
      this.displayTanGrid = false;
      this.displayTanDetails = false;
      this.displayTanSearchDetails = true;
    }
    else if(this.selectedExternalRowData.length > 0)
    {
      this.displayTanGrid = true;
      this.displayTanDetails = true;
      this.displayTanSearchDetails = true;
    }

    let externalTAN = this.selectedExternalRowData[0]["tan_of_deductor"];
    this.selectedTan = externalTAN;
    console.log(externalTAN);

    this.displayTanDetails = true;
    this.displayTanGrid = true;

    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "tanNumber": externalTAN,
      "fromDate" : this.fromDate,
      "toDate" : this.toDate
    }

    this.obj_auth_service.getIntRecordForTanFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        console.log("TAN Resposne Data, ", response_data);

        let selectedInternalRowData = response_data["int_records"]["data"];
        let selectedTanSum = '<strong>' + response_data["int_tan_sum"] + '</strong>';
        this.SelectedinternalRowData = selectedInternalRowData;
        this.erpTanTotal = selectedTanSum;
        this.asTanTotal = '<strong>' + response_data["ext_tan_sum"] + '</strong>';
        this.tanDifference = '<strong>' + response_data["tan_sum_int_diff_ext"] + '</strong>';
      }
    )
  }

  getSelectedTAN()
  {

    this.displayTanSearchGrid = true;

    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "tanNumber": this.enteredTAN,
      "fromDate" : this.fromDate,
      "toDate" : this.toDate
    }

    this.obj_auth_service.getIntRecordForTanFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        console.log("TAN Resposne Data, ", response_data);

        let searchInternalRowData = response_data["int_records"]["data"];
        let searchIntTanSum = '<strong>' + response_data["int_tan_sum"] + '</strong>';
        let searchExternalRowData = response_data["ext_records"]["data"];
        let searchExtTanSum = '<strong>' + response_data["ext_tan_sum"] + '</strong>';
        this.searchInternalRowData = searchInternalRowData;
        this.erpSearchTanTotal = searchIntTanSum;
        this.searchExternalRowData = searchExternalRowData;
        this.asSearchTanTotal = searchExtTanSum;
        this.tanSearchDifference = '<strong>' + response_data["tan_sum_int_diff_ext"] + '</strong>';
      }
    )
    
  }

  onFormAsTanSearchGridReady(params)
  {
    this.asSearchTanGridApi = params.api;
    this.asSearchTanGridColumnApi = params.columnApi;
  }

  onErpTanSearchGridReady(params)
  {
    this.erpSearchTanGridApi = params.api;
    this.erpSearchTanGridColumnApi = params.columnApi;
  }

  onAsTanSearchExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'TanReport_Form26AS_TAN_' + this.enteredTAN + '.csv'
    };
    this.asSearchTanGridApi.exportDataAsCsv(params);
  }

  onErpTanSearchExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'TanReport_ERP_TDS_NAC_' + this.enteredTAN + '.csv'
    };
    this.erpSearchTanGridApi.exportDataAsCsv(params);
  }

}