import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/mi.auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-mi-report-explicit',
  templateUrl: './mi-report-explicit.component.html',
  styleUrls: ['./mi-report-explicit.component.css']
})
export class MiReportExplicitComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userModelList: any;
  public userId: any;
  public tenantId: any;
  public groupId: any;
  public entityId: any;
  public mProcessingLayerId: any;
  public mProcessingSubLayerId: any;
  public pagination : boolean = false;
  public paginationSize : Number = 0;
  public externalRowData: any;
  public externalColumnDefs: any;
  public processingLayerIdsUser: any;
  public externalGridApi: any;
  public externalGridColumnApi: any;
  public displayExplicitGrid: boolean = false;
  public insurerType: any;
  public insuranceType: any;
  public fromDate: any;
  public policyType: any;
  public policyList: any;
  public insurerList: any;
  public insuerId: any;
  public policyId: any;
  public insurerName: any;
  public clientId: any;
  public clientList: any;
  public clientType: any;


  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.ngxService.start();
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.pagination = true;
    this.paginationSize = 20;
    this.insuranceType = "Empty";
    this.fromDate = "Empty";
    this.insuerId = 0;
    this.policyId = 0;

    this.insurerType = {
      "m_insurer_id": 0
    }

    this.policyType = {
      "m_policy_type_id": 0
    }

    this.clientId = 0;
    this.clientType = {
      "m_client_details_id" : 0
    }

    this.getInsurerList();
    this.getPolicyTypeList();
    this.ngxService.stop();
  };

  getInsurerList()
  {
    this.ngxService.start();

    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
    }

    this.obj_auth_service.getInsurerListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"]["insurer_list"]["data"];
        this.insurerList = response_data;
        this.ngxService.stop();
      }
    )
  }

  getClientList()
  {
    this.ngxService.start();

    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "mInsurerId" : this.insuerId
    }

    this.obj_auth_service.getClientListFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData["data"]["client_list"]["data"];
        this.clientList = responseData;
        this.ngxService.stop();
      }
    )
  }

  getPolicyTypeList()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
    }

    this.obj_auth_service.getPolicyListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"]["policy_type_list"]["data"];
        this.policyList = response_data;
        this.ngxService.stop();
      }
    )
  }

  searchClick()
  {
    if (this.insuerId === 0)
    {
      alert("Kindly Choose Insurance Company!!!");
    }
    else if (this.clientId === 0)
    {
      alert("Please choose the Client for the Insurance Company Chosen!!!");
    }
    else if(this.policyId === 0)
    {
      alert("Kindly Choose Policy Type!!!");
    }
    else if(this.fromDate === "Empty")
    {
      alert("Kindly Choose the Insurance Month!!!");
    }
    else
    {
      this.getExplicatRecords();
    }
  }

  getExplicatRecords()
  {
    this.ngxService.start();
    this.displayExplicitGrid = true;
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "insurerId": this.insuerId,
      "clientId": this.clientId,
      "policyId": this.policyId,
      "chosenDate": this.fromDate
    }
    this.obj_auth_service.getExceptionDataFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        let externalRecordsAllColumnDefs = response_data["exception"]["headers"];
        let externalRecordsAllrowData = response_data["exception"]["data"];

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = false;
              item["minWidth"] = 100;
              // item["pinned"] = 'left';
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 100;
            }

            // Hiding
            if (item.field === "id")
            {
              item["hide"] = true;
            }

          }
        });

        this.externalColumnDefs = externalRecordsAllColumnDefs;
        this.externalRowData = externalRecordsAllrowData;
        this.ngxService.stop();
      }
    )
  }

  onExplicitGridReady(params)
  {
    this.externalGridApi = params.api;
    this.externalGridColumnApi = params.columnApi;
  }

  onExplicitExportButtonClick()
  {
    const params = {
      columnGroups: true,
      allColumns: true,
      fileName: 'MonthlyExceptions' + "_" + this.insurerName.replaceAll(" ", "_") + "_" + this.fromDate.replace("-", "_") + '.csv'
    };
    this.externalGridApi.exportDataAsCsv(params);
  }

  getInsuerType(m_insurer_id)
  {
    this.insuerId = m_insurer_id;
    if(m_insurer_id == -1)
    {
      this.insurerName = 'ALL'
    }
    else
    {
      this.insurerName = this.getInsurerName(m_insurer_id);
      // console.log(this.insurerName);
    }
    this.getClientList();
  }

  getPolicyType(policy_id)
  {
    this.policyId = policy_id;
  }

  getInsurerName(insurerId)
  {
    // console.log(this.insurerList);
    let insurerList = this.insurerList;

    for(var i=0; i<insurerList.length; i++)
    {
      if (insurerList[i]["m_insurer_id"] == insurerId)
      {
        return insurerList[i]["insurer_name"]
      }
    }

  };

  getClientChange(clientId)
  {
    this.clientId = clientId
  }


}
