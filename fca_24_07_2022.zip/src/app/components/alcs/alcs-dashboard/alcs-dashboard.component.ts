import { Component, OnInit } from '@angular/core';
import { ChartType } from 'chart.js';

@Component({
  selector: 'app-alcs-dashboard',
  templateUrl: './alcs-dashboard.component.html',
  styleUrls: ['./alcs-dashboard.component.css']
})
export class AlcsDashboardComponent implements OnInit {

  constructor() { }

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Transaction Count',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": true
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          // labelString: 'Vendors'
        },
        gridLines : {
          "display": true
        }
      }]
    },
    title : {
      display : true,
      text : "ALCS Letters Count as on Today",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };

  public barChartLabels = ["AXIS", "HDFC", "SBI", "ICICI", "HDFC-NEFT", "ICICI-NEFT"];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [{ data : [850,500,250, 1500, 300, 780], label : "Transaction Count"}];
  public colorOptions = [{backgroundColor: ['#30637F', '#D6B154', '#DDF56A', '#9A7B4F', '#9897A9', '#3DeD97']}]

  public barChartOptions2 = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Transaction Value',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": true
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          // labelString: 'Vendors'
        },
        gridLines : {
          "display": true
        }
      }]
    },
    title : {
      display : true,
      text : "ALCS Letters Value as on Today",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };

  public barChartLabels2 = ["AXIS", "HDFC", "SBI", "ICICI", "HDFC-NEFT", "ICICI-NEFT"];
  public barChartType2: ChartType = 'bar';
  public barChartLegend2 = true;
  public barChartData2 = [{ data : [154010,845741,745842, 845762, 147258, 852369], label : "Transaction Value"}];

  ngOnInit(): void {
  }

}
