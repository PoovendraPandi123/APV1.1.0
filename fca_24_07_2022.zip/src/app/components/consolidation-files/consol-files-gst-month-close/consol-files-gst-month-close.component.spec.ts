import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesGstMonthCloseComponent } from './consol-files-gst-month-close.component';

describe('ConsolFilesGstMonthCloseComponent', () => {
  let component: ConsolFilesGstMonthCloseComponent;
  let fixture: ComponentFixture<ConsolFilesGstMonthCloseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesGstMonthCloseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesGstMonthCloseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
