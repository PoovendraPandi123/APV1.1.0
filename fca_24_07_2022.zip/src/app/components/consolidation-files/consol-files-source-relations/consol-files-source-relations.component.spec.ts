import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesSourceRelationsComponent } from './consol-files-source-relations.component';

describe('ConsolFilesSourceRelationsComponent', () => {
  let component: ConsolFilesSourceRelationsComponent;
  let fixture: ComponentFixture<ConsolFilesSourceRelationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesSourceRelationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesSourceRelationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
