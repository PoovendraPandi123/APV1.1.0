import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrsConsolidationReportComponent } from './brs-consolidation-report.component';

describe('BrsConsolidationReportComponent', () => {
  let component: BrsConsolidationReportComponent;
  let fixture: ComponentFixture<BrsConsolidationReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrsConsolidationReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrsConsolidationReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
