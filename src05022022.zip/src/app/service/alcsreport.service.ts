import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AlcsreportService {

  public alcsPort = "50010";

  constructor() { }

  public getAlcsTypeList() : any {
    return [
      {alcsType: 'axis', alcsName: 'ALCS AXIS RECON'},
      {alcsType: 'icici', alcsName: 'ALCS ICICI RECON'},
      {alcsType: 'sbi', alcsName: 'ALCS SBI RECON'},
      {alcsType: 'hdfc', alcsName: 'ALCS HDFC RECON'},
      {alcsType: 'hdfc-neft', alcsName: 'ALCS HDFC NEFT RECON'}
    ];
  };
}
