export class MIInsurer
{
    public tenantId : any;
    public groupId : any;
    public entityId : any;
    public mProcessingLayerId : any;
    public mProcessingSubLayerId : any;
    public processingLayerId : any;
    public userId : any;
    public userModelList : any
    public pagination : boolean = false;
    public paginationSize : number = 0;
    public insurerRowData : any;
    public insurerColumnDefs : any;
    public clientRowData : any;
    public clientColumnDefs : any;
    public mailRowData : any;
    public mailColumnDefs : any;
    public insurerAddButtonDisabled : boolean = false;
    public insurerEditButtonDisabled : boolean = true;
    public insurerClientDetailsButtonDisabled : boolean = true;
    public clientAddButtonDisabled :  boolean = true;
    public clientEditButtonDisabled :  boolean = true;
    public clientMailIdButtonDisabled : boolean = true;
    public mailIdAddButtonDisabled : boolean = true;
    public mailIdEditButtonDisabled : boolean = true;
    public clientAndMailIdSide : boolean = false;
    public clientDetailsDisplay : boolean = true;
    public mailIdDisplay : boolean = true;
    public insurerGridApi : any;
    public insurerGridColumnApi : any;
    public clientGridApi : any;
    public clientGridColumnApi : any;
    public mailIdGridApi : any;
    public mailIdGridColumnApi : any;
    public insurerNameAdd: string = '';
    public insurerNameEdit: string = '';
    public insurerActiveStatus: string = '';
    public insurerId : any;
    public clientId : any;
    public mailAddressId : any;
    public clientNameAdd : string = '';
    public policyStartDateAdd : any;
    public policyEndDateAdd : any;
    public addressAdd : string = '';
    public gstNumberAdd : string = '';
    public clientNameEdit : string = '';
    public policyStartDateEdit: any;
    public policyEndDateEdit: any;
    public addressEdit: string = '';
    public gstNumberEdit: string = '';
    public clientActiveStatus: string = '';
    public mailAddressAdd: string = '';
    public mailAddressEdit: string = '';
    public mailIdActiveStatus: string = '';

    constructor(){}
}