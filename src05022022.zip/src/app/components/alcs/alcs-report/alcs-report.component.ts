import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { HttpClient  } from '@angular/common/http';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AlcsreportService } from 'src/app/service/alcsreport.service';

@Component({
  selector: 'app-alcs-report',
  templateUrl: './alcs-report.component.html',
  styleUrls: ['./alcs-report.component.css']
})
export class AlcsReportComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public reportDate : any;
  public displayGrid : boolean;
  public pagination : boolean;
  public paginationSize : number;
  public rowData : any;
  public columnDefs : any;
  public alcsType : string;
  public alcsTypeList : any;

  constructor(private alcsReportService : AlcsreportService, private ngxService : NgxUiLoaderService) 
  { 
    this.reportDate = '';
    this.displayGrid = false;
    this.pagination = false;
    this.paginationSize = 0;
    this.rowData = [];
    this.columnDefs = [];
    this.alcsType = '';
    this.alcsTypeList = [];
  }

  public ngOnInit(): void {
    this.pagination = true;
    this.paginationSize = 20;
    this.initAlcsTypeList();
    this.alcsType = '0';
  }

  public initAlcsTypeList() : void {
    this.ngxService.start();
    this.alcsTypeList = this.alcsReportService.getAlcsTypeList();
    this.ngxService.stop();
  }

  public searchClick() : void {
    if (this.alcsType == '0')
    {
      alert("Please Choose ALCS Type!!!");
    }
    else if (this.reportDate == "")
    {
      alert("Please Choose Report Date!!!");
    }
    else
    {
      this.getReportValues();
      this.displayGrid = true;
    }
  }

  public getReportValues() : void {
    this.ngxService.start();
    this.ngxService.stop();
  }

  public onGridReady(event : any) : void {
    
  }

  public onExportButtonClick(): void {
    
  }
}
