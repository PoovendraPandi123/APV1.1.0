import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecoOperationComponent } from './reco-operation.component';

describe('RecoOperationComponent', () => {
  let component: RecoOperationComponent;
  let fixture: ComponentFixture<RecoOperationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecoOperationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecoOperationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
