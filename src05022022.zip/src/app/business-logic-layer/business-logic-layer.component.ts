import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { BusinesslogiclayerService } from '../service/businesslogiclayer.service';
import { HttpClient  } from '@angular/common/http';
declare const $: any;

@Component({
  selector: 'app-business-logic-layer',
  templateUrl: './business-logic-layer.component.html',
  styleUrls: ['./business-logic-layer.component.css']
})
export class BusinessLogicLayerComponent implements OnInit {

  public cardTitle;
  public businesslayerlogicview;
  public processinglayerdata;
  public processinglayerlist;
  public objbusinesslogic;
  public businesslogiclayerdata;
  public businesslogiclayerlist;
  public businesslayermainlist;
  public userdtl;
  public user;
  public doc;
  public newdoc;
  public businessdata;
  public rulecategorylist;
  public ruletypelist;

  constructor(private router: Router,private objservice:BusinesslogiclayerService,public http:HttpClient) { }


  ngOnInit(): void {

    this.userdtl=JSON.parse(localStorage.getItem('useracess'));
    this.user=JSON.parse(localStorage.getItem('Userdtl'));
    console.log("userdtl",this.user);
    this.businesslayerlogicview=false;
    this.businesslogiclayerlist=[];
    this.objbusinesslogic={"processing_layer_id":0,"rule_set_name":"","rule_category_id":0};
    this.newdoc={"rule_name":"","rule_description":"","rule_type_id":0,"sub_sequence":""};
    this.getbusinesslayer();
  }

  getbusinesslayer(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      }
    console.log("inputbusiness",Indata);
    this.objservice.getbusinesslogicFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourcelistresponse---",tempresponsedata)
      this.processinglayerdata=tempresponsedata;
      this.businessdata=this.processinglayerdata.Data[0];
      // this.sourcelist=this.sourcedata.sources_list;
      this.processinglayerlist=this.businessdata.process_lay_def_list;
      this.rulecategorylist=this.businessdata.rule_categories_list;
      this.ruletypelist=this.businessdata.rule_type_list;
         });
  }

  list(){
    this.businesslayerlogicview=true;

  }
  backlist(){
    this.businesslayerlogicview=false;

  }

  addFieldValue(data?) {
    
    this.businesslogiclayerlist.push(this.newdoc);
    let getLength = this.businesslogiclayerlist.length - 1;    
    this.newdoc={"rule_name":"","rule_description":"","rule_type_id":0,"sub_sequence":""};
  }

  deleteFieldValue(index) {
    this.businesslogiclayerlist.splice(index, 1);
    // this.costVendorTypeArray.splice(index, 1);    
  }			
 

  clearbusinesslayerFields(){
    this.newdoc={"rule_name":"","rule_description":"","rule_type_id":0,"sub_sequence":""};
  }

  cancelEdit(){

  }

  savebusinesslayerdetails(){
    
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "processing_layer_id":this.objbusinesslogic.processing_layer_id,
      "rule_set_name":this.objbusinesslogic.rule_set_name,
      "m_rule_categories_id":this.objbusinesslogic.rule_category_id,
      "execution_sequence":this.objbusinesslogic.execution_sequence,
      // "rule_category_name":"",
      "rules_list":this.businesslogiclayerlist
      }
    console.log("inputsavebusiness",Indata);
    this.objservice.postbusinesslogiclayerFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("saveresponse---",tempresponsedata);
    });

  }

  Editbusinesslayerdetail(param){

  }

  
}
