import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolidationFilesLandingPageComponent } from './consolidation-files-landing-page.component';

describe('ConsolidationFilesLandingPageComponent', () => {
  let component: ConsolidationFilesLandingPageComponent;
  let fixture: ComponentFixture<ConsolidationFilesLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolidationFilesLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolidationFilesLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
