import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class BusinesslogiclayerdefinitionService {
  lstReturn: any;
  public  port="50003";
  // public  port1="10002";

  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  
  postbusinesslayerdefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/update_business_layer/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getbusinesslayerFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/bus_lay_process_def/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
  getbusinessrulesetFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/bus_lay_rule_set/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getbusinessrulenameFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/bus_lay_rule_name/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getbusinesslayerdefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/business_layer_definition/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }
}
