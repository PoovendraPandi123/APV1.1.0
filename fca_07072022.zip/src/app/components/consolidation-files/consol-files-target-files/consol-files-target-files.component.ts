import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ConsolFilesTargetFilesService } from 'src/app/service/consol-files-target-files.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ITargetDefinitions } from './consol-files-target-definition.model';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-consol-files-target-files',
  templateUrl: './consol-files-target-files.component.html',
  styleUrls: ['./consol-files-target-files.component.css']
})
export class ConsolFilesTargetFilesComponent implements OnInit {

  @ViewChild('content') content : ElementRef;

  public listButton: boolean = true;
  public createButton: boolean = false;
  public createTargetEnable: boolean = false;
  public listTargetEnable: boolean = false;
  public targetName: string;
  public targetDescription: string;
  public pagination: boolean = false;
  public paginationSize: number;
  public targetRowData: any;
  public targetColumnDefs: any;
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public targetDefRowData: any;
  public targetDefColumnDefs: any;
  public listTargetDefEnable: boolean = false;
  public targetActionType: string;
  public targetClickedData: any;
  public targetNameClicked: string;
  public targetDefButtonVisible: boolean;
  public targetDefinitions: ITargetDefinitions[];
  public isTargetDefinitionsRequired: boolean[];
  public targetDefCreateVisible: boolean;
  public closeResult: any;

  constructor(private targetService: ConsolFilesTargetFilesService, private ngxService: NgxUiLoaderService, private dialog: MatDialog, private modalService: NgbModal) { 
    this.targetName = '';
    this.targetDescription = '';
    this.paginationSize = null;
    this.targetRowData = [];
    this.targetColumnDefs = [];
    this.targetDefRowData = [];
    this.targetDefColumnDefs = [];
    this.targetActionType = '';
    this.targetClickedData = [];
    this.targetNameClicked = '';
    this.targetDefButtonVisible = false;
    this.targetDefinitions = [];
    this.isTargetDefinitionsRequired = [];
    this.targetDefCreateVisible = false;
  }

  public ngOnInit(): void {
    this.pagination = true;
    this.paginationSize = 10;
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.setTargetColumns();
    this.setTargetDefColumns();
    this.setTargetDefColumns();
    this.getTargetList();
    this.targetDefinitions = [
      {
        fieldName: "",
        fieldPosition: null
      }
    ];
    this.isTargetDefinitionsRequired = [true];
  }

  public open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public setTargetColumns() : void {
    this.targetColumnDefs = [
      {
        headerName: 'Action',
        width: 100,
        template:
        `
        <a>
          <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        </a>
        <a style="margin-left:3px;">
          <i class='fas fa-trash-alt' data-action-type="Delete" title="Delete" style="color:red"></i>
        </a>
        <a>
          <i class='fa fa-angle-double-right' data-action-type="target_def" title="Target Definitions" aria-hidden="true"></i>
        </a>
        `
      },
      {headerName: 'Name', field: 'name', sortable: true, filter: true, resizable: true, width: 200},
      {headerName: 'Description', field: 'description', sortable: true, filter: true, resizable: true, width: 400},
    ]
  }

  public setTargetDefColumns() : void {
    this.targetDefColumnDefs = [
      // {
      //   headerName: 'Action',
      //   width: 100,
      //   template:
      //   `
      //   <a>
      //     <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
      //   </a>
      //   `
      // },
      {headerName: 'Name', field: 'field_name', sortable: true, filter: true, resizable: true, width: 300},
      {headerName: 'Sequence', field: 'field_sequence', sortable: true, filter: true, resizable: true, width: 200},
    ]
  }

  public getTargetList() : void {
    this.targetDefinitions = [];
    this.isTargetDefinitionsRequired = [];
    this.addButtonClick();

    this.targetDefButtonVisible = false;
    this.listButton = true;
    this.createButton = false;
    this.createTargetEnable = false;
    this.listTargetEnable = true;
    this.targetDefCreateVisible = false;

    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.targetService.getTragetListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Target List Response ", responseData);
        this.targetRowData = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HanlerErrorResponse(error);
      this.ngxService.stop();
    }

  }

  public getCreateTarget() : void {
    this.listButton = false;
    this.createButton = true;
    this.createTargetEnable = true;
    this.listTargetEnable = false;
    this.listTargetDefEnable = false;

  }

  public getTargetDefinitionsList() : void {
    this.ngxService.start();
    this.targetDefButtonVisible = true;
    this.listTargetDefEnable = true;
    // console.log("Clicked Target Row", this.targetClickedData);
    this.targetNameClicked = this.targetClickedData["name"];

    let prminputs = {
        "tenants_id": this.tenantId,
        "groups_id": this.groupId,
        "entities_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processingLayerId,
        "target_files_id": this.targetClickedData["id"],
        "is_active": "yes",
    }

    this.targetService.getTargetDefinitionListFromServer(prminputs)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Target Definitions List Response ", responseData);
        let targetFileDefinitions = responseData;
        this.targetDefRowData = targetFileDefinitions;
        this.ngxService.stop();
        // window.location.reload();
      },
      error : (error : any) => {
        console.log("Get Target Definition List Error ", error);
        this.ngxService.stop();
      }
    });
    
  }

  public onSaveButtonClick() : void {

    if (this.targetName == "")
    {
      alert("Target Name Should not be Blank!!!");
    }
    else if (this.targetDescription == "")
    {
      alert("Target Description Should not be Blank!!!");
    }
    else if (this.getCheckSpecialCharacters(this.targetName))
    {
      alert("Target Name Should not Contain any Special Characters!!!");
    }
    else
    {
      let targetName = this.targetName;
      let re = / /gi;
      let targetNameReplaced = targetName.replace(re, "_").toUpperCase();

      this.ngxService.start();
      let data = {
          "target_file_definitions": [],
          "tenants_id": this.tenantId,
          "groups_id": this.groupId,
          "entities_id": this.entityId,
          "m_processing_layer_id": this.mProcessingLayerId,
          "m_processing_sub_layer_id": this.mProcessingSubLayerId,
          "processing_layer_id": this.processingLayerId,
          "name": targetNameReplaced,
          "description": this.targetDescription,
          "files_config": null,
          "is_active": true,
          "created_by": this.userId,
          "created_date": "{bk_update}",
          "modified_by": this.userId,
          "modified_date": "{bk_update}"
      }
  
      this.targetService.getCreateTargetToServer(data)
      .subscribe(
        (receivedData : any) => {
          let responseData = receivedData;
          console.log("Get Create Target Response ", responseData);
          if ("id" in responseData)
          {
            alert("Target Created Successfully!!!");
            window.location.reload();
          }
          else
          {
            alert("Error in Creating Target. Please Contact Advents Support!!!");
          };
          this.ngxService.stop();
        },
        (error : any) => {
          let responseError = error;
            this.HanlerErrorResponse(responseError);
            let err = responseError["error"];
            console.log("err", err);
            if ("name" in err)
            {
              alert("Name column Should not be Blank!!!");
            }
            else if ("description" in err)
            {
              alert("Description Column Should not be Blank!!!");
            }
            this.ngxService.stop();
        }
      );

    }
  }

  public getCheckSpecialCharacters(inputText: string) : boolean {
    var format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|.,<>\/?~]/;
    if (format.test(inputText))
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public onClearButtonClick() : void {
    
  }

  public onTargetGridReady(event : any) : void {

  }

  public onTargetRowClicked(e : any) : void {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.targetActionType = actionType;
      this.targetClickedData = data;
      switch (actionType) {
        case 'target_def':
          return this.getTargetDefinitionsList();
        case 'Delete':
          return this.deleteTargetPopup();
      }
    }
  }

  public onTargetDefGridReady(event : any) : void {

  }

  public onTargetDefRowClicked(e : any) : void {

  }

  public getCreateTargetDefinitions() : void {
    this.targetDefCreateVisible = true;
    this.listButton = false;
    this.createButton = true;
    this.createTargetEnable = false;
    this.listTargetEnable = false;
    this.listTargetDefEnable = false;
  }

  public deleteTargetPopup() : void {
    this.targetNameClicked = this.targetClickedData["name"];
    this.open(this.content);
  }

  public deleteTarget() : void {
    this.ngxService.start();

    let data = {
      "id": this.targetClickedData["id"],
      "is_active": 0
    }

    this.targetService.getDeleteTargetToServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        this.getTargetList();
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      let responseError = error;
      this.HanlerErrorResponse(responseError);
      let err = responseError["error"];
      // console.log("Delete Target Error Response ", err);
      this.ngxService.stop();
    }
  }

  public targetDefinitionsSaveClick() : void {

    let requiredTargetDefinitionsList = [];

    for (var i=0; i<this.targetDefinitions.length; i++)
    {
      if (this.isTargetDefinitionsRequired[i])
      {
        requiredTargetDefinitionsList.push(this.targetDefinitions[i]);
      }
    }

    if (requiredTargetDefinitionsList.length == 0)
    {
      alert("Please fill the data and save the records!!!");
    }
    else if (requiredTargetDefinitionsList[0]["fieldName"] == "" || requiredTargetDefinitionsList[0]["fieldPosition"] == null)
    {
      alert("Please fill all the data in the fields and save the records!!!");
    }
    else
    {

      var resultNameValidation = this.getValidateTargetDefinitionName(requiredTargetDefinitionsList);
      var resultNameDuplicateValidation = this.getCheckTargetDefinitionName(requiredTargetDefinitionsList);
      var resultPositionValidation = this.getValidateTargetDefinitionPositions(requiredTargetDefinitionsList);
      var resultEmptyPositionValidation = this.getValidateNullTargetDefinitionPosition(requiredTargetDefinitionsList);

      if (resultNameValidation)
      {
        alert("Kindly Check the Target Definition Name. It is Empty in the added rows. Source Field Name should not be Empty!!!");
      }
      else if (resultNameDuplicateValidation)
      {
        alert("Kindly Check the Target Definition Name. One of the Field Names is defined twice in the added rows. Target Definition Name should not be duplicated!!!");
      }
      else if (resultPositionValidation)
      {
        alert("Kindly Check the Target Element Position. Two Times same Number defined!!!");
      }
      else if (resultEmptyPositionValidation)
      {
        alert("Kindly Check the Target Element Position. One of the record is Empty in the added rows!!!");
      }
      else
      {
        this.ngxService.start();

        let prminputs = {
          "tenants_id": this.tenantId,
          "groups_id": this.groupId,
          "entities_id": this.entityId,
          "m_processing_layer_id": this.mProcessingLayerId,
          "m_processing_sub_layer_id": this.mProcessingSubLayerId,
          "processing_layer_id": this.processingLayerId,
          "target_def_list": requiredTargetDefinitionsList,
          "user_id": this.userId,
          "target_files_id": this.targetClickedData["id"]
        }

        this.targetService.postTargetDefinitionsListToserver(prminputs)
        .subscribe({
          next : (receivedData : any) => {
            let responseData = receivedData;
            console.log("Post Target Definitions List Response ", responseData);

            if (responseData["Status"] == "Success")
            {
              alert("Target Definitions Created Successfully!!!");
              this.ngxService.stop();
              window.location.reload();
            }
            else if (responseData["Status"] == "Error")
            {
              alert("Error in Creating Target Definitions. Please Contact Advents Support!!!");
              this.ngxService.stop();
            }
          },
          error : (error : any) => {
            console.log("Post Target Definition Error ", error);
            this.ngxService.stop();
          }
        });

      }


    }

  }

  public getValidateTargetDefinitionName(requiredTargetDefinitionsList : any) : boolean {
    for (var i=0; i<requiredTargetDefinitionsList.length; i++)
    {
      if (requiredTargetDefinitionsList[i]["fieldName"] == "")
      {
        return true
      }
    }
  }

  public getCheckTargetDefinitionName(requiredTargetDefinitionsList : any) : boolean {
    const toFindDuplicates = arry => arry.filter((item, index) => arry.indexOf(item) !== index);

    let allFieldNameList = [];
    for (var i = 0; i < requiredTargetDefinitionsList.length; i++)
    {
      allFieldNameList.push(requiredTargetDefinitionsList[i]["fieldName"]);
    }

    let duplicateElements = toFindDuplicates(allFieldNameList);

    if (duplicateElements.length != 0)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public getValidateTargetDefinitionPositions(requiredTargetDefinitionsList : any) : boolean {

    const toFindDuplicates = arry => arry.filter((item, index) => arry.indexOf(item) !== index);

    let allFieldPositionList = [];
    for (var i = 0; i < requiredTargetDefinitionsList.length; i++)
    {
      allFieldPositionList.push(requiredTargetDefinitionsList[i]["fieldPosition"]);
    }

    let duplicateElements = toFindDuplicates(allFieldPositionList);

    if (duplicateElements.length != 0)
    {
      return true;
    }
    else
    {
      return false;
    }
    
  }

  public getValidateNullTargetDefinitionPosition(requiredTargetDefinitionsList : any) : boolean {
    for (var i=0; i<requiredTargetDefinitionsList.length; i++)
    {
      if (requiredTargetDefinitionsList[i]["fieldPosition"] == null || requiredTargetDefinitionsList[i]["fieldPosition"] == "")
      {
        return true;
      }
    }
  }

  public addButtonClick() : void {
    this.isTargetDefinitionsRequired.push(true);
    this.targetDefinitions.push({
      fieldName: "",
      fieldPosition: null
    })
  }

  public deleteTargetDefClick(index: number) : void {
    this.isTargetDefinitionsRequired[index] = false;
  }

  public HanlerErrorResponse(err : any) : void {
    console.log(err);
  }

}
