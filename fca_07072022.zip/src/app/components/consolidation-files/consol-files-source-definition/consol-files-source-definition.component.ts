import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ConsolFilesSourceDefinitionService } from 'src/app/service/consol-files-source-definition.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ISourceDefinitions } from './consol-files-source-definition.model';

@Component({
  selector: 'app-consol-files-source-definition',
  templateUrl: './consol-files-source-definition.component.html',
  styleUrls: ['./consol-files-source-definition.component.css']
})
export class ConsolFilesSourceDefinitionComponent implements OnInit {

  public sourceData : any;
  public sourceId: number;
  public sourceName: string;
  public listButton: boolean = false;
  public createButton: boolean = false;
  public pagination: boolean = false;
  public paginationSize: number;
  public externalRowData: any;
  public externalColumnDefs: any;
  public actionType: string;
  public clickedData: any;
  public listSourceDefinitionEnable: boolean = false;
  public createSourceDefinitionEnable: boolean;
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public fieldName: string;
  public fieldPosition: number;
  public fieldDataType: string;
  public fieldDateFormatEnable: boolean;
  public fieldDateFormat: string;
  public fieldMinimumLength: number;
  public fieldMaximumLength: number;
  public fieldUnique: string;
  public sourceDefinitions: ISourceDefinitions[];
  public isSourceDefinitionsRequired: boolean[];

  constructor(private activeRoute: ActivatedRoute, private sourceDefService: ConsolFilesSourceDefinitionService, private ngxService: NgxUiLoaderService) { 
    this.sourceData = {};
    this.externalRowData = [];
    this.externalColumnDefs = [];
    this.actionType = '';
    this.clickedData = {};
    this.createSourceDefinitionEnable = false;
    this.fieldName = '';
    this.fieldPosition = null;
    this.fieldDataType = '';
    this.fieldDateFormatEnable = false;
    this.fieldDateFormat = '';
    this.fieldMinimumLength = null;
    this.fieldMaximumLength = null;
    this.fieldUnique = '';
    this.sourceDefinitions = [];
    this.isSourceDefinitionsRequired = [];
  }

  public ngOnInit(): void {
    this.getQueryParams();
    this.listButton = true;
    this.pagination = true;
    this.paginationSize = 15;
    this.listSourceDefinitionEnable = true;
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.setSourceDefinitionColumns();
    this.getSourceDefinitionList();
    this.fieldDataType = '-1';
    this.fieldDateFormat = '-1';
    this.fieldUnique = '-1';
  }

  public getQueryParams() : void {
    this.activeRoute.queryParamMap.subscribe(
      queryParams => {
        let params = queryParams["params"];
        this.sourceId = Number(params["id"]);
        this.sourceName = params["source_name"];
      }
    );
  }

  public setSourceDefinitionColumns() : void {
    this.externalColumnDefs = [
      // {
      //   headerName: 'Action',
      //   width: 100,
      //   template:
      //   `
      //   <a>
      //     <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
      //   </a>
      //   `
      // },
      {headerName: 'Name', field: 'attribute_name', sortable: true, filter: true, resizable: true, width: 200},
      {headerName: 'Position', field: 'attribute_position', sortable: true, filter: true, resizable: true, width: 100},
      {headerName: 'Data Type', field: 'attribute_data_type', sortable: true, filter: true, resizable: true, width: 200},
      {headerName: 'Date Format', field: 'attribute_date_format', sortable: true, filter: true, resizable: true, width: 200},
      {headerName: 'Minimum Length', field: 'attribute_min_length', sortable: true, filter: true, resizable: true, width: 200},
      {headerName: 'Maximum Length', field: 'attribute_max_length', sortable: true, filter: true, resizable: true, width: 200},
      {headerName: 'Unique (True/False)', field: 'is_unique', sortable: true, filter: true, resizable: true, width: 200}
    ]
  }

  public onGridReady(event : any) : void {

  };

  public onRowClicked(e : any) : void {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.actionType = actionType;
      this.clickedData = data;
      switch (actionType) {
        case 'Edit':
          return this.editSourceDefinitions();
      }
    }
  }

  public getSourceDefinitionList() : void {
    this.listSourceDefinitionEnable = true;
    this.createSourceDefinitionEnable = false;
    this.listButton = true;
    this.createButton = false;

    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "sources_id": this.sourceId,
      "is_active": "yes"
    };
    
    this.sourceDefService.getSourceDefinitionsListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Source Definitions List Response ", responseData);
        this.externalRowData = responseData;
        this.getDisplaySourceDefinitions();
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HanlerErrorResponse(error);
    }
  }

  public getAttributeUniqueColumnValue(data : Number) : string {
    if (data == 1)
    {
      return "1"
    }
    else
    {
      return "0"
    }
  }

  public getDisplaySourceDefinitions() : void {

    if (this.externalRowData.length == 0)
    {
      this.isSourceDefinitionsRequired = [true];
      this.sourceDefinitions = [{
        fieldName: "",
        fieldPosition: null,
        fieldDataType: "char",
        fieldDateFormat: "No",
        fieldMinimumLength: 1,
        fieldMaximumLength: 100,
        fieldUnique: "0"
      }];
    }
    else
    {
      for (var i=0; i<this.externalRowData.length; i++)
      {
        this.isSourceDefinitionsRequired.push(true);
        this.sourceDefinitions.push({
          fieldName: this.externalRowData[i]["attribute_name"],
          fieldPosition: this.externalRowData[i]["attribute_position"],
          fieldDataType: this.externalRowData[i]["attribute_data_type"],
          fieldDateFormat: this.externalRowData[i]["attribute_date_format"],
          fieldMinimumLength: this.externalRowData[i]["attribute_min_length"],
          fieldMaximumLength: this.externalRowData[i]["attribute_max_length"],
          fieldUnique: this.getAttributeUniqueColumnValue(this.externalRowData[i]["is_unique"])
        });
      }
    }
  }

  public editSourceDefinitions() : void {

  }

  public getCreateSourceDefinition() : void {
    this.listSourceDefinitionEnable = false;
    this.createSourceDefinitionEnable = true;
    this.listButton = false;
    this.createButton = true;
  }

  public sourceDefinitionsSaveClick() : void {
    // console.log("Source Definitions ", this.sourceDefinitions);
    // console.log("Source Definitions Boolean", this.isSourceDefinitionsRequired);

    let requiredSourceDefinitionsList = [];

    for (var i=0; i<this.sourceDefinitions.length; i++)
    {
      if (this.isSourceDefinitionsRequired[i])
      {
        requiredSourceDefinitionsList.push(this.sourceDefinitions[i]);
      };
    };

    // console.log("Required Source Definition List ", requiredSourceDefinitionsList);

    if (requiredSourceDefinitionsList.length == 0)
    {
      alert("Please fill the data and save the records!!!");
    }
    else if (requiredSourceDefinitionsList[0]["fieldName"] == "" || requiredSourceDefinitionsList[0]["fieldPosition"] == null || requiredSourceDefinitionsList[0]["fieldDataType"] == "-1" || requiredSourceDefinitionsList[0]["fieldDateFormat"] == "-1" || requiredSourceDefinitionsList[0]["fieldMinimumLength"] == "" || requiredSourceDefinitionsList[0]["fieldMaximumLength"] == "" || requiredSourceDefinitionsList[0]["fieldUnique"] == "-1")
    {
      alert("Please fill all the data in the fields and save the records!!!");
    }
    else
    {
      // console.log("Source Definitions Proper ", requiredSourceDefinitionsList);
      
      var resultNameValidation = this.getValidateSourceDefinitionName(requiredSourceDefinitionsList);
      var resultNameDuplicateValidation = this.getCheckSourceDefinitionName(requiredSourceDefinitionsList);
      var resultPositionValidation = this.getValidateSourceDefinitionPositions(requiredSourceDefinitionsList);
      var resultEmptyPositionValidation = this.getValidateSourceDefinitionEmptyPosition(requiredSourceDefinitionsList);
      var resultDataTypeValidation = this.getValidateSourceDefinitionDataType(requiredSourceDefinitionsList);
      var resultDateFormatValidation = this.getValidateSourceDefinitionDateFormat(requiredSourceDefinitionsList);
      var resultMinimumLength = this.getValidateSourceDefinitionMinimumLength(requiredSourceDefinitionsList);
      var resultMaximumLength = this.getValidateSourceDefinitionMaximumLength(requiredSourceDefinitionsList);
      var resultUniqueValidation = this.getValidateSourceDefinitionUnique(requiredSourceDefinitionsList);
      var resultUniqueDuplicateValidation = this.getCheckSourceDefinitionUnique(requiredSourceDefinitionsList);
      var resultUniqueChosen = this.getCheckSourceDefinitionUniqueChosen(requiredSourceDefinitionsList);
      
      if (resultNameValidation)
      {
        alert("Kindly Check the Source Name. It is Empty in the added rows. Source Field Name should not be Empty!!!");
      }
      else if (resultNameDuplicateValidation)
      {
        alert("Kindly Check the Source Name. One of the Field Names is defined twice in the added rows. Source Name should not be duplicated!!!");
      }
      else if (resultPositionValidation)
      {
        alert("Kindly Check the Source Element Position. Two Times same Number defined!!!");
      }
      else if (resultEmptyPositionValidation)
      {
        alert("Kindly Check the Source Element Position. One of the record is Empty in the added rows");
      }
      else if (resultDataTypeValidation)
      {
        alert("Kindly Check the Source Data Type. It is not Chosen in one of the added rows. Source Data Type should not be Empty!!!");
      }
      else if (resultDateFormatValidation)
      {
        alert("Kindly Check the Source Date Format. It is not Chosen in one of the added rows. Source Date Format Should not be Empty. If your chosen Data Type is other than 'Date' then choose 'NA' in date format!!!");
      }
      else if (resultMinimumLength)
      {
        alert("Kindly Check the Source Minimum Length. It is Empty in one of the addeed rows. Source Minimun Length Should not be Empty!!!");
      }
      else if (resultMaximumLength)
      {
        alert("Kindly Check the Source Maximum Length. It is Empty in one of the added rows. Source Maximum Length Should not be Empty!!!");
      }
      else if (resultUniqueValidation)
      {
        alert("Kindly Check the Source Unique Field. It is not Chosen in one of the added rows. Source Unique Field Should not be Empty!!!");
      }
      else if (resultUniqueDuplicateValidation)
      {
        alert("Kindly Check the Source Unique Field. Two times Unique Field is Chosen. It should be only one for a Source!!!");
      }
      else if (resultUniqueChosen)
      {
        alert("Kindly Check the Source Unique Field. No Unique Field is Chosen. There should be one Unique Field for a Source!!!");
      }
      else
      {
        this.ngxService.start();

        let prminputs = {
          "tenants_id": this.tenantId,
          "groups_id": this.groupId,
          "entities_id": this.entityId,
          "m_processing_layer_id": this.mProcessingLayerId,
          "m_processing_sub_layer_id": this.mProcessingSubLayerId,
          "processing_layer_id": this.processingLayerId,
          "source_def_list": requiredSourceDefinitionsList,
          "user_id": this.userId,
          "sources_id": this.sourceId
        };
    
        this.sourceDefService.postSourceDefinitionsListToServer(prminputs)
        .subscribe({
          next : (receivedData : any) => {
            let responseData = receivedData;
            console.log("Post Source Definition Response ", responseData);
    
            if (responseData["Status"] == "Success")
            {
              alert("Source Definitions Created Successfully!!!");
              this.ngxService.stop();
              window.location.reload();
            }
            else if (responseData["Status"] == "Error")
            {
              alert("Error in Creating Source Definitions. Please Contact Advents Support!!!");
              this.ngxService.stop();
            }
          },
          error : (error : any) => {
            console.log("Post Source Definition Error ", error);
            this.ngxService.stop();
          }
        })
      }
    }
  }

  public getValidateSourceDefinitionName(requiredSourceDefinitionsList : any) : boolean {
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldName"] == "")
      {
        return true;
      }
    }
  }

  public getCheckSourceDefinitionName(requiredSourceDefinitionsList : any) : boolean {

    const toFindDuplicates = arry => arry.filter((item, index) => arry.indexOf(item) !== index);

    let allFieldNameList = [];
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      allFieldNameList.push(requiredSourceDefinitionsList[i]["fieldName"]);
    }

    let duplicateElements = toFindDuplicates(allFieldNameList);

    if (duplicateElements.length != 0)
    {
      return true;
    }
    else
    {
      return false;
    }

  }

  public getValidateSourceDefinitionPositions(requiredSourceDefinitionsList : any) : boolean {

    const toFindDuplicates = arry => arry.filter((item, index) => arry.indexOf(item) !== index);

    let allFieldPositionList = [];
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      allFieldPositionList.push(requiredSourceDefinitionsList[i]["fieldPosition"]);
    }

    let duplicateElements = toFindDuplicates(allFieldPositionList);

    if (duplicateElements.length != 0)
    {
      return true;
    }
    else
    {
      return false;
    }
    
  }

  public getValidateSourceDefinitionEmptyPosition(requiredSourceDefinitionsList : any) : boolean {
    for (var i=0; i<requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldPosition"] == null || requiredSourceDefinitionsList[i]["fieldPosition"] == "")
      {
        return true
      }
    }
  }

  public getValidateSourceDefinitionDataType(requiredSourceDefinitionsList : any) : boolean {
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldDataType"] == "-1")
      {
        return true;
      }
    }
  }

  public getValidateSourceDefinitionDateFormat(requiredSourceDefinitionsList : any) : boolean {
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldDateFormat"] == "-1")
      {
        return true;
      }
    }
  }

  public getValidateSourceDefinitionMinimumLength(requiredSourceDefinitionsList : any) : boolean {
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldMinimumLength"] == "" || requiredSourceDefinitionsList[i]["fieldMinimumLength"] == null)
      {
        return true;
      }
    }
  }

  public getValidateSourceDefinitionMaximumLength(requiredSourceDefinitionsList : any) : boolean {
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldMaximumLength"] == "" || requiredSourceDefinitionsList[i]["fieldMaximumLength"] == null)
      {
        return true;
      }
    }
  }

  public getValidateSourceDefinitionUnique(requiredSourceDefinitionsList : any) : boolean {
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldUnique"] == "-1")
      {
        return true;
      }
    }
  }

  public getCheckSourceDefinitionUnique(requiredSourceDefinitionsList : any) : boolean {

    const toFindDuplicates = arry => arry.filter((item, index) => arry.indexOf(item) !== index);

    let allFieldUniqueList = [];
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldUnique"] == "1")
      {
        allFieldUniqueList.push(requiredSourceDefinitionsList[i]["fieldUnique"]);
      }
    }

    let duplicateElements = toFindDuplicates(allFieldUniqueList);

    if (duplicateElements.length != 0)
    {
      return true;
    }
    else
    {
      return false;
    }

  }

  public getCheckSourceDefinitionUniqueChosen(requiredSourceDefinitionsList : any) : boolean {

    let allFieldUniqueList = [];
    for (var i = 0; i < requiredSourceDefinitionsList.length; i++)
    {
      if (requiredSourceDefinitionsList[i]["fieldUnique"] == "1")
      {
        allFieldUniqueList.push(requiredSourceDefinitionsList[i]["fieldUnique"]);
      }
    }

    if (allFieldUniqueList.length == 0)
    {
      return true;
    }
    else
    {
      return false;
    }

  }

  public dataTypeChange() : void {
    if (this.fieldDataType == "date")
    {
      this.fieldDateFormatEnable = true;
    }
    else
    {
      this.fieldDateFormatEnable = false;
    }
  }

  public onSaveButtonClick() : void {

  }

  public onClearButtonClick() : void {
    
  }

  public addButtonClick() : void {
    this.isSourceDefinitionsRequired.push(true);
    this.sourceDefinitions.push({
      fieldName: "",
      fieldPosition: null,
      fieldDataType: "char",
      fieldDateFormat: "No",
      fieldMinimumLength: 1,
      fieldMaximumLength: 100,
      fieldUnique: "0"
    });
  }

  public deleteSourceDefClick(index : number) : void {
    this.isSourceDefinitionsRequired[index] = false;
  }

  public HanlerErrorResponse(err : any) : void {
    console.log(err);
  }

}
