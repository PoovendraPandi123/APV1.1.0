import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesReportComponent } from './consol-files-report.component';

describe('ConsolFilesReportComponent', () => {
  let component: ConsolFilesReportComponent;
  let fixture: ComponentFixture<ConsolFilesReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
