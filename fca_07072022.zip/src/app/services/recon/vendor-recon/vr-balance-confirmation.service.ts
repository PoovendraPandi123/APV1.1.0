import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/service/common.service';

@Injectable({
  providedIn: 'root'
})
export class VrBalanceConfirmationService {

  public reconPort = "50013";

  constructor(private CS: CommonService) { }

  public sendMailToVendor(prminputs : any) : any{
    let resData = CommonService.authReq(this.reconPort+'/api/v1/vendor_recon/get_send_mail/');
    return this.CS.SendToAPI("post", resData, prminputs)
  }
}
