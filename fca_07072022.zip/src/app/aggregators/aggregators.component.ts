import { Component, OnInit } from '@angular/core';
import { AggregatorsService } from '../service/aggregators.service';
import {Router} from '@angular/router';
import { HttpClient  } from '@angular/common/http';
declare const $: any;

@Component({
  selector: 'app-aggregators',
  templateUrl: './aggregators.component.html',
  styleUrls: ['./aggregators.component.css']
})
export class AggregatorsComponent implements OnInit {

  public cardTitle;
  public aggregatorview;
  public objaggregator;
  public aggregatorlist;
  public newaggregator;
  public aggregatordata;
  public aggregatormainlist;
  public userdtl;
  public user;
  public operationflag;
  public sourcedata;
  public sourcelist;

  constructor(private router: Router,private objservice:AggregatorsService,public http:HttpClient) { }


  ngOnInit(): void {

    this.cardTitle="Aggregator"
    this.aggregatorview=false;
    this.objaggregator={"aggregator_name":""};
    this.newaggregator={"source_id":0,"base_file":""};
    this.aggregatorlist=[];

    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));
    this.user=JSON.parse(localStorage.getItem('Userdtl'));
    console.log("userdtl",this.user);
  
    this.aggregatormainlist=[];
   this.operationflag="ANDSD"
    this.userdtl.tenant_id=1;
    this.userdtl.group_id=1;
    this.userdtl.entity_id=1;
    this.userdtl.module_id=1;
    this.userdtl.user_id=1;
    this.getaggregatorlist();
    this.getsourcelist();
  }

  list(){
this.aggregatorview=true;
this.getaggregatorlist();

  }

  backlist(){
    this.aggregatorview=false;
  }

  addFieldValue(data?) {
    //console.log(this.newOtherCost)
    this.aggregatorlist.push(this.newaggregator);
    // this.sourcelist.splice(this.sourcelist.findIndex(item => item.source_id === data.source_id), 1);
    // this.sourcelist=this.sourcelist.slice(x=>x.source_id!==data.source_id)
    let getLength = this.aggregatorlist.length - 1;    
    this.newaggregator={"source_id":0,"base_file":""};
 
  }

  deleteFieldValue(index) {
    this.aggregatorlist.splice(index, 1);
    // this.costVendorTypeArray.splice(index, 1);    
  }			
  clearaggregatorFields() {
    //this.aggregatorlist.pull(this.newaggregator);
    this.newaggregator={"source_id":0,"base_file":""};

  }

  getsourcelist(){
    let Indata={
      "tenant_id":  this.userdtl.tenant_id,
      "group_id":   this.userdtl.group_id,
      "entity_id":  this.userdtl.entity_id,
      "module_id":  this.userdtl.module_id,
      "operation_flag":this.operationflag   
    }
    console.log("inputsource",Indata);
    this.objservice.getsourceFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourcelistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.sourcelist=this.sourcedata.sources_list;
      console.log("Sourcelist---",this.sourcelist)
    });
  }

//   onChange(value) {   
//     this.sourcelist=this.sourcelist.filter(x=>x.source_id!=value)
//  }


  getaggregatorlist(){

    let Indata={
      "tenant_id":  this.userdtl.tenant_id,
      "group_id":   this.userdtl.group_id,
      "entity_id":  this.userdtl.entity_id,
      "user_id": this.userdtl.user_id,     
      "operation_flag":'SELECT'
    }
    console.log("inputaggregratorlist",Indata);
    this.objservice.getaggregatorFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("aggregratorlistresponse---",tempresponsedata)
      this.aggregatordata=tempresponsedata;
      this.aggregatormainlist=this.aggregatordata.aggregator_list;
      console.log("aggregratorlist---",this.aggregatormainlist)
      this.objaggregator={"aggregator_name":""};
    this.newaggregator={"source_id":0,"base_file":""};
    this.aggregatorlist=[];
    setTimeout(() => {
      this.loadData();
         }, 300);
    });
  }

 

  cancelEdit(){
    this.objaggregator={"aggregator_name":""};
    this.newaggregator={"source_id":0,"base_file":""};
    this.aggregatorlist=[];

  }

  saveaggregatordetails(){
    let Indata={
      "tenant_id": this.userdtl.tenant_id,
      "group_id": this.userdtl.group_id,
      "entity_id": this.userdtl.entity_id,
      "user_id": this.userdtl.user_id,     
      "aggregator_name": this.objaggregator.aggregator_name,
      "aggregator_list": this.aggregatorlist,
       }

    console.log("inputsaveaggregator",Indata);
    this.objservice.postaggregatorFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Aggregatorresponse---",tempresponsedata)
      this.objaggregator={"aggregator_name":""};
    this.newaggregator={"source_id":0,"base_file":""};
    this.aggregatorlist=[];
    // this.objsource= new Source();
    this.list();
    });

  }

  Editaggregatordetail(param){
console.log("editdata",param);
    this.objaggregator.aggregator_name=param.aggregator_name;
    this.aggregatorlist=param.aggregator_list;
    this.aggregatorview=false;

  }

  private loadData() {

    if ($.fn.dataTable.isDataTable('#tablesourceExport')) {
      $('#tablesourceExport').DataTable();
    }
    else {
      $('#tablesourceExport').DataTable({
        // dom: 'Bfrtip',
        // buttons: ['pdf'],
        buttons: [],
        "pageLength": 10,
        "paging": true,
        "bFilter": true,
        "bInfo": true,
        "order": [], //to disable inital sort
        drawCallback: () => {
         
         }
      });
    }
  }

}
