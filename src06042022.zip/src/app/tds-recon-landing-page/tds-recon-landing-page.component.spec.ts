import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TdsReconLandingPageComponent } from './tds-recon-landing-page.component';

describe('TdsReconLandingPageComponent', () => {
  let component: TdsReconLandingPageComponent;
  let fixture: ComponentFixture<TdsReconLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TdsReconLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TdsReconLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
