import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-process',
  templateUrl: './consol-files-process.component.html',
  styleUrls: ['./consol-files-process.component.css']
})
export class ConsolFilesProcessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
