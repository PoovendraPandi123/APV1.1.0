import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-target-files',
  templateUrl: './consol-files-target-files.component.html',
  styleUrls: ['./consol-files-target-files.component.css']
})
export class ConsolFilesTargetFilesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
