import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-source-definition',
  templateUrl: './consol-files-source-definition.component.html',
  styleUrls: ['./consol-files-source-definition.component.css']
})
export class ConsolFilesSourceDefinitionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
