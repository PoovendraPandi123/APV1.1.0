import { TestBed } from '@angular/core/testing';

import { VrSummaryService } from './vr-summary.service';

describe('VrSummaryService', () => {
  let service: VrSummaryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrSummaryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
