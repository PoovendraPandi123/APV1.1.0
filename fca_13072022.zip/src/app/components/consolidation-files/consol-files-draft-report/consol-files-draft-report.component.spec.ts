import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesDraftReportComponent } from './consol-files-draft-report.component';

describe('ConsolFilesDraftReportComponent', () => {
  let component: ConsolFilesDraftReportComponent;
  let fixture: ComponentFixture<ConsolFilesDraftReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesDraftReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesDraftReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
