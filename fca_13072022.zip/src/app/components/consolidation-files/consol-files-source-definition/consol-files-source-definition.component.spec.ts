import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesSourceDefinitionComponent } from './consol-files-source-definition.component';

describe('ConsolFilesSourceDefinitionComponent', () => {
  let component: ConsolFilesSourceDefinitionComponent;
  let fixture: ComponentFixture<ConsolFilesSourceDefinitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesSourceDefinitionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesSourceDefinitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
