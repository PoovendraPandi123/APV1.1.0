import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlcsDashboardComponent } from './alcs-dashboard.component';

describe('AlcsDashboardComponent', () => {
  let component: AlcsDashboardComponent;
  let fixture: ComponentFixture<AlcsDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlcsDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlcsDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
