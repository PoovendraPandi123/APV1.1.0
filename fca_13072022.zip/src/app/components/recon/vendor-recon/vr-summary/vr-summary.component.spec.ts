import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrSummaryComponent } from './vr-summary.component';

describe('VrSummaryComponent', () => {
  let component: VrSummaryComponent;
  let fixture: ComponentFixture<VrSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
