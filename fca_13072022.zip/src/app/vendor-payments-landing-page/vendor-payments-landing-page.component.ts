import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-payments-landing-page',
  templateUrl: './vendor-payments-landing-page.component.html',
  styleUrls: ['./vendor-payments-landing-page.component.css']
})
export class VendorPaymentsLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
