export const environment = {
  production: true,
  envName: 'dev',
  host: "https://ecourt.azurewebsites.net",

  cdnhost: "http://65.0.168.200:",
    // cdnhost: "http://10.100.2.181:",
  // cdnhost: "http://127.0.0.1:",
 
  uploadFileNativePath:"./assets/UploadedFiles/"
};
