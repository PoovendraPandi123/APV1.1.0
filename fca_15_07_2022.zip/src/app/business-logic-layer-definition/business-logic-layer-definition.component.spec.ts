import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessLogicLayerDefinitionComponent } from './business-logic-layer-definition.component';

describe('BusinessLogicLayerDefinitionComponent', () => {
  let component: BusinessLogicLayerDefinitionComponent;
  let fixture: ComponentFixture<BusinessLogicLayerDefinitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusinessLogicLayerDefinitionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessLogicLayerDefinitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
