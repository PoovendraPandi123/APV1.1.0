import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-brs-report',
  templateUrl: './brs-report.component.html',
  styleUrls: ['./brs-report.component.css']
})
export class BrsReportComponent implements OnInit {

  public processingLayerList : any;
  public selectProcessingLayer : any;
  public dateChoosen : String = 'date';
  public reportFileGenerated : any;
  public reportDownload: boolean = false;
  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.selectProcessingLayer = {
      "processing_layer_id":0
    };
    this.getProcessingLayerList();
  }

  getProcessingLayerList(){
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    }

    this.obj_auth_service.getProcessingLayerListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Processing Layer List Response: ", response_data);
        this.processingLayerList = response_data["processing_layer_list"];
      }
    )

  }

  reportDownloadClick(){
    this.reportDownload = false;
    let processingLayerId = this.selectProcessingLayer.processing_layer_id;
    let dateChoosen = this.dateChoosen;
    
    if(processingLayerId == 0)
    {
      alert("Kindly Choose Reconciliation Type!!!");
    }
    
    if(dateChoosen === "date")
    {
      alert("Kindly Choose Date!!!");
    }
    
    if(processingLayerId != 0 && dateChoosen !== "date")
    {
      this.ngxService.start();
      let data = {
        "tenantId": this.tenantId,
        "groupId": this.groupId,
        "entityId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "processingLayerId": processingLayerId,
        "userId": this.userId,
        "reportDate": dateChoosen
      }

      this.obj_auth_service.getBrsReportFromServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log("Report Button Click Response", responseData);
          if(responseData["Status"] === "Success")
          {
            console.log("Success");
            this.reportFileGenerated = responseData["file_generated"];
            this.reportDownload = true;
            this.ngxService.stop();
          }
          else if(responseData["Status"] === "Error")
          {
            console.log("Error");
            this.ngxService.stop();
            alert("Error in Getting Report. Please Contact Advent Support!!!");
          }
          else if(responseData["Status"] === "Report Generating")
          {
            console.log("Another user is currently generating report");
            this.ngxService.stop();
            alert("Another User is Currently Generating Report. Kindly try after some time!!!");
          }
        }
      )

    }
  }

}
