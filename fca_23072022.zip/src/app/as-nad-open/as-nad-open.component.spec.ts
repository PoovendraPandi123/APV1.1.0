import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsNadOpenComponent } from './as-nad-open.component';

describe('AsNadOpenComponent', () => {
  let component: AsNadOpenComponent;
  let fixture: ComponentFixture<AsNadOpenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsNadOpenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsNadOpenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
