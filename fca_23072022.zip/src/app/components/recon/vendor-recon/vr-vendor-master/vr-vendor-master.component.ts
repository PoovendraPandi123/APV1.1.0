import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { VrVendorMasterService } from 'src/app/services/recon/vendor-recon/vr-vendor-master.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-vr-vendor-master',
  templateUrl: './vr-vendor-master.component.html',
  styleUrls: ['./vr-vendor-master.component.css']
})
export class VrVendorMasterComponent implements OnInit {

  public paginationSize: number;
  public externalRowData: any;
  public externalColumnDefs: any;
  public pagination: boolean;
  public searchValue: string;
  public gridRowApi: any;
  public gridColumnApi: any;

  constructor(private vendorMasterService: VrVendorMasterService, private ngxService: NgxUiLoaderService) { 
    this.paginationSize = null;
    this.externalRowData = [];
    this.externalColumnDefs = [];
    this.pagination = false;
    this.searchValue = '';
    this.gridColumnApi = [];
    this.gridRowApi = [];
  }

  public ngOnInit(): void {
    this.paginationSize = 15;
    this.pagination = true;
    this.initializeVendorMaster();
  }

  public onGridReady(params : any) : void {
    this.gridRowApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  public onRowClicked(e : any) : void {

  }

  public quickSearch() : void {
    this.gridRowApi.setQuickFilter(this.searchValue);
  }

  public initializeVendorMaster() : void {
    this.ngxService.start();
    this.externalColumnDefs = [
      {headerName: 'VEN_CODE', field: 'vendor_code', sortable: true, filter: true, resizable: true},
      {headerName: 'VEN_NAME', field: 'vendor_name', sortable: true, filter: true, resizable: true},
      {headerName: 'VEN_SITE_CODE', field: 'vendor_site_code', sortable: true, filter: true, resizable: true},
      {headerName: 'VEN_CAT', field: 'vendor_category', sortable: true, filter: true, resizable: true},
      {headerName: 'LIABILITY A/C', field: 'liability_account', sortable: true, filter: true, resizable: true},
      {headerName: 'CON_FNAME', field: 'contact_first_name', sortable: true, filter: true, resizable: true},
      {headerName: 'CON_PHONE', field: 'contact_phone_number', sortable: true, filter: true, resizable: true},
      {headerName: 'CON_EMAIL', field: 'contact_email', sortable: true, filter: true, resizable: true},
      {headerName: 'DIVISION', field: 'division', sortable: true, filter: true, resizable: true},
      {headerName: 'PAN_NO', field: 'pan_number', sortable: true, filter: true, resizable: true},
      {headerName: 'GST Number', field: 'gst_number', sortable: true, filter: true, resizable: true},
      {headerName: 'VEN_TYPE', field: 'vendor_type', sortable: true, filter: true, resizable: true},
    ];
    
    let params = {};

    this.vendorMasterService.getVendorMasterListFromServer(params).
    subscribe(
      receivedData => {
        let responseData = receivedData;
        // console.log("Vendor Master List Response ", responseData);
        this.externalRowData = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    };
  };

  public HandleErrorResponse(err : any) : void {
    console.log(err);
  }

}
