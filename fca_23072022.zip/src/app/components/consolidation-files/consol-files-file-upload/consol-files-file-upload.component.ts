import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ConsolFilesFileUploadService } from 'src/app/service/consol-files-file-upload.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConsolFilesFileUpload } from './consol-files-file-upload.model';

@Component({
  selector: 'app-consol-files-file-upload',
  templateUrl: './consol-files-file-upload.component.html',
  styleUrls: ['./consol-files-file-upload.component.css']
})
export class ConsolFilesFileUploadComponent implements OnInit {

  @ViewChild('content') content : ElementRef;

  @ViewChild('fileInput',  {static: false}) 
  fileInput : ElementRef;

  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: number;
  public sourceName: string;
  public sourceList: any;
  public gstRemittanceMonth: string;
  public pagination: boolean;
  public paginationSize: number;
  public fileRowData: any;
  public fileColumnDefs: any;
  public editGstRemittanceMonth: string;
  public closeResult : any;
  public actionType: string;
  public clickedData: any;
  public removeFileSelection: string;
  public gridApi: any;
  public gridColumnApi: any;
  public gridSelectedRows: any;
  public consolFilesFileUpload: ConsolFilesFileUpload;
  public fileUpload: any;

  constructor(private fileUploadService: ConsolFilesFileUploadService, private ngxService: NgxUiLoaderService, private modalService: NgbModal) { 
    this.userModelList = [];
    this.userDetails = [];
    this.tenantId = null;
    this.groupId = null;
    this.entityId = null;
    this.mProcessingLayerId = null;
    this.mProcessingSubLayerId = null;
    this.processingLayerId = null;
    this.userId = null;
    this.sourceName = '';
    this.sourceList = [];
    this.gstRemittanceMonth = '';
    this.pagination = false;
    this.paginationSize = null;
    this.fileRowData = [];
    this.fileColumnDefs = [];
    this.editGstRemittanceMonth = '';
    this.actionType = '';
    this.clickedData = [];
    this.removeFileSelection = '';
    this.gridSelectedRows = [];
  }

  public ngOnInit(): void {

    this.consolFilesFileUpload = new ConsolFilesFileUpload();

    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;

    this.consolFilesFileUpload.userId = this.userDetails["user_id"];
    this.consolFilesFileUpload.tenantId = this.userModelList["tenant_id"];
    this.consolFilesFileUpload.groupId = this.userModelList["group_id"];
    this.consolFilesFileUpload.entityId = this.userModelList["entity_id"];
    this.consolFilesFileUpload.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.consolFilesFileUpload.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.consolFilesFileUpload.processingLayerId = 1000;

    this.sourceName = '-1';
    this.pagination = true;
    this.paginationSize = 17;
    this.removeFileSelection = '0';
    this.setFileColumnDefs();
    this.getSourceList();
    this.getFileUploadsList();
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public fileOnChange(event : any) : void {
    let files = event.target.files;
    console.log("Files ", files);
    this.consolFilesFileUpload.fileInputName = files[0];
  };


  public getSourceList() : void {

    this.ngxService.start();

    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.fileUploadService.getSourceListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Source List Response ", responseData);
        this.sourceList = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public uploadClick() : void {

    console.log("File Name", this.consolFilesFileUpload.fileInputName.name.split(".")[this.consolFilesFileUpload.fileInputName.name.split(".").length - 1])

    if (this.sourceName == '-1')
    {
      alert("Kindly Choose Source Name!!!");
    }
    else if (this.gstRemittanceMonth == '')
    {
      alert("Kindly Choose GST Remittance Month!!!");
    }
    else if (this.consolFilesFileUpload.fileInputName === undefined)
    {
      alert("Please Choose the File for Upload!!!");
    }
    else if (this.consolFilesFileUpload.fileInputName.name.split(".")[this.consolFilesFileUpload.fileInputName.name.split(".").length - 1] == "xlsb" || this.consolFilesFileUpload.fileInputName.name.split(".")[this.consolFilesFileUpload.fileInputName.name.split(".").length - 1] == "xlsx")
    {

      this.ngxService.start();

      const formData = new FormData();

      formData.append("fileName", this.consolFilesFileUpload.fileInputName);
      formData.append("tenantsId", this.consolFilesFileUpload.tenantId);
      formData.append("groupsId", this.consolFilesFileUpload.groupId);
      formData.append("entityId", this.consolFilesFileUpload.entityId);
      formData.append("mProcessingLayerId", this.consolFilesFileUpload.mProcessingLayerId);
      formData.append("mProcessingSubLayerId", this.consolFilesFileUpload.mProcessingSubLayerId);
      formData.append("processingLayerId", this.consolFilesFileUpload.processingLayerId);
      formData.append("userId", this.consolFilesFileUpload.userId);
      formData.append("sourceId", this.sourceName);
      formData.append("gstRemittanceMonth", this.gstRemittanceMonth);

      this.fileUpload = formData;

      console.log("Form Input ", this.fileUpload);

      this.fileUploadService.postFileToServer(this.fileUpload)
      .subscribe({
        next : (receivedData : any) => {
          let responseData = receivedData;
          console.log("File Upload Response ", responseData);
          if (responseData["Status"] == "Success")
          {
            alert("File Upload Successfully!!!");
            this.fileInput.nativeElement.value = '';
            this.consolFilesFileUpload.fileInputName = undefined;
            this.getFileUploadsList();
            this.ngxService.stop();
          }
          else if (responseData["Status"] == "Error")
          {
            alert("Error in File Upload. Kindly Contact Advents Support!!!");
            this.fileInput.nativeElement.value = '';
            this.consolFilesFileUpload.fileInputName = undefined;
            this.getFileUploadsList();
            this.ngxService.stop();
          }
        },
        error : (error : any) => {
          console.log("File Upload Error ", error);
          this.ngxService.stop();
        }
      })

    }
    else
    {
      alert("Please Choose only Excel File for Upload!!!");
    }
  }

  public gstMonnthAllUpdateClick() : void {
    if (this.gstRemittanceMonth == '')
    {
      alert("Kindly Choose GST Remittance Month!!!");
    }
    else
    {
      this.ngxService.start();

      let fileUploadsIdList = [];

      for (var i=0; i<this.gridSelectedRows.length; i++)
      {
        fileUploadsIdList.push(this.gridSelectedRows[i]["id"]);
      };

      let prminputs = {
        "fileUploadsIdList": fileUploadsIdList,
        "gstRemittanceMonth": this.gstRemittanceMonth
      };

      this.fileUploadService.getGstMonthUpdateAllToServer(prminputs)
      .subscribe({
        next : (receivedData : any) => {
          let responseData = receivedData;
          console.log("GST Month Update All Response ", responseData);
          if (responseData["Status"] == "Success")
          {
            alert("Data Updated Successfully!!!");
            this.getFileUploadsList();
            this.ngxService.stop();
          }
          else if (responseData["Status"] == "Error")
          {
            alert("Error in Updating Data. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        error : (error : any) => {
          console.log("GST Month Update All Error ", error);
          this.ngxService.stop();
        }
      })

    }
  }

  public setFileColumnDefs() : void {
    this.fileColumnDefs = [
      {headerName: '', checkboxSelection: true, field: "", maxWidth: 40, pinned: 'left', sortable: true, filter: false, resizable: false, suppressAutoSize: true, suppressSizeToFit: true, lockPosition: true, headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true},
      {
        headerName: 'Action',
        width: 80,
        template:
        `
        <a>
          <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        </a>
        `
      },
      {headerName: 'GST Month', field: 'gst_month', sortable: true, filter: true, resizable: true, width: 120},
      {headerName: 'Source Name', field: 'source_name', sortable: true, filter: true, resizable: true},
      {headerName: 'Extraction Type', field: 'extraction_type', sortable: true, filter: true, resizable: true},
      {headerName: 'File Name', field: 'file_name', sortable: true, filter: true, resizable: true},
      {headerName: 'File Size (Bytes)', field: 'file_size_bytes', sortable: true, filter: true, resizable: true, width: 140},
      {headerName: 'Row Count', field: 'file_row_count', sortable: true, filter: true, resizable: true, width: 120},
      {headerName: 'Status', field: 'status', sortable: true, filter: true, resizable: true},
      {headerName: 'Comments', field: 'comments', sortable: true, filter: true, resizable: true, width:500},
    ]
  }

  public getFileUploadsList() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.fileUploadService.getFileUploadsListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get File Uploads List Response ", responseData);
        this.fileRowData = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public gstUniqueButtonClick() : void {
    if (this.editGstRemittanceMonth == '')
    {
      alert("Kindly choose the GST Remittance Month!!!");
    }
    else if (this.removeFileSelection == '-1')
    {
      alert("Kindly choose the file needs to be removed or not!!!");
    }
    else
    {
      this.ngxService.start();

      let prminputs = {
        "fileId": this.clickedData["id"],
        "gstRemittanceMonth": this.editGstRemittanceMonth,
        "fileRequired": this.removeFileSelection
      };

      this.fileUploadService.getGstMonthUpdateToServer(prminputs)
      .subscribe({
        next : (receivedData : any) => {
          let responseData = receivedData;
          console.log("GST Month Update Response ", responseData);
          if (responseData["Status"] == "Success")
          {
            alert("Data Updated Successfully!!!");
            this.getFileUploadsList();
            this.ngxService.stop();
          }
          else if(responseData["Status"] == "Error")
          {
            alert("Error in Updating Data. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        error : (error : any) => {
          console.log("GST Month Update Error ", error);
          this.ngxService.stop();
        }
      });
    }
  }

  public fileUploadRefresh() : void {
    this.getFileUploadsList();
  }

  public onGridReady(params : any) : void {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  public onGridSelectionChanged(params : any) : void {
    this.gridSelectedRows = params.api.getSelectedRows();
  }

  public onRowClicked(e : any) : void {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.actionType = actionType;
      this.clickedData = data;
      switch (actionType) {
        case 'Edit':
          return this.editFileUpload();
      }
    }
  };

  public validateButtonClick() : void {
    if (this.gridSelectedRows.length == 0)
    {
      alert("Please Select the Record and Click on Validate Button!!!");
    }
    else 
    {
      this.ngxService.start();
      console.log("Grid Selected Rows ", this.gridSelectedRows);

      let validateFileIds = [];

      for (var i=0; i<this.gridSelectedRows.length; i++)
      {
        if (this.gridSelectedRows[i]["status"] == "VALIDATION ERROR")
        {
          validateFileIds.push(this.gridSelectedRows[i]["id"]);
        }
      }
  
      let prminputs = {
        "validateFileIdsList": validateFileIds
      };
      console.log("Validate params ", prminputs);
      this.fileUploadService.getSendValidateRecordsToServer(prminputs)
      .subscribe({
        next : (receivedData : any) => {
          let responseData = receivedData;
          console.log("Validate Button Click Response ", responseData);
          if (responseData["Status"])
          {
            alert("Records Updated Successfully!!!");
            this.getFileUploadsList();
            this.ngxService.stop();
          }
          else if (responseData["Status"])
          {
            alert("Error in Updating Records. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        error : (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      });
    }

  }

  public editFileUpload() : void {
    this.open(this.content);
  }

  public HandleErrorResponse(err : any) : void {
    console.log(err);
  }

}