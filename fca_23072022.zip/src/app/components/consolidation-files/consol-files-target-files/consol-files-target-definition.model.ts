export interface ITargetDefinitions {
    fieldName: string;
    fieldType: string;
    fieldPosition: number;
    fieldUnique: string;
    fieldPrimaryDate: string;
    fieldStatus: string
}