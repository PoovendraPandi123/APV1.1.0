import { TestBed } from '@angular/core/testing';

import { BusinesslogiclayerService } from './businesslogiclayer.service';

describe('BusinesslogiclayerService', () => {
  let service: BusinesslogiclayerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusinesslogiclayerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
