import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { ApiCallService } from './api-call.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConsoleFilesSourceService {

  public port : string = '50012';

  constructor(private CS: CommonService, private http: HttpClient) { }

  // public postSourceToServer(prminputs : any) : any {
  //   var resData = CommonService.authReq(this.port+'/api/v1/consol_files/source/');
  //   return this.CS.SendToAPI("post", resData, prminputs);
  // }

  public getSourceListFromServer(prminputs : any) : any {
    var resData = CommonService.authReq(this.port+'/api/v1/consol_files/source/');
    return this.CS.SendToAPI("get", resData, prminputs);
  }

  // private getSourceListFromServer(prminputs: any) : any {
  //   var resData = ApiCallService.authRequest(this.port + '/api/v1/consol_files/source/');
  //   return this.apiCall.SendToAPI("get", resData, prminputs);
  // }

  public postSourceToServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+'/api/v1/consol_files/source/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }

  public getActiveSourceListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/generic/sources/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&is_active=yes`);
    return this.http.get(resData["url"], resData["headers"])
  }

  public getDeleteSourceToServer(prminputs: any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/source/${prminputs["id"]}/`);
    return this.http.patch(resData["url"], prminputs, resData["headers"]);
  }

  public getEditSourceToSeerver(prminputs: any) : any {
    var resData = ApiCallService.authRequest(this.port+'/api/v1/consol_files/get_edit_sources/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }
}
