import { TestBed } from '@angular/core/testing';

import { BrsFileUploadService } from './brs-file-upload.service';

describe('BrsFileUploadService', () => {
  let service: BrsFileUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BrsFileUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
