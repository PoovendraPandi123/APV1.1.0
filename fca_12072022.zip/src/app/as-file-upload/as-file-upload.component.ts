import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {Router} from '@angular/router';
import { ASFileUploadService } from '../service/as-file-upload.service';
import { HttpClient  } from '@angular/common/http';
import { ASFileUpload } from './as-file-upload.model';
import {Observable} from 'rxjs';
import { AuthService } from '../service/auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AgGridAngular } from 'ag-grid-angular';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-as-file-upload',
  templateUrl: './as-file-upload.component.html',
  styleUrls: ['./as-file-upload.component.css']
})
export class AsFileUploadComponent implements OnInit {

  @ViewChild('externalFileInput', {static: false})
  externalFileInput: ElementRef;

  @ViewChild('internalFileInput', {static: false})
  internalFileInput : ElementRef;

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userdtl;
  public sourcedata;
  public processinglayerlist;
  public objprocessid;
  public fileupload;
  public fileuploadlist;

  public paginationSize;
  public file_records;
  public pagination;
  rowData: Observable<any[]>;
  public fileData;

  public userModelList :  any;
  public processingLayerIdsUser :  any;
  public selectProcessingLayer : any;
  public fileUploaded : any;
  public fileRowData : any;
  public fileColumnDefs :  any;

  public fileType: any;
  public fileUploadList: any;

  public fromDate: any;
  public toDate: any;

  ASFileUpload:ASFileUpload;

  columnDefs = [
    { field: 'File Name',headerText: 'File Name', sortable: true, filter: true},
    { field: 'Size(mb)', sortable: true, filter: true },
    { field: 'UploadDate', sortable: true, filter: true },
    { field: 'UploadBy', sortable: true, filter: true },
    { field: 'UploadStatus', sortable: true, filter: true },
    { field: 'Validation', sortable: true, filter: true },
    { field: 'Status', sortable: true, filter: true },
    { field: 'ProcessTime', sortable: true, filter: true },
  ];

  constructor(private router: Router,private fileUploadService:ASFileUploadService, public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  shortLink: string = "";
  loading: boolean = false; 
  file: File = null; 

  ngOnInit(): void {

    this.ASFileUpload=new ASFileUpload();

    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.ASFileUpload.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.ASFileUpload.tenantId = this.userModelList["tenant_id"];
    this.ASFileUpload.groupId = this.userModelList["group_id"];
    this.ASFileUpload.entityId = this.userModelList["entity_id"];
    this.ASFileUpload.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.ASFileUpload.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];

    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));

    this.ASFileUpload.processingLayerId = 500;
    this.ASFileUpload.uploadType = "Empty";
    // this.getProcessingLayerList();
    // this.selectProcessingLayer = {
    //   "processing_layer_id" : 0
    // };
    this.getFileUploadList();
    this.fileType = {
      "file_id": 0
    }

    this.fileUploadList = [
      {"file_id": "1", "file_name": "Form 26AS", "upload_type": "26AS"},
      {"file_id": "2", "file_name": "Form 26AS PASSWORD", "upload_type": "PWD"},
      {"file_id": "3", "file_name": "SALES REGISTER","upload_type": "SR"},
      {"file_id": "4", "file_name": "CUSTOMER NATIONAL ACCOUNT DETAILS", "upload_type": "NAD"},
      {"file_id": "5", "file_name": "ACCPAC", "upload_type": "TDS"},
      {"file_id": "6", "file_name": "ERP TAN UPDATE", "upload_type": "TAN"}
    ]

    this.pagination=true;
    this.paginationSize = 15;
    this.file_records=[];
    this.fromDate = "Empty";
    this.toDate = "Empty";

    this.getFileUploadedList();
  }

  getFileName(uploadType)
  {
    for(var i=0; i<this.fileUploadList.length; i++)
    {
      if (this.fileUploadList[i]["upload_type"] == uploadType)
      {
        return this.fileUploadList[i]["file_name"];
      }
    }
  }

  getFileUploadList()
  {
    this.ngxService.start();
    let Indata={
      "tenantId": this.ASFileUpload.tenantId,
      "groupId": this.ASFileUpload.groupId,
      "entityId": this.ASFileUpload.entityId,
      "userId": this.ASFileUpload.userId,
      "mProcessingLayerId": this.ASFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId": this.ASFileUpload.mProcessingSubLayerId
    }
    console.log("fileuploadlistdata",Indata);
    this.fileUploadService.getFileListFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("filelistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.fileuploadlist=this.sourcedata.recon_file_upload_list;
      console.log("FIle Upload List ",this.fileuploadlist);
      this.rowData = this.fileuploadlist;
      this.file_records = this.fileuploadlist;
      this.ngxService.stop();
  });

}

public getFileType(file_id)
{
  if (file_id == 0)
  {
    this.ASFileUpload.uploadType = "Empty";
  }
  else if (file_id == 1)
  {
    this.ASFileUpload.uploadType = "26AS";
  }
  else if (file_id == 2)
  {
    this.ASFileUpload.uploadType = "PWD";
  }
  else if (file_id == 3)
  {
    this.ASFileUpload.uploadType = "SR";
  }
  else if (file_id == 4)
  {
    this.ASFileUpload.uploadType = "NAD";
  }
  else if (file_id == 5)
  {
    this.ASFileUpload.uploadType = "TDS";
  }
  else if (file_id == 6)
  {
    this.ASFileUpload.uploadType = "TAN";
  }
}

onChange(event) {
    this.file = event.target.files[0];
}

public extFileOnChanged(event:any) {
  let files = event.target.files;
  this.ASFileUpload.externalFileName = files[0];
  console.log(files);
  console.log(this.ASFileUpload.externalFileName);
  console.log(this.ASFileUpload.externalFileName.name.split("."));
}

public uploadAll(){

  if (this.ASFileUpload.uploadType == "Empty" || this.fromDate == "Empty" || this.toDate == "Empty")
  {
    alert("Kindly choose the File Type, From Date and To Date!!!");
  }
  else if (this.ASFileUpload.uploadType == "26AS")
  {
    if (this.ASFileUpload.externalFileName.name.split(".")[1] === "zip")
    {
      this.getFileUpload();
    }
    else
    {
      let message = "Kindly choose the Proper Zip File for " + this.getFileName(this.ASFileUpload.uploadType) + " !!!";
      alert(message);
    }
  }
  else if (this.ASFileUpload.uploadType == "PWD")
  {
    if (this.ASFileUpload.externalFileName.name.split(".")[1] === "txt")
    {
      this.getFileUpload();
    }
    else
    {
      let message = "Kindly choose the Proper Text File for " + this.getFileName(this.ASFileUpload.uploadType) + " !!!";
      alert(message);
    }
  }
  else if (this.ASFileUpload.uploadType == "SR" || this.ASFileUpload.uploadType == "NAD" || this.ASFileUpload.uploadType == "TDS")
  {
    if (this.ASFileUpload.externalFileName.name.split(".")[1] === "xls" || this.ASFileUpload.externalFileName.name.split(".")[1] === "xlsx" || this.ASFileUpload.externalFileName.name.split(".")[1] === "xlsb")
    {
      this.getFileUpload();
    }
    else
    {
      let message = "Kindly choose the Proper Excel File for " + this.getFileName(this.ASFileUpload.uploadType) + " !!!";
      alert(message);
    }
  }
  else if (this.ASFileUpload.uploadType == "TAN")
  {
    if (this.ASFileUpload.externalFileName.name.split(".")[1] === "csv")
    {
      this.getFileUpload();
    }
    else
    {
      let message = "Kindly choose the Proper CSV File for " + this.getFileName(this.ASFileUpload.uploadType) + " !!!";
      alert(message);
    }
  }
  
}

public getFileUpload(){
    this.ngxService.start();

    const formData = new FormData();

    formData.append("externalFileName ", this.ASFileUpload.externalFileName);
    formData.append("processingLayerId", this.ASFileUpload.processingLayerId);
    formData.append("tenantId", this.ASFileUpload.tenantId);
    formData.append("groupId", this.ASFileUpload.groupId);
    formData.append("entityId", this.ASFileUpload.entityId);
    formData.append("mProcessingLayerId", this.ASFileUpload.mProcessingLayerId);
    formData.append("mProcessingSubLayerId", this.ASFileUpload.mProcessingSubLayerId);
    formData.append("userId", this.ASFileUpload.userId);
    formData.append("fileUploaded", this.ASFileUpload.uploadType);
    formData.append("fromDate", this.fromDate);
    formData.append("toDate", this.toDate);

    this.fileupload = formData;

    console.log("Data  ",this.fileupload);
    this.fileUploadService.postFileToServer(this.fileupload)
      .subscribe(
      recieveddata  => {   
        let tempresponsedata = recieveddata;
        console.log("Fileuploadresponse---", tempresponsedata)
        this.fileupload="";
        this.fileupload = tempresponsedata;
        if(this.fileupload.Status === "Success")
        {
          alert("File Uploaded Successfully!!!");
          this.externalFileInput.nativeElement.value = '';
          this.ASFileUpload.externalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
        }
        else if(this.fileupload.Status === "Error")
        {
          alert("Error in Upload File. Kindly Contact Advents Support!!!");
          this.externalFileInput.nativeElement.value = '';
          this.ASFileUpload.externalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
        }
        else if(this.fileupload.Status === "File Exists")
        {
          alert("File already exists in Batch for the choosen Relationship Type. Kindly Upload after some time!!!");
          this.externalFileInput.nativeElement.value = '';
          this.ASFileUpload.externalFileName = undefined;
          this.getFileUploadedList();
          this.ngxService.stop();
        }
      },
      (error: any) => { 
        this.HandleErrorResponse(error);
        this.externalFileInput.nativeElement.value = '';
        this.ASFileUpload.externalFileName = undefined;
        this.getFileUploadedList();
        this.ngxService.stop();
    });
}

getFileUploadedList(){

  let data = {
    "tenantId": this.ASFileUpload.tenantId,
    "groupId": this.ASFileUpload.groupId,
    "entityId": this.ASFileUpload.entityId,
    "mProcessingLayerId": this.ASFileUpload.mProcessingLayerId,
    "mProcessingSubLayerId": this.ASFileUpload.mProcessingSubLayerId,
    "userId": this.ASFileUpload.userId
  };

  this.fileUploadService.getFileListFromServer(data)
  .subscribe(
    receivedData => {
      let responseData = receivedData;
      console.log("File Data Response, ", responseData);
      if (responseData["Status"] === "Success")
      {
        let fileUploadListData = responseData["file_upload_data_list"];
        console.log(fileUploadListData);
        let fileColumnDefs = fileUploadListData["headers"];

        fileColumnDefs.forEach((item, index) =>
        {
          if(item.sortable=="true")
          {
            item.sortable=true;
            item.filter=true;
            item.resizable=true;
            item.suppressAutoSize=true;
            item.suppressSizeToFit=true;
          }
        });
        this.fileColumnDefs = fileColumnDefs;
        this.fileRowData = fileUploadListData["data"];
      }
      else if(responseData["Status"] === "Error")
      {
        console.log("Error in Getting File Uploaded Data List!!!")
      }
    }
  )
}

refreshFileUploadList()
{
  this.getFileUploadedList();
}


HandleErrorResponse(err: any)
{
  console.log("Error",err);
}

previewconsoldoc(doc)
{

}

onRowSelected(event)
{

}

}
