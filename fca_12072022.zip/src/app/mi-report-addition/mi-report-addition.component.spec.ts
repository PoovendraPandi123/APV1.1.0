import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiReportAdditionComponent } from './mi-report-addition.component';

describe('MiReportAdditionComponent', () => {
  let component: MiReportAdditionComponent;
  let fixture: ComponentFixture<MiReportAdditionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiReportAdditionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiReportAdditionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
