import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsNadReportComponent } from './as-nad-report.component';

describe('AsNadReportComponent', () => {
  let component: AsNadReportComponent;
  let fixture: ComponentFixture<AsNadReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsNadReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsNadReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
