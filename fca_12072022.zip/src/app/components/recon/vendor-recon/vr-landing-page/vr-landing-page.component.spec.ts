import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrLandingPageComponent } from './vr-landing-page.component';

describe('VrLandingPageComponent', () => {
  let component: VrLandingPageComponent;
  let fixture: ComponentFixture<VrLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
