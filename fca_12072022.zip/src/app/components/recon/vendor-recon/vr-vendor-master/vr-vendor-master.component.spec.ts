import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrVendorMasterComponent } from './vr-vendor-master.component';

describe('VrVendorMasterComponent', () => {
  let component: VrVendorMasterComponent;
  let fixture: ComponentFixture<VrVendorMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrVendorMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrVendorMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
