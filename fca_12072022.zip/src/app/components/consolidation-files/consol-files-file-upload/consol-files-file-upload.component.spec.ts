import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesFileUploadComponent } from './consol-files-file-upload.component';

describe('ConsolFilesFileUploadComponent', () => {
  let component: ConsolFilesFileUploadComponent;
  let fixture: ComponentFixture<ConsolFilesFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesFileUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
