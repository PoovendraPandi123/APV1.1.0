import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsNationalAccountDetailsComponent } from './as-national-account-details.component';

describe('AsNationalAccountDetailsComponent', () => {
  let component: AsNationalAccountDetailsComponent;
  let fixture: ComponentFixture<AsNationalAccountDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsNationalAccountDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsNationalAccountDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
