import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessingLayerDefinitionsComponent } from './processing-layer-definitions.component';

describe('ProcessingLayerDefinitionsComponent', () => {
  let component: ProcessingLayerDefinitionsComponent;
  let fixture: ComponentFixture<ProcessingLayerDefinitionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProcessingLayerDefinitionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessingLayerDefinitionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
