import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiReportExplicitComponent } from './mi-report-explicit.component';

describe('MiReportExplicitComponent', () => {
  let component: MiReportExplicitComponent;
  let fixture: ComponentFixture<MiReportExplicitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiReportExplicitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MiReportExplicitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
