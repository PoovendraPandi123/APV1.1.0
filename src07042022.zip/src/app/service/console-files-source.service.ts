import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class ConsoleFilesSourceService {

  public port : string = '50012';

  constructor(private CS: CommonService) { }

  public postSourceToServer(prminputs : any) : any {
    var resData = CommonService.authReq(this.port+'/api/v1/consol_files/source/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getSourceListFromServer(prminputs : any) : any {
    var resData = CommonService.authReq(this.port+'/api/v1/consol_files/source/');
    return this.CS.SendToAPI("get", resData, prminputs);
  }

}
