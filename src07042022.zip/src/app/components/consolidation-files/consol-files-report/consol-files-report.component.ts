import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-report',
  templateUrl: './consol-files-report.component.html',
  styleUrls: ['./consol-files-report.component.css']
})
export class ConsolFilesReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
