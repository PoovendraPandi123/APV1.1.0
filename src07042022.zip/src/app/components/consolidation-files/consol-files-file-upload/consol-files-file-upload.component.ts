import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-file-upload',
  templateUrl: './consol-files-file-upload.component.html',
  styleUrls: ['./consol-files-file-upload.component.css']
})
export class ConsolFilesFileUploadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
