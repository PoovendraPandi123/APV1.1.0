import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {Router} from '@angular/router';
import { MIFileUploadService } from '../service/mi-file-upload.service';
import { HttpClient  } from '@angular/common/http';
import { MIFileUpload } from './mi-file-upload.model';
import {Observable} from 'rxjs';
import { AuthService } from '../service/auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AgGridAngular } from 'ag-grid-angular';

@Component({
  selector: 'app-mi-file-upload',
  templateUrl: './mi-file-upload.component.html',
  styleUrls: ['./mi-file-upload.component.css']
})
export class MiFileUploadComponent implements OnInit {

  @ViewChild('externalFileInput', {static: false})
  externalFileInput: ElementRef;

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userdtl;
  public sourcedata;
  public processinglayerlist;
  public objprocessid;
  public fileupload;
  public fileuploadlist;

  public paginationSize;
  public file_records;
  public pagination;
  rowData: Observable<any[]>;
  public fileData;

  public userModelList :  any;
  public processingLayerIdsUser :  any;
  public selectProcessingLayer : any;
  public fileUploaded : any;
  public fileRowData : any;
  public fileColumnDefs :  any;

  public fileType: any;
  public fileUploadList: any;

  public fromDate: any;

  MIFileUpload:MIFileUpload;

  constructor(private router: Router,private fileUploadService:MIFileUploadService, public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  shortLink: string = "";
  loading: boolean = false; 
  file: File = null; 

  ngOnInit(): void {

    this.MIFileUpload=new MIFileUpload();

    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.MIFileUpload.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.MIFileUpload.tenantId = this.userModelList["tenant_id"];
    this.MIFileUpload.groupId = this.userModelList["group_id"];
    this.MIFileUpload.entityId = this.userModelList["entity_id"];
    this.MIFileUpload.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.MIFileUpload.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];

    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));

    this.MIFileUpload.processingLayerId = 600;
    this.MIFileUpload.uploadType = "Empty";
    // this.getProcessingLayerList();
    // this.selectProcessingLayer = {
    //   "processing_layer_id" : 0
    // };
    this.getFileUploadList();
    this.fileType = {
      "file_id": 0
    }

    this.fileUploadList = [
      {"file_id": "1", "file_name": "MIS", "upload_type": "MIS"},
      {"file_id": "2", "file_name": "PAYROLL REGISTER", "upload_type": "PR"},
      {"file_id": "3", "file_name": "EXIT REPORT","upload_type": "ER"},
      {"file_id": "4", "file_name": "TPA CLAIM CONFIRMATION REPORT", "upload_type": "TCR"},
      // {"file_id": "5", "file_name": "INSURER ENDORSEMENT REPORT", "upload_type": "IER"},
      {"file_id": "5", "file_name": "GPA DEATH CASE TRACKER", "upload_type": "GDT"},
    ]

    this.pagination=true;
    this.paginationSize = 15;
    this.file_records=[];

    this.fromDate = 'Empty';

    this.getFileUploadedList();

  }

  getFileName(uploadType)
  {
    for(var i=0; i<this.fileUploadList.length; i++)
    {
      if (this.fileUploadList[i]["upload_type"] == uploadType)
      {
        return this.fileUploadList[i]["file_name"];
      }
    }
  }

  getFileUploadedList(){

    let data = {
      "tenantId": this.MIFileUpload.tenantId,
      "groupId": this.MIFileUpload.groupId,
      "entityId": this.MIFileUpload.entityId,
      "mProcessingLayerId": this.MIFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId": this.MIFileUpload.mProcessingSubLayerId,
      "userId": this.MIFileUpload.userId
    };
  
    this.fileUploadService.getFileListFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("File Data Response, ", responseData);
        if (responseData["Status"] === "Success")
        {
          let fileUploadListData = responseData["file_upload_data_list"];
          console.log(fileUploadListData);
          let fileColumnDefs = fileUploadListData["headers"];
  
          fileColumnDefs.forEach((item, index) =>
          {
            if(item.sortable=="true")
            {
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
            }
          });
          this.fileColumnDefs = fileColumnDefs;
          this.fileRowData = fileUploadListData["data"];
        }
        else if(responseData["Status"] === "Error")
        {
          console.log("Error in Getting File Uploaded Data List!!!")
        }
      }
    )
  }


  getFileUploadList()
  {
    this.ngxService.start();
    let Indata={
      "tenantId": this.MIFileUpload.tenantId,
      "groupId": this.MIFileUpload.groupId,
      "entityId": this.MIFileUpload.entityId,
      "userId": this.MIFileUpload.userId,
      "mProcessingLayerId": this.MIFileUpload.mProcessingLayerId,
      "mProcessingSubLayerId": this.MIFileUpload.mProcessingSubLayerId
    }
    console.log("fileuploadlistdata",Indata);
    this.fileUploadService.getFileListFromServer(Indata)
    .subscribe(
      recieveddata  => {
        let tempresponsedata = recieveddata;
        console.log("filelistresponse---",tempresponsedata)
        this.sourcedata=tempresponsedata;
        this.fileuploadlist=this.sourcedata.recon_file_upload_list;
        console.log("FIle Upload List ",this.fileuploadlist);
        this.rowData = this.fileuploadlist;
        this.file_records = this.fileuploadlist;
        this.ngxService.stop();
    });
  }

  public getFileType(file_id)
  {
    if (file_id == 0)
    {
      this.MIFileUpload.uploadType = "Empty";
    }
    else if (file_id == 1)
    {
      this.MIFileUpload.uploadType = "MIS";
    }
    else if (file_id == 2)
    {
      this.MIFileUpload.uploadType = "PR";
    }
    else if (file_id == 3)
    {
      this.MIFileUpload.uploadType = "ER";
    }
    else if (file_id == 4)
    {
      this.MIFileUpload.uploadType = "TCR";
    }
    else if (file_id == 5)
    {
      this.MIFileUpload.uploadType = "GDT";
    }
  }

onChange(event) {
  this.file = event.target.files[0];
}

public extFileOnChanged(event:any) {
  let files = event.target.files;
  this.MIFileUpload.externalFileName = files[0];
  // console.log(files);
  // console.log(this.MIFileUpload.externalFileName);
  // console.log(this.MIFileUpload.externalFileName.name.split("."));
}

public uploadAll(){

  // console.log(this.fromDate);

  if (this.MIFileUpload.uploadType == "Empty" || this.fromDate === "Empty")
  {
    alert("Kindly choose the File Type and Reconciliation Month!!!");
  }
  else if (this.MIFileUpload.uploadType == "MIS" || this.MIFileUpload.uploadType == "PR" || this.MIFileUpload.uploadType == "ER" || this.MIFileUpload.uploadType == "TCR")
  {
    if (this.MIFileUpload.externalFileName.name.split(".")[this.MIFileUpload.externalFileName.name.split(".").length - 1] === "xls" || this.MIFileUpload.externalFileName.name.split(".")[this.MIFileUpload.externalFileName.name.split(".").length - 1] === "xlsx" || this.MIFileUpload.externalFileName.name.split(".")[this.MIFileUpload.externalFileName.name.split(".").length - 1] === "xlsb")
    {
      this.getFileUpload();
    }
    else
    {
      let message = "Kindly choose the Proper Excel File for " + this.getFileName(this.MIFileUpload.uploadType) + " !!!";
      alert(message);
    }
  }
  else if (this.MIFileUpload.uploadType == "GDT")
  {
    if (this.MIFileUpload.externalFileName.name.split(".")[this.MIFileUpload.externalFileName.name.split(".").length - 1] === "xlsx")
    {
      this.getFileUpload();
    }
    else
    {
      let message = "Kindly choose the Proper Excel File for " + this.getFileName(this.MIFileUpload.uploadType) + " !!!";
      alert(message);
    }
  }
  
}

public getFileUpload(){
  
  this.ngxService.start();

  const formData = new FormData();

  formData.append("externalFileName ", this.MIFileUpload.externalFileName);
  formData.append("processingLayerId", this.MIFileUpload.processingLayerId);
  formData.append("tenantId", this.MIFileUpload.tenantId);
  formData.append("groupId", this.MIFileUpload.groupId);
  formData.append("entityId", this.MIFileUpload.entityId);
  formData.append("mProcessingLayerId", this.MIFileUpload.mProcessingLayerId);
  formData.append("mProcessingSubLayerId", this.MIFileUpload.mProcessingSubLayerId);
  formData.append("userId", this.MIFileUpload.userId);
  formData.append("fileUploaded", this.MIFileUpload.uploadType);
  formData.append("fromDate", this.fromDate);

  this.fileupload = formData;

  console.log("Data  ",this.fileupload);
  this.fileUploadService.postFileToServer(this.fileupload)
    .subscribe(
    recieveddata  => {   
      let tempresponsedata = recieveddata;
      console.log("Fileuploadresponse---", tempresponsedata)
      this.fileupload="";
      this.fileupload = tempresponsedata;
      if(this.fileupload.Status === "Success")
      {
        alert("File Uploaded Successfully!!!");
        this.externalFileInput.nativeElement.value = '';
        this.MIFileUpload.externalFileName = undefined;
        this.getFileUploadedList();
        this.ngxService.stop();
      }
      else if(this.fileupload.Status === "Error")
      {
        alert("Error in Upload File. Kindly Contact Advents Support!!!");
        this.externalFileInput.nativeElement.value = '';
        this.MIFileUpload.externalFileName = undefined;
        this.getFileUploadedList();
        this.ngxService.stop();
      }
      else if(this.fileupload.Status === "File Exists")
      {
        alert("File already exists in Batch for the choosen Relationship Type. Kindly Upload after some time!!!");
        this.externalFileInput.nativeElement.value = '';
        this.MIFileUpload.externalFileName = undefined;
        this.getFileUploadedList();
        this.ngxService.stop();
      }
    },
    (error: any) => { 
      this.HandleErrorResponse(error);
      this.externalFileInput.nativeElement.value = '';
      this.MIFileUpload.externalFileName = undefined;
      this.getFileUploadedList();
      this.ngxService.stop();
  });
}

refreshFileUploadList()
{
  this.getFileUploadedList();
}


HandleErrorResponse(err: any)
{
  console.log("Error",err);
}

}

