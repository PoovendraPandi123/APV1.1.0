export const environment = {
  production: true,
  envName: 'dev',
  host: "https://ecourt.azurewebsites.net",
  
    cdnhost: "http://154.61.75.57:",
  // cdnhost: "http://127.0.0.1:",
 
  uploadFileNativePath:"./assets/UploadedFiles/"
};
