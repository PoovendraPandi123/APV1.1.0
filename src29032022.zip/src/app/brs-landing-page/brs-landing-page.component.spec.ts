import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrsLandingPageComponent } from './brs-landing-page.component';

describe('BrsLandingPageComponent', () => {
  let component: BrsLandingPageComponent;
  let fixture: ComponentFixture<BrsLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrsLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrsLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
