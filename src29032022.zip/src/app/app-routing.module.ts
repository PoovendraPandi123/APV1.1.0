import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrsLandingPageComponent } from './brs-landing-page/brs-landing-page.component';
import { ModulelistComponent } from './modulelist/modulelist.component';
import { PoIssueLandingPageComponent } from './po-issue-landing-page/po-issue-landing-page.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { SigninComponent } from './signin/signin.component';
import { SourceComponent } from './source/source.component';
import { TaskManagementLandingPageComponent } from './task-management-landing-page/task-management-landing-page.component';
import { TdsReconLandingPageComponent } from './tds-recon-landing-page/tds-recon-landing-page.component';
import { VendorPaymentsLandingPageComponent } from './vendor-payments-landing-page/vendor-payments-landing-page.component';
import { AlcsFileUploadComponent } from './components/alcs/alcs-file-upload/alcs-file-upload.component';
import { AlcsClientsComponent } from './components/alcs/alcs-clients/alcs-clients.component';
import { AlcsDashboardComponent } from './components/alcs/alcs-dashboard/alcs-dashboard.component';
import { AlcsReportComponent } from './components/alcs/alcs-report/alcs-report.component';
import { AlcsOperationsComponent } from './components/alcs/alcs-operations/alcs-operations.component';
import { ConsolFilesFileUploadComponent } from './components/consolidation-files/consol-files-file-upload/consol-files-file-upload.component';
import { ConsolFilesProcessComponent } from './components/consolidation-files/consol-files-process/consol-files-process.component';
import { ConsolFilesReportComponent } from './components/consolidation-files/consol-files-report/consol-files-report.component';
import { ConsolFilesDraftReportComponent } from './components/consolidation-files/consol-files-draft-report/consol-files-draft-report.component';
import { ConsolFilesDashboardComponent } from './components/consolidation-files/consol-files-dashboard/consol-files-dashboard.component';
import { ConsolFilesSourceComponent } from './components/consolidation-files/consol-files-source/consol-files-source.component';
import { ConsolFilesSourceDefinitionComponent } from './components/consolidation-files/consol-files-source-definition/consol-files-source-definition.component';
import { ConsolFilesTargetFilesComponent } from './components/consolidation-files/consol-files-target-files/consol-files-target-files.component';

const routes: Routes = [
  { path: '', redirectTo: '/SignIn', pathMatch: 'full' },
  {path:'SignIn', component:SigninComponent},
  {path:'ModuleList', component:ModulelistComponent},
  {path:'SideMenu', component:SideMenuComponent},
  {path:'BrsLandingPage', component:BrsLandingPageComponent},
  {path:'PoLandingPage', component:PoIssueLandingPageComponent},
  {path:'TaskManagementLangingPage', component:TaskManagementLandingPageComponent},
  {path:'VendorPaymentsLandingPage', component:VendorPaymentsLandingPageComponent},
  {path:'TdsLandingPage', component:TdsReconLandingPageComponent},
  {path:'BrsSource', component:SourceComponent},
  {
    path:'SideMenu', component:SideMenuComponent,
    children: [
      {path: 'AlcsFileUpload', component:AlcsFileUploadComponent},
      {path: 'AlcsClients', component:AlcsClientsComponent},
      {path: 'AlcsDashboard', component:AlcsDashboardComponent},
      {path: 'AlcsReport', component:AlcsReportComponent},
      {path: 'AlcsOperations', component:AlcsOperationsComponent},
      {path: 'ConsolidationFileUpload', component:ConsolFilesFileUploadComponent},
      {path: 'ConsolidationProcess', component:ConsolFilesProcessComponent},
      {path: 'ConsolidationReport', component:ConsolFilesReportComponent},
      {path: 'ConsolidationDraftReport', component:ConsolFilesDraftReportComponent},
      {path: 'ConsolFilesDashboard', component:ConsolFilesDashboardComponent},
      {path: 'ConsolidationSource', component:ConsolFilesSourceComponent},
      {path: 'ConsolidationSourceDefinition', component:ConsolFilesSourceDefinitionComponent},
      {path: 'ConsolidationTargetFiles', component:ConsolFilesTargetFilesComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
