import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { SourcedefinitionService } from '../service/sourcedefinition.service';
import { HttpClient  } from '@angular/common/http';
import { ViewChild,ElementRef } from '@angular/core';
declare const $: any;

@Component({
  selector: 'app-source-definition',
  templateUrl: './source-definition.component.html',
  styleUrls: ['./source-definition.component.css']
})
export class SourceDefinitionComponent implements OnInit {

  public cardTitle;
  public userdtl;
  public user;
  public sourcedata;
  public sourcelist;
  public sourcedefinitionlist: Array<any> = [];
  public newsourcedefinitionlist;
  public objsource;
  public operationflag;
  public sourceview;
  public sourcedefinition;
  public editBtnshow;
  public sourcedefinitionview;
  public fileupload;

  constructor(private router: Router,private objservice:SourcedefinitionService,public http:HttpClient) { }

  @ViewChild('fileInput') fileInput: ElementRef;


  ngOnInit() {
    this.userdtl=JSON.parse(sessionStorage.getItem('user_details'));
    this.user=JSON.parse(localStorage.getItem('Userdtl'));
    console.log("userdtl",this.user);
    this.objsource={"source_id":0};
   this.operationflag="SND"
   //this.sourceview=false;
   this.userdtl.tenant_id=1;
   this.userdtl.group_id=1;
   this.userdtl.entity_id=1;
   this.userdtl.module_id=1;
   this.userdtl.user_id=1;


    this.getsourcelist();
  }

  list(){
    this.operationflag="SD"
    this.sourceview=true;
    this.sourcedefinitionlist=[];
    this.getsourcelist();
    this.fileInput.nativeElement.value = null;
  }
  backlist(){
    this.operationflag="SND"
    this.sourceview=false;
    this.sourcedefinitionlist=[];
    this.getsourcelist();
  }

  cancelEdit(){

  }

  getsourcelist(){
    let Indata={
      "tenant_id":  this.userdtl.tenant_id,
      "group_id":   this.userdtl.group_id,
      "entity_id":  this.userdtl.entity_id,
      "module_id":  this.userdtl.module_id,
      "operation_flag":this.operationflag   
    }
    console.log("inputsource",Indata);
    this.objservice.getsourceFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourcelistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.sourcelist=this.sourcedata.sources_list;
      console.log("Sourcelist---",this.sourcelist)

    });
  }

  editsourcedefinitionlist(){
   // this.sourceview=false;
  }

  
  sourceselection(param){

    console.log("flag",this.operationflag);
    if(this.operationflag=="SD"){
    let Indata={
      "tenant_id": this.userdtl.tenant_id,
      "group_id": this.userdtl.group_id,
      "entity_id": this.userdtl.entity_id,
      "source_id": param    
    }
    console.log("inputsource",Indata);
    this.objservice.getsourcedefinitionFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourcedefinitionlistresponse---",tempresponsedata)
      
      this.sourcedefinition=tempresponsedata;
       this.sourcedefinitionlist=this.sourcedefinition.sources_list;
       setTimeout(() => {
        this.loadData();

           }, 300);
     
      console.log("Sourcelist---",this.sourcedefinitionlist)

    });
  }
  else{
    this.sourcedefinitionlist=[];   
  }
}

validateFile(name: String) {
  var ext = name.substring(name.lastIndexOf('.') + 1);
  if (ext.toLowerCase() == 'csv' || ext.toLowerCase() == 'xlsb'|| ext.toLowerCase() == 'txt'|| ext.toLowerCase() == 'xlsx') {
      return true;
  }
  else {
      return false;
  }
}


upload(files){
  console.log("sourceid",files[0]);
  if (!this.validateFile(files[0].name)) {
    alert('Selected file format is not supported');   
    return false;
}
  const formData = new FormData();
  formData.append("m_source_file", files[0]);
  formData.append("source_id", this.objsource.source_id);
  formData.append("tenant_id", this.userdtl.tenant_id);
  formData.append("group_id", this.userdtl.group_id);
  formData.append("entity_id", this.userdtl.entity_id);
  // formData.append("module_id", this.userdtl.module_id);
  formData.append("user_id", this.user.user_id);

  this.fileupload=formData;    
}

savesourcefile(){
  console.log("savesourcedefinitionfile",this.fileupload);
  this.objservice.postFileToServer(this.fileupload)
  .subscribe(
  recieveddata  => {   
      let tempresponsedata = recieveddata;
    console.log("Fileuploadresponse---",tempresponsedata)
    // this.fileupload="";
  this.fileupload=tempresponsedata;
  if(this.fileupload.Status=="Success"){
this.sourcedefinitionfileload();
  }
 
  },
  (error: any) => { this.HandleErrorResponse(error) });
}
sourcedefinitionfileload(){
  let Indata={
    "source_id": this.objsource.source_id,
    "tenant_id": this.userdtl.tenant_id,
    "group_id": this.userdtl.group_id,
    "entity_id": this.userdtl.entity_id,
    "user_id": this.userdtl.user_id,
    }
    console.log("inputfileloadforsourcedef",Indata);
    this.objservice.getsourcedefinitionfiledataFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("outputfileloadforsourcedef---",tempresponsedata)
      this.sourcedefinition=tempresponsedata;
      this.sourcedefinitionlist=this.sourcedefinition.data_header;
      setTimeout(() => {
        this.loadData();
           }, 300);

    });

}

  savesourcedefinitionlist(){   
this.senddatatoserver();   
  }

  senddatatoserver(){
    let Indata={
      "tenant_id": this.userdtl.tenant_id,
      "group_id": this.userdtl.group_id,
      "entity_id": this.userdtl.entity_id,
      "user_id": this.userdtl.user_id,     
      "source_id": this.objsource.source_id,
      "source_attributes": this.sourcedefinitionlist,
       }

    console.log("inputsavesource",Indata);
    this.objservice.postsourcedefinitionFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourceresponse---",tempresponsedata)
    // this.objsource= new Source();
this.list();
    });
  }

    private loadData() {

    if ($.fn.dataTable.isDataTable('#tablesourceExport')) {
      $('#tablesourceExport').DataTable();
    }
    else {
      $('#tablesourceExport').DataTable({
        buttons: [],
        "pageLength": 10,
        "paging": true,
        "bFilter": true,
        "bInfo": true,
        "order": [], //to disable inital sort
        drawCallback: () => {
         
         }
      });
    }
  }
  
  HandleErrorResponse(err: any)
  {
   console.log("Error",err);
  }

}
