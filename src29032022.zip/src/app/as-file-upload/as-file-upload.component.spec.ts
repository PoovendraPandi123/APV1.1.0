import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsFileUploadComponent } from './as-file-upload.component';

describe('AsFileUploadComponent', () => {
  let component: AsFileUploadComponent;
  let fixture: ComponentFixture<AsFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsFileUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
