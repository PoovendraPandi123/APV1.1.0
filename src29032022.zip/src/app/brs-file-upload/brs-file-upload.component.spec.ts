import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrsFileUploadComponent } from './brs-file-upload.component';

describe('BrsFileUploadComponent', () => {
  let component: BrsFileUploadComponent;
  let fixture: ComponentFixture<BrsFileUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrsFileUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrsFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
