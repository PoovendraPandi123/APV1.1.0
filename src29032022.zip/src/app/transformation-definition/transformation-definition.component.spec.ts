import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransformationDefinitionComponent } from './transformation-definition.component';

describe('TransformationDefinitionComponent', () => {
  let component: TransformationDefinitionComponent;
  let fixture: ComponentFixture<TransformationDefinitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransformationDefinitionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransformationDefinitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
