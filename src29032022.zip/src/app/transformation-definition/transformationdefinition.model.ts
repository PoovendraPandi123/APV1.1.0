export class Transformationdefinition {
        public attributes_names:Array<attributes_names>=[];
        public field_extraction_operators: Array<field_extraction_operators> = [];
        public delimiter_operators: Array<delimiter_operators> = [];
        public custom_operators: Array<custom_operators> = [];
        public transaction_operators: Array<transaction_operators> = [];

    constructor(   
        ) {  }

  }

  export class attributes_names{
    constructor(
        public source_definition_id: number=0,
        public attribute_name: string='',
           
          ) {  }
  }

  export class field_extraction_operators {

    constructor(
      public operator_type=[],
         
        ) {  }

  }
  export class delimiter_operators {

    constructor(
      public operators=[],
         
        ) {  }

  }
  export class custom_operators {

    constructor(
      public operators=[],
         
        ) {  }

  }
  export class transaction_operators {

    constructor(
      public operators=[],
         
        ) {  }

  }
