import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsolFilesDashboardComponent } from './consol-files-dashboard.component';

describe('ConsolFilesDashboardComponent', () => {
  let component: ConsolFilesDashboardComponent;
  let fixture: ComponentFixture<ConsolFilesDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsolFilesDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsolFilesDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
