import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-source',
  templateUrl: './consol-files-source.component.html',
  styleUrls: ['./consol-files-source.component.css']
})
export class ConsolFilesSourceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
