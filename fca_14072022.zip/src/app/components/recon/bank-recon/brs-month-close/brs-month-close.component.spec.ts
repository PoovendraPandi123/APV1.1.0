import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrsMonthCloseComponent } from './brs-month-close.component';

describe('BrsMonthCloseComponent', () => {
  let component: BrsMonthCloseComponent;
  let fixture: ComponentFixture<BrsMonthCloseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrsMonthCloseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrsMonthCloseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
