import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brs-landing-page',
  templateUrl: './brs-landing-page.component.html',
  styleUrls: ['./brs-landing-page.component.css']
})
export class BrsLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
