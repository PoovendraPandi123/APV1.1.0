export interface ITargetDefinitions {
    fieldName: string;
    fieldType: string;
    fieldPosition: number;
}