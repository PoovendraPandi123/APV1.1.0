import { TestBed } from '@angular/core/testing';

import { VrPeriodAssigmentService } from './vr-period-assigment.service';

describe('VrPeriodAssigmentService', () => {
  let service: VrPeriodAssigmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrPeriodAssigmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
