import { TestBed } from '@angular/core/testing';

import { ConsolFilesSourceDefinitionService } from './consol-files-source-definition.service';

describe('ConsolFilesSourceDefinitionService', () => {
  let service: ConsolFilesSourceDefinitionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesSourceDefinitionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
