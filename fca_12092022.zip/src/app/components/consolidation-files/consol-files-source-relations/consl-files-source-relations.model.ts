export interface ISourceRelations {
    sourceId: String
}