import { Component, OnInit } from '@angular/core';
import { ConsolFilesSourceRelationsService } from 'src/app/service/consol-files-source-relations.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ISourceRelations } from './consl-files-source-relations.model';

@Component({
  selector: 'app-consol-files-source-relations',
  templateUrl: './consol-files-source-relations.component.html',
  styleUrls: ['./consol-files-source-relations.component.css']
})
export class ConsolFilesSourceRelationsComponent implements OnInit {

  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public sourceList: any;
  public sourceRelationList: any;
  public sourceIdChosen: string;
  public isRelation: string;
  public relationIdChosen: string;
  public sourceRelationsList: ISourceRelations[];
  public isSourceRelationRequired: boolean[];
  public sourceRelationDisplay: boolean;

  constructor(private relationService: ConsolFilesSourceRelationsService, private ngxService: NgxUiLoaderService) { 
    this.sourceList = [];
    this.sourceRelationList = [];
    this.sourceIdChosen = '';
    this.isRelation = '';
    this.relationIdChosen = '';
    this.sourceRelationDisplay = false;
  }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.sourceIdChosen = '-1';
    this.isRelation = '-1';
    this.relationIdChosen = '-1';
    // this.getSourceList();
    this.getSourceRelationsList();
  }

  public getSourceList() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.relationService.getSourceListFromServer(data)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Source List Response ", responseData);
        this.sourceList = responseData;
        this.ngxService.stop();
      },
      error : (error : any) => {
        console.log("Source List Error Response ", error);
        this.ngxService.stop();
      }
    });

  }

  public getSourceRelationsList() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes",
      "is_related": "not"
    };

    this.relationService.getSourceRelationListFromServer(data)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Source Relation List Response ", responseData);
        this.sourceRelationList = responseData;
        this.ngxService.stop();
      },
      error : (error : any) => {
        console.log("Source Relation List Error response ", error);
        this.ngxService.stop();
      }
    })

  }

  public getDisplaySourceRelations() : void {
    this.isSourceRelationRequired = [true];
    this.sourceRelationsList = [{
      sourceId : "-1"
    }];
  }

  public isRelationChange() : void {
    // console.log("isRelation", this.isRelation);
    if (this.isRelation == "1")
    {
      this.sourceRelationDisplay = true;
      this.getSourceList();
    }
    else
    {
      this.sourceRelationDisplay = false;
    }
  }

  public saveButtonClick() : void {
    if (this.sourceIdChosen == "-1")
    {
      alert("Kindly Choose the Source Name!!!");
    }
    else if (this.isRelation == "-1")
    {
      alert("Kindly Choose the Source is Related or Not!!!");
    }
    else if (this.sourceIdChosen == this.relationIdChosen)
    {
      alert("Same Sources cannot be Related. Kindly choose another related source for the source Chosen!!!");
    }
    else
    {
      if (this.isRelation == "1")
      {
        if (this.relationIdChosen == "-1")
        {
          alert("Please Choose Related Source!!!");
        }
        else
        {
          this.updateSourceRelations();
        }
      }
      else if (this.isRelation == "0")
      {
        this.updateSources();
      };
    }
  }

  public updateSourceRelations() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "source_id": this.sourceIdChosen,
      "relation_id": this.relationIdChosen,
      "user_id": this.userId
    };

    this.relationService.getUpdateSourceRelationToServer(data)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Update Source Relation Response ", responseData);
        if (responseData["Status"] == "Success")
        {
          alert("Source Relations Updated Successfully!!!");
          this.getSourceRelationsList();
          this.relationIdChosen = "-1";
          this.isRelation = "-1";
          this.ngxService.stop();
        }
        else if (responseData["Status"] == "Error")
        {
          alert("Error in Updating Source Relation. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
      },
      error : (error : any) => {
        console.log("Error in Update Source Relation ", error);
        this.ngxService.stop();
      }
    })

  }

  public updateSources() : void {
    
    this.ngxService.start();

    let data = {
      "id": this.sourceIdChosen,
      "is_related": 0,
      "modified_by": this.userId
    };

    this.relationService.getUpdateSourceToServer(data)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Update Sources Response ", responseData);
        if ("id" in responseData)
        {
          alert("Source Updated Successfully as not Related to any Source!!!");
          this.getSourceRelationsList();
          this.relationIdChosen = "-1";
          this.isRelation = "-1";
          this.ngxService.stop();
        }
        else
        {
          alert("Error in Updating Source. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
      },
      error : (error : any) => {
        console.log("Error in Update Source ", error);
        this.ngxService.stop();
      }
    });
  }

}
