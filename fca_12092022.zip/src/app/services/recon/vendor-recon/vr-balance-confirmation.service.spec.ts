import { TestBed } from '@angular/core/testing';

import { VrBalanceConfirmationService } from './vr-balance-confirmation.service';

describe('VrBalanceConfirmationService', () => {
  let service: VrBalanceConfirmationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VrBalanceConfirmationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
