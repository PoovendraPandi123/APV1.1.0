import { Injectable } from '@angular/core';
import { ApiCallService } from './api-call.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConsolFilesSourceRelationsService {

  public port = "50012";
  // public port = "81/consolidationFiles";

  constructor(private http: HttpClient) { }

  public getSourceListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/generic/sources/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&is_active=${prminputs["is_active"]}`);
    return this.http.get(resData["url"], resData["headers"])
  };

  public getSourceRelationListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/generic/sources/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&is_active=${prminputs["is_active"]}&is_related=${prminputs["is_related"]}`);
    return this.http.get(resData["url"], resData["headers"]);
  };

  public getUpdateSourceRelationToServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port + '/api/v1/consol_files/get_update_source_relations/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }

  public getUpdateSourceToServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port + `/api/v1/consol_files/source/${prminputs["id"]}/`);
    return this.http.patch(resData["url"], prminputs, resData["headers"]);
  }

}
