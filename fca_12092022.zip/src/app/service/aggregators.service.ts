import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AggregatorsService {
  lstReturn: any;
  public  port="50003";
  // public  port1="10002";

  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  
  postaggregatorFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/aggregator_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getsourceFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
  getaggregatorFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/aggregator_list_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getsourcedefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_definitions_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

}
