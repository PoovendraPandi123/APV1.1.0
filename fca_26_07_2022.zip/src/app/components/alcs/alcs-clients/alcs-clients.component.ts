import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { HttpClient  } from '@angular/common/http';
import { AlcsAuthService } from 'src/app/service/alcs.auth.service';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

declare const $: any;

@Component({
  selector: 'app-alcs-clients',
  templateUrl: './alcs-clients.component.html',
  styleUrls: ['./alcs-clients.component.css']
})
export class AlcsClientsComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  @ViewChild('content') content : ElementRef;
  @ViewChild('sendEmail') sendEmail : ElementRef;

  public pagination : boolean;
  public paginationSize : number;
  public externalRowData : any;
  public externalColumnDefs : any;
  public gridView : boolean;
  public formDivision :  boolean;
  public topActionButton : boolean;
  public topDetails : boolean;
  public addDetails : boolean;
  public editDetails : boolean;
  public alcsClientId : string;
  public alcsClientName : string;
  public alcsEmailAddress : string;
  public alcsFrequency : string;
  public readOnly : boolean;
  public actionType : string;
  public clickedData : any;
  public userModelList : any;
  public tenantsId : number;
  public groupsId : number;
  public entitiesId : number;
  public mProcessingLayerId : number;
  public mProcessingSubLayerId : number;
  public userId : number;
  public closeResult : any;
  public paymentFromDate : string;
  public paymentToDate : string;

  constructor(public ngxService: NgxUiLoaderService, private alcsService: AlcsAuthService, private http: HttpClient, private modalService: NgbModal) 
  { 
    this.pagination = false;
    this.paginationSize = 0;
    this.externalRowData = [];
    this.externalColumnDefs = [];
    this.gridView = false;
    this.formDivision = false;
    this.topActionButton = false;
    this.topDetails = false;
    this.editDetails = false;
    this.addDetails = false;
    this.alcsClientId = '';
    this.alcsClientName = '';
    this.alcsEmailAddress = '';
    this.alcsFrequency = '';
    this.readOnly = false;
    this.actionType = '';
    this.clickedData = {};
    this.userModelList = {};
    this.tenantsId = 0;
    this.groupsId = 0;
    this.entitiesId = 0;
    this.userId = 0;
    this.closeResult = '';
    this.paymentFromDate = '';
    this.paymentToDate = '';
  }

  public ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    // console.log("User Model List", this.userModelList);
    this.tenantsId = this.userModelList['tenant_id'];
    this.groupsId = this.userModelList['group_id'];
    this.entitiesId = this.userModelList['entity_id'];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.getClientDetails();
    this.pagination = true;
    this.paginationSize = 15;
    this.gridView = true;
    this.topActionButton = true;
    this.topDetails = true;
    this.alcsFrequency = 'Choose...';

    this.externalColumnDefs = [
      {headerName: 'Client Id', field: 'client_id', sortable: true, filter: true, resizable: true},
      {headerName: 'Client Name', field: 'client_name', sortable: true, filter: true, resizable: true},
      {headerName: 'Email Address', field: 'email_address', sortable: true, filter: true, resizable: true, width: 300},
      {headerName: 'Frequency', field: 'frequency', sortable: true, filter: true, resizable: true},
      {headerName: 'Last Sent On', field: 'last_send_on', sortable: true, filter: true, resizable: true, width: 300},
      {
        headerName: 'Action',
        template:
        `
        <a>
          <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        </a>
        <a>
          <i class='fa fa-trash' data-action-type="Delete" title="Delete" aria-hidden="true" style="margin-left: 20px;"></i>
        </a>
        <a>
          <i class='fa fa-envelope' data-action-type="Email" title="Email" aria-hidden="true" style="margin-left: 20px;"></i>
        </a>
        `
      }
    ];

    // this.externalRowData = [
    //   {"client_id" : "abc", "client_name" : "ABZ", "email_address" : "sdjsdsdj", "frequency" : "Monthly", "last_sent_on" : "24/05/2021"}
    // ];

  };

  public onGridReady(event : any) : void {

  };

  public onRowClicked(e : any) : void {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.actionType = actionType;
      this.clickedData = data;
      switch (actionType) {
        case 'Edit':
          return this.editAlcsClient(data);
        case 'Delete':
          return this.deleteAlcsClient(data);
        case 'Email':
          return this.sendEmailClient();
      }
    }
  };

  public editAlcsClient(data : any) : void {
    this.gridView = false;
    this.editDetails = true;
    this.formDivision = true;
    this.topActionButton = false;
    this.addDetails = false;
    this.topDetails = false;
    this.alcsClientId = data['client_id'];
    this.alcsClientName = data['client_name'];
    this.alcsEmailAddress = data['email_address'];
    this.alcsFrequency = data['frequency'];
    this.readOnly = true;
  };

  public deleteAlcsClient(data : any) :  void {
    this.alcsClientId = data['client_id'];
    this.open(this.content);
  };

  public viewAlcsClient(data : any) : void {
    console.log("View");
    this.gridView = false;
  };

  public addEmailClient() : void {
    this.gridView = false;
    this.formDivision = true;
    this.topActionButton = false;
    this.topDetails = false;
    this.editDetails = false;
    this.addDetails = true;
    this.alcsClientId = '';
    this.alcsClientName = '';
    this.alcsEmailAddress = '';
    this.alcsFrequency = 'Choose...';
    this.readOnly = false;
  };

  public OnSubmit() : void {
    if(this.actionType == 'Edit')
    {
      this.editClientDetails();
    }
    else if(this.actionType == '')
    {
      this.createClientDetails();
    }
  };

  public cancel() : void {
    this.formDivision = false;
    this.topActionButton = true;
    this.topDetails = true;
    this.gridView = true;
    this.editDetails = false;
    this.addDetails = false;
    this.actionType = '';
  };

  public sendEmailClient () : void {
    this.open(this.sendEmail);
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public getClientDetails() : void {
    this.ngxService.start();
    let params = {};

    this.alcsService.getClientDetailsFromServer(params)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        let rowData = responseData;
        rowData.forEach((item, index) => {
          // console.log("last sent on", item['last_send_on']);
          if (item['last_send_on'] == null)
          {
            item['last_send_on'] = '';
          }
          else
          {
            let date = item['last_send_on'].split(" ")[0];
            item['last_send_on'] = date.split("-")[2] + "/" + date.split("-")[1] + "/" + date.split("-")[0];
          }
        });

        this.externalRowData = rowData;
        this.ngxService.stop();
      }
    ), 
    (error : any) => {
      this.ngxService.stop();
      this.HandleErrorResponse(error);
    }
  };

  public editClientDetails() : void {
    // this.ngxService.start();
    console.log("Edit");
    console.log(this.clickedData);
    let data = this.clickedData;
    // console.log("Last Sent on", data['last_send_on']);
    if (data["last_send_on"] != "")
    {
      data['last_send_on'] = data['last_send_on'].split("/")[2] + "-" + data['last_send_on'].split("/")[1] + "-" + data['last_send_on'].split("/")[0] + " " + '07:18:02.973726+00:00';
    }
    else
    {
      data['last_send_on'] = null;
    };

    let params = {
      "id": data["id"],
      "tenants_id": this.tenantsId,
      "groups_id": this.groupsId,
      "entities_id": this.entitiesId,
      "client_id": this.alcsClientId,
      "client_name": this.alcsClientName,
      "email_address": this.alcsEmailAddress,
      "frequency": this.alcsFrequency,
      "last_send_on": data['last_send_on'],
      "is_active": 1,
      "created_by": this.userId,
      "created_date": data['created_date'],
      "modified_by": this.userId,
      "modified_date": data['modified_date']
    };

    // console.log("Edit Data", data);
    this.alcsService.editClientDetailsToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        // console.log("Edit Data Response", responseData);
        alert("Details Updated Successfully!!!");
        this.cancel();
        this.getClientDetails();
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.ngxService.stop();
      this.HandleErrorResponse(error);
    };
  };

  public createClientDetails() : void {
    // console.log("Create");
    this.ngxService.start();
    let params = {
      "tenants_id": this.tenantsId,
      "groups_id": this.groupsId,
      "entities_id": this.entitiesId,
      "client_id": this.alcsClientId,
      "client_name": this.alcsClientName,
      "email_address": this.alcsEmailAddress,
      "frequency": this.alcsFrequency,
      "last_send_on": "",
      "is_active": 1,
      "created_by": this.userId,
      "modified_by": this.userId,
    };

    this.alcsService.postClientDetailsToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Post Response ", responseData);
        if ('id' in responseData)
        {
          alert("Details Created Successfully!!!");
        }
        else if (responseData[0] === undefined)
        {
          alert("Error in Updating Details!!!");
        };
        this.cancel();
        this.getClientDetails();
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    };
  };

  public deleteClientDetails() : void {
    this.ngxService.start();
    console.log("Delete Data", this.clickedData);
    let params = this.clickedData;
    this.alcsService.deleteClientDetailsToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Delete Response ", responseData);
        this.getClientDetails();
        this.ngxService.stop();
      }
    ), 
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  };

  public emailClient() : void {

    if (this.paymentFromDate == "")
    {
      alert("Please Choose Payment From Date!!!");
    }
    else if (this.paymentToDate == "")
    {
      alert("Please Choose Payment To Date!!!");
    }
    else
    {
      this.ngxService.start();
      let clientId = this.clickedData['client_id'];
      let params = {
        "alcsClientId" : clientId,
        "paymentFromDate" : this.paymentFromDate,
        "paymentToDate" : this.paymentToDate,
        "tenantsId": this.tenantsId,
        "groupsId": this.groupsId,
        "entitiesId": this.entitiesId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId
      };
      this.alcsService.sendMailToClient(params)
      .subscribe(
        (receivedData : any) => {
          let responseData = receivedData;
          // console.log("Send Mail Response", responseData);
          if (responseData.length == 0)
          {
            alert("Oops! No Data Available for this '" + clientId.toString() + "' Client!!!");
            this.ngxService.stop();
          }
          else if (responseData[0] === undefined)
          {
            alert("Error in Sending Email for this '" + clientId.toString() + "' Client!!!");
            this.ngxService.stop();
          }
          else if ('id' in responseData[0])
          {
            alert("Email Sent to this '" + clientId.toString() + "' Client Id Successfully!!!");
            this.getClientDetails();
            this.ngxService.stop();
          };
        },
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      );
    }
  };

  public HandleErrorResponse(err: any) : void {
   console.log("Error",err);
  };

}
