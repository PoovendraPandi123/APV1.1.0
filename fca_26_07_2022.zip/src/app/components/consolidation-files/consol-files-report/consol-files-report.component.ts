import { Component, OnInit } from '@angular/core';
import { ConsolFilesReportService } from 'src/app/service/consol-files-report.service';
import { JsonToExcelService } from 'src/app/services/common/json-to-excel.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-consol-files-report',
  templateUrl: './consol-files-report.component.html',
  styleUrls: ['./consol-files-report.component.css']
})
export class ConsolFilesReportComponent implements OnInit {

  public reportTypeChosen: string;
  public targetList: any;
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public targetNameChosen: string;
  public gstMonthChosen: string;
  public pagination: boolean;
  public reportVisible: boolean;
  public paginationSize: number;
  public fileRowData: any;
  public fileColumnDefs: any;
  public excelExportData: any;
  public gridApi: any;
  public gridColumnApi: any;
  public todayDate: any;

  constructor(private reportService: ConsolFilesReportService, private ngxService: NgxUiLoaderService, private excelService: JsonToExcelService) {
    this.reportTypeChosen = '';
    this.targetList = [];
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.targetNameChosen = '';
    this.gstMonthChosen = '';
    this.pagination = false;
    this.reportVisible = false;
    this.paginationSize = null;
    this.fileRowData = [];
    this.fileColumnDefs = [];
    this.excelExportData = [];
    this.todayDate = '';
   }

  public ngOnInit(): void {
    this.reportTypeChosen = '-1';
    this.targetNameChosen = '-1';
    this.getTargetList();
    this.pagination = true;
    this.paginationSize = 20;
  }

  public getTodayDate() : void {
    var currentdate = new Date();
    var datetime = currentdate.getDate() + "_"+(currentdate.getMonth()+1) 
    + "_" + currentdate.getFullYear() + "_" 
    + currentdate.getHours() + "_Hrs_" 
    + currentdate.getMinutes() + "_Min_" + currentdate.getSeconds() + "_Sec";
    this.todayDate = datetime;
  }

  public getTargetList() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.reportService.getTragetListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Target List Response ", responseData);
        this.targetList = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HanlerErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public searchClick() : void {
    if (this.reportTypeChosen == '-1')
    {
      alert("Kindly Chooose Report Type!!!");
    }
    else if (this.targetNameChosen == '-1')
    {
      alert("Kindly Choose Target Name!!!");
    }
    else if(this.gstMonthChosen == '')
    {
      alert("Kindly Choose GST Remittance Month!!!");
    }
    else
    {
      this.ngxService.start();
      this.reportVisible = true;

      let prminputs = {
        "tenants_id": this.tenantId,
        "groups_id": this.groupId,
        "entities_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processingLayerId,
        "target_files_id": this.targetNameChosen,
        "report_type": this.reportTypeChosen,
        "gst_month": this.gstMonthChosen
      }

      this.reportService.getReportFromServer(prminputs)
      .subscribe({
        next : (receivedData : any) => {
          this.ngxService.start();
          let responseData = receivedData;
          console.log("Post Report Server Response ", responseData);
          if (responseData["Status"] == "Success")
          {
            let data = responseData["data"];
            let headers = data["headers"];
            let records = data["data"];
            this.excelExportData = responseData["excel_export_data"];

            headers.forEach((item, index) => {
              if(item.sortable=="true"){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
            });

            this.fileColumnDefs = headers;
            this.fileRowData = records;

            this.ngxService.stop();
          }
          else if (responseData["Status"] == "Error")
          {
            this.ngxService.stop();
          }
        },
        error : (error : any) => {
          console.log("Post Response Server Error ", error);
          this.ngxService.stop();
        }
      });

    }
  }

  public getTargetName(targetId: Number) : string {
    for (var i=0; i<this.targetList.length; i++)
    {
      if (this.targetList[i]["id"] == targetId)
      {
        return this.targetList[i]["name"]
      }
    }
  }

  public onExportXlsxClick() : void {
    this.ngxService.start();
    this.getTodayDate();
    this.excelService.exportAsExcelFile(this.excelExportData, this.getTargetName(Number(this.targetNameChosen)) + "_" + this.todayDate);
    this.ngxService.stop();
  }

  public onExportXlsbClick() : void {
    this.ngxService.start();
    this.getTodayDate();
    this.excelService.exportAsExcelXlsbFile(this.excelExportData, this.getTargetName(Number(this.targetNameChosen)) + "_" + this.todayDate);
    this.ngxService.stop();
  }

  public onExportCsvClick() : void {
    this.ngxService.start();
    this.getTodayDate();
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: this.getTargetName(Number(this.targetNameChosen)) + "_" + this.todayDate + '_export.csv'
    };
    this.gridApi.exportDataAsCsv(params);
    this.ngxService.stop();
  }

  public onGridReady(event : any) : void {
    this.gridApi = event.api;
    this.gridColumnApi = event.columnApi;
  }

  public onRowClicked(e : any) : void {

  }

  public HanlerErrorResponse(err : any) : void {
    console.log(err);
  }

}
