import { TestBed } from '@angular/core/testing';

import { ConsolFilesSourceRelationsService } from './consol-files-source-relations.service';

describe('ConsolFilesSourceRelationsService', () => {
  let service: ConsolFilesSourceRelationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesSourceRelationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
