import { TestBed } from '@angular/core/testing';

import { AggregatorsService } from './aggregators.service';

describe('AggregatorsService', () => {
  let service: AggregatorsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AggregatorsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
