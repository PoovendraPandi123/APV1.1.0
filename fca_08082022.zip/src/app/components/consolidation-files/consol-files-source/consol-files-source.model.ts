export class Source {
  public sourceName: string = '';
  public sourceType: string = '';
  public fileType: string = '';
  public textSeparator: string = '';
  public otherSeparator: string = '';
  public filePasswordRequired: string = '';
  public filePassword: string = '';
  public sheetNameRequired: string = '';
  public sheetName: string = '';
  public sheetPasswordRequired: string = '';
  public sheetPassword: string = '';
  public columnStartRow: string = '';
  public database: string = '';
  public dbHost: string = '';
  public dbPort:string = '';
  public dbUserName: string = '';
  public dbPassword: string = '';
  public schema: string = '';
  public table: string = '';
  public importSequence: number = 0;
  public psqlDatabase: string = '';
  public keywords: string = '';

  constructor() {  }

}