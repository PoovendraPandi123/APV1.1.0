import { Component, OnInit } from '@angular/core';
import { ConsolFilesProcessService } from 'src/app/service/consol-files-process.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-consol-files-process',
  templateUrl: './consol-files-process.component.html',
  styleUrls: ['./consol-files-process.component.css']
})
export class ConsolFilesProcessComponent implements OnInit {

  public pagination: boolean;
  public paginationSize: number;
  public fileRowData: any;
  public fileColumnDefs: any;
  public userModelList: any;
  public userDetails: any;
  public userId: number;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public clickedData: any;
  public gridSelectedRows: any;

  constructor(private processService: ConsolFilesProcessService, private ngxService: NgxUiLoaderService) { 
    this.pagination = false;
    this.paginationSize = null;
    this.fileRowData = [];
    this.fileColumnDefs = [];
    this.userModelList = [];
    this.userDetails = [];
    this.userId = null;
    this.tenantId = null;
    this.groupId = null;
    this.entityId = null;
    this.mProcessingLayerId = null;
    this.mProcessingSubLayerId = null;
    this.processingLayerId = null;
    this.clickedData = [];
    this.gridSelectedRows = [];
  }

  public ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.pagination = true;
    this.paginationSize = 20;
    this.setFileColumnDefs();
    this.getValidatedData();
  }

  public refreshClick() : void {
    this.getValidatedData();
  }

  public onGridReady(event : any) : void {

  }

  public onRowClicked(e : any) : void {

    if (e.event.target !== undefined) {
      let data = e.data;
      this.clickedData = data;
      console.log("Click ", this.clickedData);
    }
  }

  public setFileColumnDefs() : void {
    this.fileColumnDefs = [
      {headerName: '', checkboxSelection: true, field: "", maxWidth: 40, pinned: 'left', sortable: true, filter: false, resizable: false, suppressAutoSize: true, suppressSizeToFit: true, lockPosition: true, headerCheckboxSelection: true, headerCheckboxSelectionFilteredOnly: true},
      {headerName: 'GST Month', field: 'gst_month', sortable: true, filter: true, resizable: true, width: 120},
      {headerName: 'Source Name', field: 'source_name', sortable: true, filter: true, resizable: true},
      {headerName: 'Extraction Type', field: 'extraction_type', sortable: true, filter: true, resizable: true},
      {headerName: 'File Name', field: 'file_name', sortable: true, filter: true, resizable: true},
      {headerName: 'File Size (Bytes)', field: 'file_size_bytes', sortable: true, filter: true, resizable: true, width: 140},
      {headerName: 'Row Count', field: 'file_row_count', sortable: true, filter: true, resizable: true, width: 120},
      {headerName: 'Status', field: 'status', sortable: true, filter: true, resizable: true},
      {headerName: 'Comments', field: 'comments', sortable: true, filter: true, resizable: true, width:500},
    ]
  }

  public getValidatedData() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes",
      "status": "VALIDATED"
    };

    this.processService.getValidateDataFromServer(data)
    .subscribe(
      (receivedData: any) => {
        let responseData = receivedData;
        for (var i=0; i<responseData.length; i++)
        {
          responseData[i][""] = ""
        };
        // console.log("Validated Data Response ", responseData);
        this.fileRowData = responseData;

        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public onGridSelectionChanged(params : any) : void {
    this.gridSelectedRows = params.api.getSelectedRows();
  }

  public processButtonClick() : void {
    console.log("File Row Data ", this.gridSelectedRows);
    if (this.gridSelectedRows.length == 0)
    {
      alert("Kindly Select the File to Process!!!");
    }
    else
    {
      this.ngxService.start();

      let prminputs = {
        "validatedFileList": this.gridSelectedRows
      };

      

      alert("File Processed Successfully!!!");
      this.ngxService.stop();
    }
  }

  public HandleErrorResponse(err : any) : void {
    console.log(err);
  }

}
