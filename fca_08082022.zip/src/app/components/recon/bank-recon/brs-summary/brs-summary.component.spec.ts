import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrsSummaryComponent } from './brs-summary.component';

describe('BrsSummaryComponent', () => {
  let component: BrsSummaryComponent;
  let fixture: ComponentFixture<BrsSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrsSummaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrsSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
