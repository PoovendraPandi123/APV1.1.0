import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brs-month-close',
  templateUrl: './brs-month-close.component.html',
  styleUrls: ['./brs-month-close.component.css']
})
export class BrsMonthCloseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
