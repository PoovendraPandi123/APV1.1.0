import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrsMonthendCloseComponent } from './brs-monthend-close.component';

describe('BrsMonthendCloseComponent', () => {
  let component: BrsMonthendCloseComponent;
  let fixture: ComponentFixture<BrsMonthendCloseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrsMonthendCloseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrsMonthendCloseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
