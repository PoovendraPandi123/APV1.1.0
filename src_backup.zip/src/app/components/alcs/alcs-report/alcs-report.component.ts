import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { HttpClient  } from '@angular/common/http';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AlcsreportService } from 'src/app/service/alcsreport.service';

@Component({
  selector: 'app-alcs-report',
  templateUrl: './alcs-report.component.html',
  styleUrls: ['./alcs-report.component.css']
})
export class AlcsReportComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public reportDate : any;
  public displayGrid : boolean;
  public pagination : boolean;
  public paginationSize : number;
  public rowData : any;
  public columnDefs : any;
  public alcsType : string;
  public alcsTypeList : any;
  public userModelList : any;
  public tenantsId : number;
  public groupsId : number;
  public entitiesId : number;
  public mProcessingLayerId : number;
  public mProcessingSubLayerId : number;
  public processingLayerId : number;
  public gridApi : any;
  public gridColumnApi : any;

  constructor(private alcsReportService : AlcsreportService, private ngxService : NgxUiLoaderService) 
  { 
    this.reportDate = '';
    this.displayGrid = false;
    this.pagination = false;
    this.paginationSize = 0;
    this.rowData = [];
    this.columnDefs = [];
    this.alcsType = '';
    this.alcsTypeList = [];
    this.userModelList = [];
    this.tenantsId = 0;
    this.groupsId = 0;
    this.entitiesId = 0;
    this.mProcessingLayerId = 0;
    this.mProcessingSubLayerId = 0;
    this.processingLayerId = 0;
  }

  public ngOnInit(): void {
    this.pagination = true;
    this.paginationSize = 20;
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.tenantsId = this.userModelList["tenant_id"];
    this.groupsId = this.userModelList["group_id"];
    this.entitiesId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.initAlcsTypeList();
    this.alcsType = '0';
  }

  public initAlcsTypeList() : void {
    this.ngxService.start();
    this.alcsTypeList = this.alcsReportService.getAlcsTypeList();
    this.ngxService.stop();
  }

  public searchClick() : void {
    if (this.alcsType == '0')
    {
      alert("Please Choose ALCS Type!!!");
      this.displayGrid = false;
    }
    else if (this.reportDate == "")
    {
      alert("Please Choose Report Date!!!");
      this.displayGrid = false;
    }
    else
    {
      this.displayGrid = true;
      this.setColumnDefinitions();
      this.getReportValues();
    }
  }

  public getProcessingLayerId(alcsType) : number {
    for (var i=0; i<this.alcsTypeList.length; i++)
    {
      if (alcsType == this.alcsTypeList[i]["alcsType"])
      {
        return this.alcsTypeList[i]["processingLayerId"];
      }
    }
  }

  public setColumnDefinitions() : void {
    if (this.alcsType == "axis" || this.alcsType == "icici" || this.alcsType == "sbi" || this.alcsType == "hdfc")
    {
      this.columnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true},
        {headerName: 'Debit Date', field: 'int_reference_date_time_2', sortable: true, filter: true, resizable: true},
        {headerName: 'bank_reference_column', field: 'int_extracted_text_6', sortable: true, filter: true, resizable: true},
        {headerName: 'Regenerated Letter Number', field: 'int_generated_num_2', sortable: true, filter: true, resizable: true}
      ]
    }
    else if (this.alcsType == 'hdfc-neft')
    {
      this.columnDefs = [
        {headerName: 'Bank Name', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Account No', field: 'int_reference_text_2', sortable: true, filter: true, resizable: true},
        {headerName: 'Accpac Code', field: 'int_reference_text_3', sortable: true, filter: true, resizable: true},
        {headerName: 'Date', field: 'int_reference_date_time_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Acc #', field: 'int_reference_text_4', sortable: true, filter: true, resizable: true},
        {headerName: 'Issued Amt', field: 'int_amount_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Name', field: 'int_reference_text_5', sortable: true, filter: true, resizable: true},
        {headerName: 'Company', field: 'int_reference_text_6', sortable: true, filter: true, resizable: true},
        {headerName: 'Emp#', field: 'int_reference_text_7', sortable: true, filter: true, resizable: true},
        {headerName: 'Client Id', field: 'int_reference_text_8', sortable: true, filter: true, resizable: true},
        {headerName: 'Remarks', field: 'int_reference_text_9', sortable: true, filter: true, resizable: true},
        {headerName: 'IFSC CODES', field: 'int_reference_text_11', sortable: true, filter: true, resizable: true},
        {headerName: 'Letter upload No', field: 'int_reference_text_12', sortable: true, filter: true, resizable: true},
        {headerName: 'PM_Payment_Date', field: 'int_reference_text_13', sortable: true, filter: true, resizable: true},
        {headerName: 'UTR Number', field: 'int_reference_text_14', sortable: true, filter: true, resizable: true},
        {headerName: 'Debit Date', field: 'int_reference_date_time_2', sortable: true, filter: true, resizable: true},
        {headerName: 'bank_reference_column', field: 'int_extracted_text_14', sortable: true, filter: true, resizable: true},
        {headerName: 'Regenerated Letter Number', field: 'int_generated_num_3', sortable: true, filter: true, resizable: true}
      ]
    }
  }

  public getReportValues() : void {
    this.ngxService.start();

    let params = {
      "tenantsId": this.tenantsId,
      "groupsId": this.groupsId,
      "entityId": this.entitiesId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.getProcessingLayerId(this.alcsType),
      "paymentDate": this.reportDate
    }

    // console.log("Report Values Input", params);

    this.alcsReportService.getReportFromServer(params)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Report Response", responseData);
        let rowData = responseData;
        rowData.forEach((item, index) => {
          item["int_reference_date_time_1"] = item["int_reference_date_time_1"].split("T")[0];
          item["int_reference_date_time_2"] = item["int_reference_date_time_2"].split("T")[0];
        });
        this.rowData = rowData;
        this.ngxService.stop();
      },
      (error : any) => {
        this.HandleErrorResponse(error);
      }
    )
  }

  public onGridReady(event : any) : void {
    this.gridApi = event.api;
    this.gridColumnApi = event.columnApi;
  }

  public onExportButtonClick(): void {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'ALCS_Report_' + this.alcsType + "_" + this.reportDate +'.csv'
    };
    this.gridApi.exportDataAsCsv(params);
  }

  public HandleErrorResponse(err : any)
  {
    console.log("Error", err);
  }
}
