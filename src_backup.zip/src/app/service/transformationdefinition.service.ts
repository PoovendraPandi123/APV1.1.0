import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class TransformationdefinitionService {
  lstReturn: any;
  public  port="50003";

  constructor(private httpClient: HttpClient, private router: Router, 
    private CS: CommonService) {
  }

  
  postaggregatorFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/aggregator_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
  gettransformationFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/transformation_source/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
  getaggregatorFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/aggregator_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getsourceFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  gettransformationfieldextractionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/transformation_page/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
  posttransformationdefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/transformations_field_extraction/');
    return this.CS.SendToAPI("post", resData, prminputs);   
  }
  

  getsourcedefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_definitions_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

}
