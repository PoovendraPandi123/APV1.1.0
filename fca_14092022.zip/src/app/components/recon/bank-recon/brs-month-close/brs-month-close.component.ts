import { Component, OnInit } from '@angular/core';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { BrsMonthCloseService } from 'src/app/services/recon/bank-recon/brs-month-close.service';

@Component({
  selector: 'app-brs-month-close',
  templateUrl: './brs-month-close.component.html',
  styleUrls: ['./brs-month-close.component.css']
})
export class BrsMonthCloseComponent implements OnInit {

  public selectProcessingLayer : any;
  public processing_layer_id : Number;
  public processingLayerList : any;
  public monthEndList : any;
  public closeMonth : any;
  public monthEnd : boolean = false;
  public bankBalance : any;
  public glBalance : any;
  public closeResult: any;
  public bankClosingDate : any;
  public glClosingDate : any;
  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;


  constructor(public modalService: NgbModal, public ngxService: NgxUiLoaderService, public monthCloseService: BrsMonthCloseService) { }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.getProcessingLayerList();
    this.selectProcessingLayer = {
      "processing_layer_id":0
    };
    this.ngxService.stop();
  }

  getProcessingLayerList(){
    this.ngxService.start();
    // console.log(this.userModelList);
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    }

    this.monthCloseService.getProcessingLayerListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Processing Layer List Response: ", response_data);
        this.processingLayerList = response_data["processing_layer_list"];
        this.ngxService.stop();
      }
    )

  }

  getSelectedProcessingLayer(processingLayerId){
    if (processingLayerId == 0)
    {
      alert("Kindly Choose the Reconciliation Type!!!");
    }
    else
    {
      this.ngxService.start();
      this.processing_layer_id = Number(processingLayerId);
  
      let data = {
        "tenantId" : this.tenantId,
        "groupId" : this.groupId,
        "entityId" : this.entityId,
        "mProcessingLayerId" : this.mProcessingLayerId,
        "mProcessingSubLayerId" : this.mProcessingSubLayerId,
        "processingLayerId" : this.processing_layer_id
      }
  
      this.monthCloseService.getMonthCloseMonthsFromServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log("Choose Reconciliation Output ", responseData);
          if(responseData["Status"] === "Success")
          {
            if(responseData["data"] === "NoMonth")
            {
              this.monthEnd = false;
              alert("No Month is Configured!!!");
              this.ngxService.stop();
            }
            else if(responseData["data"] !== "NoMonth")
            {
              this.closeMonth = responseData["data"]["month_closing"];
              this.bankBalance = responseData["data"]["bank_closing_balance"];
              this.glBalance = responseData["data"]["gl_closing_balance"];
              this.bankClosingDate = responseData["data"]["bank_closing_date"];
              this.glClosingDate = responseData["data"]["gl_closing_date"];
              this.monthEnd = true;
              this.ngxService.stop();
            }
          }
          else if (responseData["Status"] == "Error")
          {
            alert("Error in Fetching Month Details. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
        }, (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      )
    }
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public onSaveButtonClick() : void {
    this.ngxService.start();

    let closeMonthYear = this.closeMonth;
    let processingLayerId = this.processing_layer_id;
    let bankClosingDate = this.bankClosingDate;
    let glClosingDate = this.glClosingDate;

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "userId": this.userId,
      "closeMonthYear": closeMonthYear,
      "processingLayerId": processingLayerId,
      "bankClosingDate": bankClosingDate,
      "glClosingDate": glClosingDate
    }

    this.monthCloseService.sendMonthCloseDateToServer(data)
    .subscribe(
      received_data => {
        let responseData = received_data;
        console.log("Confirm Button Click Response, ", responseData);
        if (responseData["Status"] === "Success")
        {
          this.monthEnd = false;
          this.getProcessingLayerList();
          this.ngxService.stop();
        }
        else if (responseData["Status"] === "Error")
        {
          this.monthEnd = false;
          alert("Issue in Closing Month End. Kindly contact Advent Support!!!");
          this.ngxService.stop();
        }
        
      }
    )
  }

  public HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

}
