import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { VrPeriodAssigmentService } from 'src/app/services/recon/vendor-recon/vr-period-assigment.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-vr-period-assignment',
  templateUrl: './vr-period-assignment.component.html',
  styleUrls: ['./vr-period-assignment.component.css']
})
export class VrPeriodAssignmentComponent implements OnInit {

  constructor(private assignmentService: VrPeriodAssigmentService, private ngxService: NgxUiLoaderService) { }

  public ngOnInit(): void {
  }

}
