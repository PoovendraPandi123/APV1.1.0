import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VrBalanceConfirmationComponent } from './vr-balance-confirmation.component';

describe('VrBalanceConfirmationComponent', () => {
  let component: VrBalanceConfirmationComponent;
  let fixture: ComponentFixture<VrBalanceConfirmationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VrBalanceConfirmationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VrBalanceConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
