import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { VrBalanceConfirmationService } from 'src/app/services/recon/vendor-recon/vr-balance-confirmation.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-vr-balance-confirmation',
  templateUrl: './vr-balance-confirmation.component.html',
  styleUrls: ['./vr-balance-confirmation.component.css']
})
export class VrBalanceConfirmationComponent implements OnInit {

  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;
  public processingLayerIdsUser : any;
  public processingLayerList : any;
  public selectProcessingLayer : any;
  public processing_layer_id : Number;
  public periodChosen: string;
  public fromDate: string;
  public toDate: string;

  constructor(private balanceConfirmationSevice: VrBalanceConfirmationService, private ngxService: NgxUiLoaderService) { 
    this.periodChosen = '';
  }

  public ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.periodChosen = '0';
    this.fromDate = '';
    this.toDate = '';
  }

  public getSendMail() : void {
    if (this.periodChosen == "0")
    {
      alert("Please Choose a Period and send Mail!!!");
    }
    else if (this.fromDate == '')
    {
      alert("Please Choose a From Date!!!");
    }
    else if (this.toDate == '')
    {
      alert("Please Choose a To Date!!!");
    }
    else
    {
      this.ngxService.start();
      var data = {
        "tenantsId": this.tenantId,
        "groupsId": this.groupId,
        "entitiesId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "period": this.periodChosen,
        "fromDate": this.fromDate,
        "toDate": this.toDate
      }
      this.balanceConfirmationSevice.sendMailToVendor(data)
      .subscribe(
        received_data => {
          let responseData = received_data;
          console.log(responseData);
          if (responseData["Status"] == "Success")
          {
            alert("Email Sent to the Vendors Successfully!!!");
            this.ngxService.stop();
          }
          else
          {
            alert("Error in Sending Email to the Vendor. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error:any) => {
          this.HandleErrorResponse(error)
        }
      )
    }
  }

  public getReadMail() : void {
    this.ngxService.start();
    var data = {
      "tenantsId": this.tenantId,
      "groupsId": this.groupId,
      "entitiesId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "period": this.periodChosen,
      "fromDate": this.fromDate,
      "toDate": this.toDate
    };
    this.balanceConfirmationSevice.readMailFromVendor(data)
      .subscribe(
        received_data => {
          let responseData = received_data;
          console.log(responseData);
          if (responseData["Status"] == "Success")
          {
            alert("Email Read From Vendors Successfully!!!");
            this.ngxService.stop();
          }
          else
          {
            alert("Error in Reading Email From Vendors. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
        },
        (error:any) => {
          this.HandleErrorResponse(error)
        }
      )
  }

  public HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

}
