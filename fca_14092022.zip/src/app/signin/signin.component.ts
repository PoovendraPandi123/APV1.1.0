import { Component, OnInit } from '@angular/core';
import { User } from './signin.model';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  public obj_user: User;
  public user_details: any;
  public backgroundImage: string;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public router:Router) {
    this.backgroundImage = '';
   }

  ngOnInit(): void {
    this.backgroundImage = '/../../../assets/images/gallery/lock.png';
    this.obj_user = new User();
    this.getIPAddress();
  }

  public emailClick() : void {
    this.backgroundImage = '/../../../assets/images/gallery/lock.png';
  }

  public passwordClick() : void {
    this.backgroundImage = '/../../../assets/images/gallery/key.png';
  }

  getIPAddress()
  { 
    this.http.get("http://api.ipify.org/?format=json").subscribe((res:any)=>{
      this.obj_user.ip_address = res.ip;
    console.log("ipAddress",this.obj_user.ip_address);
    });
  }

  public validateEmailAddress(inputData) : boolean {
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    if (inputData.match(validRegex))
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  signIn(){
    // console.log("Username: ", this.obj_user.username);

    if (this.obj_user.username == "" && this.obj_user.password == "")
    {
      alert("Please Enter the Email Address and Password to Login!!!");
    }
    else if (this.obj_user.username == "")
    {
      alert("Please Enter the Email Address!!!");
    }
    else if (this.obj_user.password == "")
    {
      alert("Please Enter the Password!!!");
    }
    else if (!this.validateEmailAddress(this.obj_user.username))
    {
      alert("Invalid Email Address. Please Enter a Valid Email Address!!!");
    }
    else
    {
      let date = new Date();
      let data = {
        "username" : this.obj_user.username,
        "password" : this.obj_user.password,
        "login_time" : date,
        "system_ip" : this.obj_user.ip_address
      }
  
      // console.log("Login Input: ", data);
  
      this.obj_auth_service.getLoginstatusFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          console.log("Return Response: ", response_data);
          this.user_details = response_data;
          sessionStorage.setItem('user_details', JSON.stringify(this.user_details));
  
          if(this.user_details.Status == "Success")
          {
            this.router.navigate(['/ModuleList']);
            // this.router.navigate(['/SideMenu']);
          }
          else
          {
            alert("Error in Authentication User!!!");
          }
  
        },
        (error:any) => {this.HandleErrorResponse(error)}
      )
    }
  }

  HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

}

