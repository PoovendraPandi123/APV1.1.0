import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessLogicLayerComponent } from './business-logic-layer.component';

describe('BusinessLogicLayerComponent', () => {
  let component: BusinessLogicLayerComponent;
  let fixture: ComponentFixture<BusinessLogicLayerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusinessLogicLayerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessLogicLayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
