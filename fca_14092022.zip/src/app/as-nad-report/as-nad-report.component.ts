import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/as.auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-as-nad-report',
  templateUrl: './as-nad-report.component.html',
  styleUrls: ['./as-nad-report.component.css']
})
export class AsNadReportComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public userModelList: any;
  public userId: any;
  public tenantId: any;
  public groupId: any;
  public entityId: any;
  public mProcessingLayerId: any;
  public mProcessingSubLayerId: any;
  public pagination : boolean = false;
  public paginationSize : Number = 0;
  public externalRowData: any;
  public externalColumnDefs: any;
  public processingLayerIdsUser: any;
  public displayTAN:boolean = false;
  public externalGridApi: any;
  public externalGridColumnApi: any;
  public fromDate: any;
  public toDate: any;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.ngxService.start();
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.pagination = true;
    this.paginationSize = 20;
    this.fromDate = "Empty";
    this.toDate = "Empty";
    this.ngxService.stop();
    // this.displayTANReport();
  }

  searchClick()
  {
    if (this.fromDate == "Empty" || this.toDate == "Empty")
    {
      alert("Kindly Choose From and To Date!!!");
    }
    else if(this.fromDate != "Empty" || this.toDate != "Empty")
    {
      this.displayTAN = true;
      this.displayNADReport();
    }
  }

  displayNADReport()
  {
    this.ngxService.start();
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "fromDate" : this.fromDate,
      "toDate" : this.toDate
    }
    this.obj_auth_service.getNADReportFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data["data"];
        let externalRecordsAllColumnDefs = response_data["nad"]["headers"];
        let externalRecordsAllrowData = response_data["nad"]["data"];

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = false;
              item["minWidth"] = 100;
              // item["pinned"] = 'left';
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 100;
            }

            // Hiding
            if (item.field === "id")
            {
              item["hide"] = true;
            }

          }
        });

        this.externalColumnDefs = externalRecordsAllColumnDefs;
        this.externalRowData = externalRecordsAllrowData;
        this.ngxService.stop();
      }
    )
  }

  onExternalGridReady(params){
    this.externalGridApi = params.api;
    this.externalGridColumnApi = params.columnApi;
  }

  onExportButtonClick(){
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'CustomerNADReport.csv'
    };
    this.externalGridApi.exportDataAsCsv(params);
  }

}
