import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/service/common.service';

@Injectable({
  providedIn: 'root'
})
export class BrsMonthCloseService {

  public sourcePort = '50003';
  public reconPort = '5004';

  constructor(private CS : CommonService) { }

  public getProcessingLayerListFromServer(prminputs : any) : any {
    var resData = CommonService.authReq(this.sourcePort+'/source/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public getMonthCloseMonthsFromServer(prminputs : any) : any {
    let resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/get_month_close/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public sendMonthCloseDateToServer(prminputs : any) : any {
    let resData = CommonService.authReq(this.reconPort+'/api/v1/bank_recon/approve_month_close/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }
}
