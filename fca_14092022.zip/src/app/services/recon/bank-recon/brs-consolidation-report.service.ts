import { Injectable } from '@angular/core';
import { CommonService } from 'src/app/service/common.service';

@Injectable({
  providedIn: 'root'
})
export class BrsConsolidationReportService {

  public sourcePort = '50003';
  public reconPort = '5004';

  constructor(private CS : CommonService) { }

  public getProcessingLayerListFromServer(prminputs : any) : any {
    var resData = CommonService.authReq(this.sourcePort+'/source/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getBrsConsolidationReportFromServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/recon/get_consolidation_report/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }
}
