import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { ApiCallService } from './api-call.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConsolFilesFileUploadService {

  public port = "50012";
  // public port = "81/consolidationFiles";

  constructor(private CS: CommonService, private http: HttpClient) { }

  public postFileToServer(prminputs: any) : any {
    var resData = CommonService.authReq(this.port+'/api/v1/consol_files/get_upload_file_sequential/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }

  public getSourceListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/generic/sources/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&is_active=${prminputs["is_active"]}`);
    return this.http.get(resData["url"], resData["headers"])
  }

  public getFileUploadsListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/generic/file_uploads/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&is_active=${prminputs["is_active"]}`);
    return this.http.get(resData["url"], resData["headers"])
  }

  public getSendValidateRecordsToServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+'/api/v1/consol_files/get_update_validate_error_to_batch/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }

  public getGstMonthUpdateToServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+'/api/v1/consol_files/get_update_file_gst_month/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }

  public getGstMonthUpdateAllToServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+'/api/v1/consol_files/get_update_file_gst_month_all/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }

}
