import { Injectable } from '@angular/core';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class AlcsfileuploadService {

  public alcsPort = "50010";

  constructor(private CS: CommonService) { }

  public getFileTypeList() : any {
    return [
      {fileType: "alcs", fileName: "Consolidated ALCS", extension: "xls", entity_id: 1},
      {fileType: "bank", fileName: "Consolidated BANK", extension: "zip", entity_id: 1},
      {fileType: "hdfc-utr", fileName: "HDFC Reversal", extension: "xlsx", entity_id: 1},
      // {fileType: "alcs-manual", fileName: "ALCS Manual Upload", extension: "xls"},
      {fileType: "alcs-icici-neft", fileName: "ALCS ICICI NEFT", extension: "xlsx", entity_id: 1},
      {fileType: "icici-reversal", fileName: "ICICI NEFT Reversal", extension: "xlsx", entity_id: 1},
      {fileType: "icici-nurture", fileName: "ICICI Nurture", extension: "xlsx", entity_id: 1},
      {fileType: "alcs-icici-neft-1", fileName: "TLCS Consolidated NEFT", extension: "xls", entity_id: 2},
      {fileType: "icici-reversal-1", fileName: "TLCS ICICI Reversal TLSU", extension: "xls", entity_id: 2},
      {fileType: "icici-reversal-2", fileName: "TLCS ICICI Reversal TLEF", extension: "xls", entity_id: 2}
    ];
  };

  public getFileUploadListFromServer(prminputs)
  {
    var resData = CommonService.authReq(this.alcsPort+`/api/v1/alcs/generic/file_uploads/?file_uploaded=${prminputs["recordCount"]}&entity_id=${prminputs["entity_id"]}`);
    return this.CS.SendToAPI("get", resData, prminputs);
  }

  public postFileToServer(prminputs)
  {
    // console.log("prminputs", prminputs);
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_upload_files/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  };
}
