import { TestBed } from '@angular/core/testing';

import { ConsolFilesGstMonthCloseService } from './consol-files-gst-month-close.service';

describe('ConsolFilesGstMonthCloseService', () => {
  let service: ConsolFilesGstMonthCloseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesGstMonthCloseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
