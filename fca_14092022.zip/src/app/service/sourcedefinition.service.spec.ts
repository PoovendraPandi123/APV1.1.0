import { TestBed } from '@angular/core/testing';

import { SourcedefinitionService } from './sourcedefinition.service';

describe('SourcedefinitionService', () => {
  let service: SourcedefinitionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SourcedefinitionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
