export interface ITargetDefinitions {
    fieldName: string;
    fieldPosition: number;
}