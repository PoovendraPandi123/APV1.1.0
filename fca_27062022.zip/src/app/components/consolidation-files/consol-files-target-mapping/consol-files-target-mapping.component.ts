import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ITargetDefinitionMapping } from './consol-files-target-mapping.model';
import { ConsolFilesTargetMappingService } from 'src/app/service/consol-files-target-mapping.service';

@Component({
  selector: 'app-consol-files-target-mapping',
  templateUrl: './consol-files-target-mapping.component.html',
  styleUrls: ['./consol-files-target-mapping.component.css']
})
export class ConsolFilesTargetMappingComponent implements OnInit {

  public targetDefinitionsMappingList: ITargetDefinitionMapping[];
  public isTargetDefinitionRequired: boolean[];
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public targetList: any;
  public targetDefinitionsList: any;
  public targetChosenId: string;
  public targetDefinitionChosenId: string;
  public sourceList: any;
  public sourceDefinitionsList: any;
  public sourceIdChosen :any;

  constructor(private ngxService: NgxUiLoaderService, private mappingService: ConsolFilesTargetMappingService) { 
    this.targetDefinitionsMappingList = [];
    this.isTargetDefinitionRequired = [];
    this.userModelList = [];
    this.userDetails = [];
    this.tenantId = null;
    this.groupId = null;
    this.entityId = null;
    this.mProcessingLayerId = null;
    this.mProcessingSubLayerId = null;
    this.processingLayerId = null;
    this.userId = null;
    this.targetList = [];
    this.targetDefinitionsList = [];
    this.targetChosenId = '-1';
    this.targetDefinitionChosenId = '-1';
    this.sourceList = [];
    this.sourceDefinitionsList = [];
    this.sourceIdChosen = '-1';
  }

  public ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.getSourceList();
    this.getTargetList();
    this.setDefaultTableMapping();
  }

  public setDefaultTableMapping() : void {
    this.targetDefinitionsMappingList = [
      {
        sourceId: "-1",
        sourceDefinitionId: "-1"
      }
    ];
    this.isTargetDefinitionRequired = [true];
    this.sourceDefinitionsList = [[]];
  }

  public getSourceList() : void {

    this.ngxService.start();

    let params = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId
    };
    this.mappingService.getActiveSourceListFromServer(params)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Source List Response ", responseData);
        this.sourceList = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public getTargetList() : void {
    this.addButtonClick();
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.mappingService.getTragetListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Target List Response ", responseData);
        this.targetList = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }

  }

  public targetChange() : void {
    console.log("Target Chosen Id", this.targetChosenId);
    if (this.targetChosenId != '-1')
    {
      for (var i=0; i<this.targetList.length; i++)
      {
        if (this.targetChosenId == this.targetList[i]["id"])
        {
          this.targetDefinitionsList = this.targetList[i]["target_file_definitions"];
        }
      }
    }
    else if (this.targetChosenId == '-1')
    {
      this.targetDefinitionChosenId = '-1';
    }
  }


  public addButtonClick() : void {
    this.targetDefinitionsMappingList.push(
      {
        sourceId: "-1",
        sourceDefinitionId: "-1"
      }
    );
    this.isTargetDefinitionRequired.push(true);
    this.sourceDefinitionsList.push([]);
  }

  public deleteTargetDefinitionClick(index : number) : void {
    this.isTargetDefinitionRequired[index] = false;
  }

  public sourceChange(sourceId : any, index : any) : void {
    // console.log("Source Index", index);
    // console.log("Source Change", sourceId);
    if (sourceId != "-1")
    {
      this.sourceIdChosen = sourceId;
      for (var i=0; i<this.sourceList.length; i++)
      {
        if (sourceId == this.sourceList[i]["id"])
        {
          this.sourceDefinitionsList[index] = this.sourceList[i]["source_definitions"];
        }
      }
    }
  }

  public sourceDefinitionChange(sourceDefinitionId : any, index : any) : void {
    this.targetDefinitionsMappingList[index] = {
      sourceId: this.sourceIdChosen,
      sourceDefinitionId: sourceDefinitionId
    };

  }

  public targetMappingSaveClick() : void {

    if (this.targetChosenId == "-1")
    {
      alert("Kindly choose Target Name!!!");
    }
    else if (this.targetDefinitionChosenId == "-1")
    {
      alert("Kindly choose Target Definition Column Name!!!");
    }
    else
    {

      var targetDefinitionMappingOut = this.targetDefinitionMappingCheck();
      if (targetDefinitionMappingOut)
      {
        var targetMappingOut = this.targetMappingCheck();
      }
      else
      {
        var targetMappingOut = false;
      };

    
      if (targetMappingOut && targetDefinitionMappingOut)
      {
        this.ngxService.start();
        let params = {
          "target_id": this.targetChosenId,
          "target_def_id": this.targetDefinitionChosenId,
          "target_def_list": this.targetDefinitionsMappingList
        };

        this.mappingService.getCreateTargetMappingToServer(params)
        .subscribe(
          (receivedData : any) => {
            let responseData = receivedData;
            console.log("Create Target Mapping Response ", responseData);
            this.setDefaultTableMapping();
            this.targetDefinitionChosenId = '-1';
            alert("Data Saved Successfully!!!");
            this.ngxService.stop();
          }
        ),
        (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      };
    }
  }

  public targetMappingCheck() : boolean {
    let sourceChosenCount = 0;
    for (var i=0; i<this.targetDefinitionsMappingList.length; i++)
    {
      if (this.targetDefinitionsMappingList[i]["sourceId"] == "-1")
      {
        alert("Kindly choose Source Name -" + String(i+1) + "- Row!!!");
      }
      else
      {
        sourceChosenCount = sourceChosenCount + 1;
      }
    }
    
    if (sourceChosenCount == this.targetDefinitionsMappingList.length)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public targetDefinitionMappingCheck() : boolean {
    let sourceDefinitionChosenCount = 0;
    for (var i=0; i<this.targetDefinitionsMappingList.length; i++)
    {
      if (this.targetDefinitionsMappingList[i]["sourceDefinitionId"] == "-1")
      {
        alert("Kindly choose Source Definition Name -" + String(i+1) + "- Row!!!");
      }
      else
      {
        sourceDefinitionChosenCount = sourceDefinitionChosenCount + 1;
      }
    }

    if (sourceDefinitionChosenCount == this.targetDefinitionsMappingList.length)
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  public HandleErrorResponse(error : any) : void {
    console.log(error);
  }

}
