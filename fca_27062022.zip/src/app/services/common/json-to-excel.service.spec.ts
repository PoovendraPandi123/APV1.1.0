import { TestBed } from '@angular/core/testing';

import { JsonToExcelService } from './json-to-excel.service';

describe('JsonToExcelService', () => {
  let service: JsonToExcelService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JsonToExcelService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
