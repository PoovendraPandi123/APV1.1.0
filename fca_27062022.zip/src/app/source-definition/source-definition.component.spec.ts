import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SourceDefinitionComponent } from './source-definition.component';

describe('SourceDefinitionComponent', () => {
  let component: SourceDefinitionComponent;
  let fixture: ComponentFixture<SourceDefinitionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SourceDefinitionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SourceDefinitionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
