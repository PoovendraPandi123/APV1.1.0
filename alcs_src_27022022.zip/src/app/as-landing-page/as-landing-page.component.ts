import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-as-landing-page',
  templateUrl: './as-landing-page.component.html',
  styleUrls: ['./as-landing-page.component.css']
})
export class AsLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
