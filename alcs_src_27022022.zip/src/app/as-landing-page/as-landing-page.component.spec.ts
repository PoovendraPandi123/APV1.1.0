import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AsLandingPageComponent } from './as-landing-page.component';

describe('AsLandingPageComponent', () => {
  let component: AsLandingPageComponent;
  let fixture: ComponentFixture<AsLandingPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AsLandingPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AsLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
