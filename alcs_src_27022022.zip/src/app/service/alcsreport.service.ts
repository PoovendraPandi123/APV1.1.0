import { Injectable } from '@angular/core';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class AlcsreportService {

  public alcsPort = "50010";

  constructor(private CS: CommonService) { }

  public getAlcsTypeList() : any {
    return [
      {alcsType: 'axis', alcsName: 'ALCS AXIS RECON', processingLayerId: 400},
      {alcsType: 'icici', alcsName: 'ALCS ICICI RECON', processingLayerId: 401},
      {alcsType: 'sbi', alcsName: 'ALCS SBI RECON', processingLayerId: 402},
      {alcsType: 'hdfc', alcsName: 'ALCS HDFC RECON', processingLayerId: 403},
      {alcsType: 'hdfc-neft', alcsName: 'ALCS HDFC NEFT RECON', processingLayerId: 404}
    ];
  };

  public getReportTypeList() : any {
    return [
      {reportType: 'alcs', reportName: 'ALCS Individual'},
      {reportType: 'dailyLetters', reportName: 'Daily Letters'},
      {reportType: 'alcsUpload', reportName: 'ALCS Upload'}
    ];
  };

  public getAlcsUploadTemplateColumns() : any {
    return ['Slno', 'Client_ID', 'Emp_NO', 'Transaction_Month', 'Transaction_Year', 'Processing_Month', 'Processing_Year', 'Pay_Type', 'Invoice_No', 'Release_Date', 'NetPay_Amount', 'UTR_Number', 'Debit_Date'];
  }

  public getReportFromServer(prminputs) {
    let tenantsId = prminputs['tenantsId'];
    let groupsId = prminputs['groupsId'];
    let entitiesId = prminputs['entityId'];
    let mProcessingLayerId = prminputs['mProcessingLayerId'];
    let mProcessingSubLayerId = prminputs['mProcessingSubLayerId'];
    let processingLayerId = prminputs['processingLayerId'];
    let paymentDate = prminputs['paymentDate'];
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/generic/internal_records/?payment_date='+paymentDate+'&tenants_id='+tenantsId+'&groups_id='+groupsId+'&entity_id='+entitiesId+'&m_processing_layer_id='+mProcessingLayerId+'&m_processing_sub_layer_id='+ mProcessingSubLayerId+'&processing_layer_id='+processingLayerId);
    // console.log("Get Report API", resData);
    return this.CS.SendToAPI("get", resData, prminputs);
  };

  public getDailyLettersReportFromServer(prminputs) {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_daily_letters_report/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  public postUtrFileToServer(prminputs) {
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_utr_file_update/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  }
}
