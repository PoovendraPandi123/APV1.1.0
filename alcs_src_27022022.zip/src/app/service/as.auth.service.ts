import { Injectable } from '@angular/core';
// import { Http, Response } from '@angular/http';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
// import { Util } from './Util';
import { RouteConfigLoadStart, Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService{
  lstReturn: any;
  public modulePort = "50001";
  public reconPort = "50006";
  public reconEtlPort = "50007";
  public sourcePort = "50003";
  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  getLoginstatusFromServer(prminputs) {
    console.log("prminputs",prminputs);
    var resData = CommonService.authReq(this.modulePort+'/modules/login/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getModuleListFromServer(prminputs) {
    var resData = CommonService.authReq(this.modulePort+'/modules/user_rights/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getModelListFromServer(prminputs) {
    var resData = CommonService.authReq(this.modulePort+'/modules/user_credentials/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getProcessingLayerListFromServer(prminputs){
    var resData = CommonService.authReq(this.sourcePort+'/source/get_processing_layer_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getKPIFromServer(prminputs){
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_as_kpi/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getCustomerDifferenceFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_customer_max_difference/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getTanFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_tan_customer/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getNadListFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_customer_nad_code_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getNadDataFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_data_from_cad_code/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getIntRecordForTanFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_customer_tan/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getCustomerNADListFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconEtlPort+'/tds_recon_etl/get_customer_national_account_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  sendTanToServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconEtlPort+'/tds_recon_etl/get_update_tan/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getTANReportFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_tan_report/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getNADReportFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_nad_report/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getErpWithoutTanRecordsFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_erp_without_tan_update/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  getAsNadOpenReportFromServer(prminputs)
  {
    let resData = CommonService.authReq(this.reconPort+'/tdsrecon/get_as_nad_open_records/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

}
