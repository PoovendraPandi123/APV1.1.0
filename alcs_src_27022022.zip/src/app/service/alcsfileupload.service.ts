import { Injectable } from '@angular/core';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class AlcsfileuploadService {

  public alcsPort = "50010";

  constructor(private CS: CommonService) { }

  public getFileTypeList() : any {
    return [
      {fileType: "alcs", fileName: "Consolidated ALCS", extension: "xls"},
      {fileType: "bank", fileName: "Consolidated BANK", extension: "zip"},
      {fileType: "hdfc-utr", fileName: "HDFC Reversal", extension: "xlsx"},
      // {fileType: "alcs-manual", fileName: "ALCS Manual Upload", extension: "xls"},
      {fileType: "alcs-icici-neft", fileName: "ALCS ICICI NEFT", extension: "xlsx"},
      {fileType: "icici-reversal", fileName: "ICICI Reversal", extension: "xlsx"}
    ];
  };

  public getFileUploadListFromServer(prminputs)
  {
    let recordCount = prminputs["recordCount"];
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/generic/file_uploads/?file_uploaded='+recordCount);
    return this.CS.SendToAPI("get", resData, prminputs);
  }

  public postFileToServer(prminputs)
  {
    // console.log("prminputs", prminputs);
    var resData = CommonService.authReq(this.alcsPort+'/api/v1/alcs/common/get_upload_files/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
  };
}
