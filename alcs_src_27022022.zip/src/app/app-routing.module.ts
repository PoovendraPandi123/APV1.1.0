import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BrsLandingPageComponent } from './brs-landing-page/brs-landing-page.component';
import { ConsolidationFilesLandingPageComponent } from './consolidation-files-landing-page/consolidation-files-landing-page.component';
import { ModulelistComponent } from './modulelist/modulelist.component';
import { PoIssueLandingPageComponent } from './po-issue-landing-page/po-issue-landing-page.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { SigninComponent } from './signin/signin.component';
import { SourceComponent } from './source/source.component';
import { TaskManagementLandingPageComponent } from './task-management-landing-page/task-management-landing-page.component';
import { TdsReconLandingPageComponent } from './tds-recon-landing-page/tds-recon-landing-page.component';
import { VendorPaymentsLandingPageComponent } from './vendor-payments-landing-page/vendor-payments-landing-page.component';
import { AlcsFileUploadComponent } from './components/alcs/alcs-file-upload/alcs-file-upload.component';
import { AlcsClientsComponent } from './components/alcs/alcs-clients/alcs-clients.component';
import { AlcsDashboardComponent } from './components/alcs/alcs-dashboard/alcs-dashboard.component';
import { AlcsReportComponent } from './components/alcs/alcs-report/alcs-report.component';

const routes: Routes = [
  { path: '', redirectTo: '/SignIn', pathMatch: 'full' },
  {path:'SignIn', component:SigninComponent},
  {path:'ModuleList', component:ModulelistComponent},
  {path:'SideMenu', component:SideMenuComponent},
  {path:'BrsLandingPage', component:BrsLandingPageComponent},
  {path:'ConsolFilesLandingPage', component:ConsolidationFilesLandingPageComponent},
  {path:'PoLandingPage', component:PoIssueLandingPageComponent},
  {path:'TaskManagementLangingPage', component:TaskManagementLandingPageComponent},
  {path:'VendorPaymentsLandingPage', component:VendorPaymentsLandingPageComponent},
  {path:'TdsLandingPage', component:TdsReconLandingPageComponent},
  {path:'BrsSource', component:SourceComponent},
  {
    path:'SideMenu', component:SideMenuComponent,
    children: [
      {path: 'AlcsFileUpload', component:AlcsFileUploadComponent},
      {path: 'AlcsClients', component:AlcsClientsComponent},
      {path: 'AlcsDashboard', component:AlcsDashboardComponent},
      {path: 'AlcsReport', component:AlcsReportComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
