import { Component, OnInit } from '@angular/core';
import { ChartType } from 'chart.js';

@Component({
  selector: 'app-brs-landing-page',
  templateUrl: './brs-landing-page.component.html',
  styleUrls: ['./brs-landing-page.component.css']
})
export class BrsLandingPageComponent implements OnInit {

  constructor() { }
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Transaction Count',
          fontColor : '#004e98',
        },
        gridLines : {
          "display": true
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          // labelString: 'Vendors'
        },
        gridLines : {
          "display": true
        }
      }]
    },
    title : {
      display : true,
      text : "AXIS 18294",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels = ["Matched", "GroupMatched", "UnMatched"];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;
  public barChartData = [{ data : [2500,500,250], label : "Transaction"}];
  public colorOptions = [{backgroundColor: ['#30637F', '#D6B154', '#DDF56A']}]

  public barChartOptions1 = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'Transaction Count',
          fontColor : '#3262a8',
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          fontColor : '#3262a8',
          // labelString: 'Vendors'
        }
      }]
    },
    title : {
      display : true,
      text : "SBI 98342",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels1 = ["Matched", "GroupMatched", "Contra"];
  public barChartType1: ChartType = 'line';
  public barChartLegend1 = true;
  public barChartData1 = [{ data : [2500,500,250], backgroundColor: '#3262a8', label : "Transaction"}];

  public barChartOptions2 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "HDFC 062",
      fontSize : 14,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels2 = ["Matched", "GroupMatched", "UnMatched"];
  public barChartType2: ChartType = 'pie';
  public barChartLegend2 = true;
  public barChartData2 = [{ data : [2500,500,250], backgroundColor: ['#856969', '#CEC6C6', '#93C2D3']}];

  public barChartOptions3 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Recon Summary",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels3 = ["Loading", "Matched", "Completed"];
  public barChartType3: ChartType = 'doughnut';
  public barChartLegend3 = true;
  public barChartData3 = [{ data : [25,50,500], backgroundColor: ['#b8b2b7', '#ed87a9', '#6989b3']}];

  public barChartOptions4 = {
    scaleShowVerticalLines: false,
    responsive: true,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'No.of Transaction'
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          // labelString: 'Vendors'
        }
      }]
    },
    title : {
      display : true,
      text : "Fineshed Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels4 = ["label1", "label2", "label3", "label4"];
  public barChartType4: ChartType = 'horizontalBar';
  public barChartLegend4 = true;
  public barChartData4 = [{ data : [2,5,6,9], label : "Transaction"}];

  public barChartOptions5 = {
    scaleShowVerticalLines: false,
    responsive: true,
    indexAxis: 'y',
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'No.of Transaction',
          fontColor : '#3262a8',
        }
      }],
      xAxes: [{
        scaleLabel: {
          display: true,
          fontColor : '#3262a8',
          // labelString: 'Vendors'
        }
      }],
      legend: {
        position: 'right',
      },
    },
    title : {
      display : true,
      text : "Today's Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels5 = ["Matched", "GroupMatched", "open", "Loading"];
  public barChartType5: ChartType = 'line';
  public barChartLegend5 = true;
  public barChartData5 = [{ data : [10000,3000,250, 5000], backgroundColor: '#3262a8', label : "Transaction"}];

  public barChartOptions6 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Weekly Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels6 = ["Matched", "GroupMatched", "open"];
  public barChartType6: ChartType = 'pie';
  public barChartLegend6 = true;
  public barChartData6 = [{ data : [500,400,350], backgroundColor: ['#48CAE4','#e88bc6','#a89532']}];

  public barChartOptions7 = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Monthly Task",
      fontSize : 14,
      fontColor : '#48CAE4',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartLabels7 = ["Loading", "Matched", "Completed"];
  public barChartType7: ChartType = 'doughnut';
  public barChartLegend7 = true;
  public barChartData7 = [{ data : [25,50,80], backgroundColor: ['#b8b2b7', '#ed87a9', '#6989b3']}];

  public groupList : any;

  ngOnInit(): void {
  }

}
