import { Injectable } from '@angular/core';
import { ApiCallService } from './api-call.service';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConsolFilesTargetMappingService {

  public port : string = '50012';

  constructor(private http: HttpClient) { }

  public getTragetListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port + `/api/v1/consol_files/generic/target_files/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&sources_id=${prminputs["sources_id"]}&is_active=${prminputs["is_active"]}`);
    return this.http.get(resData["url"], resData["headers"]);
  }

  public getTargetDefinitionListFromServer(prminputs : any) {
    var resData = ApiCallService.authRequest(this.port + `/api/v1/consol_files/generic/target_files_definition/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&target_files_id=${prminputs["target_files_id"]}&is_active=${prminputs["is_active"]}`);
    return this.http.get(resData["url"], resData["headers"]);
  }


  public getActiveSourceListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port + `/api/v1/consol_files/generic/sources/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&is_active=yes`);
    return this.http.get(resData["url"], resData["headers"]);
  }

  public getSourceDefinitionsListFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port+`/api/v1/consol_files/generic/source_definitions/?tenants_id=${prminputs["tenants_id"]}&groups_id=${prminputs["groups_id"]}&entities_id=${prminputs["entities_id"]}&m_processing_layer_id=${prminputs["m_processing_layer_id"]}&m_processing_sub_layer_id=${prminputs["m_processing_sub_layer_id"]}&processing_layer_id=${prminputs["processing_layer_id"]}&sources_id=${prminputs["sources_id"]}&is_active=${prminputs["is_active"]}`);
    return this.http.get(resData["url"], resData["headers"]);
  }

  public getCreateTargetMappingToServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port + '/api/v1/consol_files/get_create_target_mapping/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }

  public getTargetMappingDetailsFromServer(prminputs : any) : any {
    var resData = ApiCallService.authRequest(this.port + '/api/v1/consol_files/get_target_mapping_details/');
    return this.http.post(resData["url"], prminputs, resData["headers"]);
  }

}
