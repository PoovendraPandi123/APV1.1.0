import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class SourcedefinitionService{
  lstReturn: any;
  public  port="50003";

  constructor(private httpClient: HttpClient, private router: Router, 
    private CS: CommonService) {
  }

  
  postsourcedefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_field_list_details/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getsourceFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getsourcedefinitionFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_definitions_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  postFileToServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/upload_files/');
    return this.CS.SendFileToAPI("post", resData, prminputs);
   
  }

  getsourcedefinitionfiledataFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_field_list/');
    return this.CS.SendToAPI("post", resData, prminputs);   
  }


}

