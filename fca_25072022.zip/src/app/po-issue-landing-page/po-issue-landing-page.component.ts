import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-po-issue-landing-page',
  templateUrl: './po-issue-landing-page.component.html',
  styleUrls: ['./po-issue-landing-page.component.css']
})
export class PoIssueLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
