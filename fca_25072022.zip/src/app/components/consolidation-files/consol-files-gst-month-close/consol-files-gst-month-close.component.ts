import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consol-files-gst-month-close',
  templateUrl: './consol-files-gst-month-close.component.html',
  styleUrls: ['./consol-files-gst-month-close.component.css']
})
export class ConsolFilesGstMonthCloseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
