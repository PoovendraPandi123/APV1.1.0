import { Component, OnInit } from '@angular/core';
import { ConsolFilesSourceRelationsService } from 'src/app/service/consol-files-source-relations.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ISourceRelations } from './consl-files-source-relations.model';

@Component({
  selector: 'app-consol-files-source-relations',
  templateUrl: './consol-files-source-relations.component.html',
  styleUrls: ['./consol-files-source-relations.component.css']
})
export class ConsolFilesSourceRelationsComponent implements OnInit {

  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public sourceList: any;
  public sourceIdChosen: string;
  public isRelation: string;
  public sourceRelationsList: ISourceRelations[];
  public isSourceRelationRequired: boolean[];

  constructor(private relationService: ConsolFilesSourceRelationsService, private ngxService: NgxUiLoaderService) { 
    this.sourceList = [];
    this.sourceIdChosen = '';
    this.isRelation = '';
  }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.sourceIdChosen = '-1';
    this.isRelation = '-1';
    this.getSourceList();
  }

  public getSourceList() : void {
    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.relationService.getSourceListFromServer(data)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Source List Response ", responseData);
        this.sourceList = responseData;
        this.ngxService.stop();
      },
      error : (error : any) => {
        console.log("Source List Error Response ", error);
        this.ngxService.stop();
      }
    })

  }

  public getSourceRelationsList() : void {
    
  }

  public getDisplaySourceRelations() : void {
    this.isSourceRelationRequired = [true];
    this.sourceRelationsList = [{
      sourceId : "-1"
    }];
  }

  public saveButtonClick() : void {
    if (this.sourceIdChosen == "-1")
    {
      alert("Kindly Choose the Source Name!!!");
    }
    else if (this.isRelation == "-1")
    {
      alert("Kindly Choose the Source is Related or Not!!!");
    }
    else
    {
      this.ngxService.start();

      this.ngxService.stop();
    }
  }

}
