export interface ISourceDefinitions {
    fieldName: string;
    fieldPosition: number;
    fieldDataType: string;
    fieldDateFormat: string;
    fieldMinimumLength: number;
    fieldMaximumLength: number;
    fieldUnique: string;
    fieldPrimaryDate: string;
    fieldStatus: string
}