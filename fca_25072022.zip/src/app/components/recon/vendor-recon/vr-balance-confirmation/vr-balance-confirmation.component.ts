import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { VrBalanceConfirmationService } from 'src/app/services/recon/vendor-recon/vr-balance-confirmation.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-vr-balance-confirmation',
  templateUrl: './vr-balance-confirmation.component.html',
  styleUrls: ['./vr-balance-confirmation.component.css']
})
export class VrBalanceConfirmationComponent implements OnInit {

  constructor(private balanceConfirmationSevice: VrBalanceConfirmationService, private ngxService: NgxUiLoaderService) { }

  public ngOnInit(): void {
  }

  public getSendMail() : void {
    this.ngxService.start();
    var data = {}
    this.balanceConfirmationSevice.sendMailToVendor(data)
    .subscribe(
      received_data => {
        let responseData = received_data;
        console.log(responseData);
        if (responseData["Status"] == "Success")
        {
          alert("Email Sent to the Vendor Successfully!!!");
        }
        else
        {
          alert("Error in Sending Email to the Vendor. Kindly contact Advents Support!!!");
        }
        this.ngxService.stop();
      },
      (error:any) => {
        this.HandleErrorResponse(error)
      }
    )
  }

  public HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

}
