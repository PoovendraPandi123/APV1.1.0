import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { AlcsreportService } from 'src/app/service/alcsreport.service';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { JsonToExcelService } from 'src/app/services/common/json-to-excel.service';

@Component({
  selector: 'app-alcs-report',
  templateUrl: './alcs-report.component.html',
  styleUrls: ['./alcs-report.component.css']
})
export class AlcsReportComponent implements OnInit {

  @ViewChild('content') content : ElementRef;

  public reportDate : any;
  public DailyLettersDisplayGrid : boolean;
  public pagination : boolean;
  public paginationSize : number;
  public alcsRowData : any;
  public alcsColumnDefs : any;
  public alcsType : string;
  public alcsTypeList : any;
  public userModelList : any;
  public tenantsId : number;
  public groupsId : number;
  public entitiesId : number;
  public mProcessingLayerId : number;
  public mProcessingSubLayerId : number;
  public processingLayerId : number;
  public alcsReportGridApi : any;
  public alcsReportGridColumnApi : any;
  public dailyLettersReportGridApi : any;
  public dailyLettersReportColumnApi : any;
  public alcsReportTypeList : any;
  public reportType: string;
  public alcsReportTypeEnable: boolean;
  public reportDownloadType: string;
  public buttonValue: string;
  public fileInputName: any;
  public utrFileUploadDivision: boolean;
  public fileUpload: any;
  public reportFileGenerated: string;
  public reportDownload: boolean;
  public alcsUploadTemplateColumnsList: any;
  public alcsReportActionType: string;
  public clickedData: any;
  public closeResult : any;
  public userDetails: any;
  public userId: number;
  public excelExportData: any;
  public todayDate: string;
  public processingLayerName: any;
  public AlcsDisplayGrid: boolean;
  public dailyLettersReportRowData: any;
  public dailyLettersReportColumnDefs: any;
  public excelExportDailyLettersData: any;

  @ViewChild('fileInput',  {static: false}) 
  fileInput : ElementRef;

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  constructor(private alcsReportService : AlcsreportService, private ngxService : NgxUiLoaderService, private modalService: NgbModal, private excelService: JsonToExcelService) 
  { 
    this.reportDate = '';
    this.DailyLettersDisplayGrid = false;
    this.pagination = false;
    this.paginationSize = 0;
    this.alcsRowData = [];
    this.alcsColumnDefs = [];
    this.alcsType = '';
    this.alcsTypeList = [];
    this.userModelList = [];
    this.tenantsId = 0;
    this.groupsId = 0;
    this.entitiesId = 0;
    this.mProcessingLayerId = 0;
    this.mProcessingSubLayerId = 0;
    this.processingLayerId = 0;
    this.alcsReportTypeList = [];
    this.reportType = '';
    this.alcsReportTypeEnable = false;
    this.reportDownloadType = '';
    this.buttonValue = '';
    this.fileInputName = '';
    this.utrFileUploadDivision = false;
    this.fileUpload = {};
    this.reportFileGenerated = '';
    this.reportDownload = false;
    this.alcsUploadTemplateColumnsList = [];
    this.alcsReportActionType = '';
    this.clickedData = [];
    this.userDetails = {};
    this.userId = 0;
    this.excelExportData = [];
    this.todayDate = '';
    this.processingLayerName = '';
    this.AlcsDisplayGrid = false;
    this.dailyLettersReportRowData = [];
    this.dailyLettersReportColumnDefs = [];
    this.excelExportDailyLettersData = [];
  }

  public ngOnInit(): void {
    this.buttonValue = 'Search';
    this.pagination = true;
    this.paginationSize = 20;
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userDetails = JSON.parse(sessionStorage.getItem("user_details"));
    this.tenantsId = this.userModelList["tenant_id"];
    this.groupsId = this.userModelList["group_id"];
    this.entitiesId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.userId = this.userDetails["user_id"];
    this.alcsType = '0';
    this.reportType = '0';
    this.initAlcsTypeList();
    this.initReportTypeList();
    this.initAlcsUploadTemplateColumnsList();
  }

  public getTodayDate() : void {
    var currentdate = new Date();
    var datetime = currentdate.getDate() + "_"+(currentdate.getMonth()+1) 
    + "_" + currentdate.getFullYear() + "_" 
    + currentdate.getHours() + "_Hrs_" 
    + currentdate.getMinutes() + "_Min_" + currentdate.getSeconds() + "_Sec";
    this.todayDate = datetime;
  }

  public initAlcsTypeList() : void {
    this.ngxService.start();
    let alcsTypeList = this.alcsReportService.getAlcsTypeList();
    let alcsTypeRequiredList = [];

    for (var i=0; i<alcsTypeList.length; i++)
    {
      if (this.entitiesId == alcsTypeList[i]["entity_id"])
      {
        alcsTypeRequiredList.push(alcsTypeList[i])
      }
    }

    this.alcsTypeList = alcsTypeRequiredList;
    this.ngxService.stop();
  }

  public initReportTypeList() : void {
    this.ngxService.start();
    this.alcsReportTypeList = this.alcsReportService.getReportTypeList();
    this.ngxService.stop();
  }

  public initAlcsUploadTemplateColumnsList() : void {
    this.ngxService.start();
    this.alcsUploadTemplateColumnsList = this.alcsReportService.getAlcsUploadTemplateColumns();
  }

  public getAlcsUploadTemplateColumnString() : string {
    var alcsUploadTemplateColumnsString = '';
    for (var i=0; i<this.alcsUploadTemplateColumnsList.length; i++)
    {
      alcsUploadTemplateColumnsString = alcsUploadTemplateColumnsString + ', ' + this.alcsUploadTemplateColumnsList[i];
    }
    return alcsUploadTemplateColumnsString;
  }

  public reportTypeChange() : void {
    this.AlcsDisplayGrid = false;
    this.DailyLettersDisplayGrid = false;

    if(this.reportType == 'alcs')
    {
      this.alcsReportTypeEnable = true;
    }
    else
    {
      this.alcsReportTypeEnable = false;
    }

    if (this.reportType == 'alcsUpload')
    {
      this.DailyLettersDisplayGrid = false;
      this.buttonValue = 'Upload';
      this.utrFileUploadDivision = true;
    }
    else
    {
      this.buttonValue = 'Search';
      this.utrFileUploadDivision = false;
    }
  }

  public alcsTypeChange() : void {
    for (let j=0; j<this.alcsTypeList.length; j++)
    {
      if (this.alcsType == this.alcsTypeList[j]["alcsType"])
      {
        this.processingLayerId = this.alcsTypeList[j]["processingLayerId"];
        this.processingLayerName = this.alcsTypeList[j]["alcsName"].replaceAll(" ", "_");
      }
    }
  }

  public getProcessingLayerId(alcsType) : number {
    for (var i=0; i<this.alcsTypeList.length; i++)
    {
      if (alcsType == this.alcsTypeList[i]["alcsType"])
      {
        return this.alcsTypeList[i]["processingLayerId"];
      }
    }
  }

  public buttonClick() : void {
    this.DailyLettersDisplayGrid = false;
    this.AlcsDisplayGrid = false;
    this.alcsColumnDefs = [];
    this.alcsRowData = [];

    if(this.reportType == '0')
    {
      alert("Please Choose Report Type!!!");
      this.alcsReportTypeEnable = false;
    }
    else if (this.reportDate == "")
    {
      alert("Please Choose Report Date!!!");
      this.DailyLettersDisplayGrid = false;
      this.AlcsDisplayGrid = false;
    }
    else if (this.reportType == 'alcs')
    {
      if (this.alcsType == '0')
      {
        alert("Please Choose ALCS Type!!!");
        this.DailyLettersDisplayGrid = false;
        this.AlcsDisplayGrid = false;
      }
      else if (this.reportDate == "")
      {
        alert("Please Choose Report Date!!!");
        this.DailyLettersDisplayGrid = false;
        this.AlcsDisplayGrid = false;
      }
      else
      {
        this.AlcsDisplayGrid = true;
        this.DailyLettersDisplayGrid = false;
        // this.setColumnDefinitions();
        // this.getReportValues();
        this.getALCSReport();
      }
    }
    else if (this.reportType == 'dailyLetters')
    {

      this.DailyLettersDisplayGrid = true;
      this.AlcsDisplayGrid = false;
      // this.setColumnDefinitions();
      this.getDailyLettersReport();
    }
    else if (this.reportType == 'alcsUpload')
    {
      this.DailyLettersDisplayGrid = false;
      this.AlcsDisplayGrid = false;
      this.reportDownload = false;
      this.postUtrFile();
    }

  }

  public setColumnDefinitions() : void {
    if (this.reportType == 'dailyLetters')
    {
      this.alcsColumnDefs = [
        {headerName: 'ALCS Type', field: 'int_reference_text_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Date', field: 'int_extracted_text_50',  sortable: true, filter: true, resizable: true},
        {headerName: 'Reissue/Manual', field: '', sortable: true, filter: true, resizable: true},
        {headerName: 'Total', field: 'int_amount_1', sortable: true, filter: true, resizable: true},
        {headerName: 'Letter Number', field: 'int_generated_num_2', sortable: true, filter: true, resizable: true},
        {headerName: '', field: ''},
        {headerName: '', field: ''},
        {headerName: '', field: ''},
        {headerName: 'Bank Date', field: 'int_reference_date_time_3', sortable: true, filter: true, resizable: true},
        {headerName: 'Bank Description', field: 'int_extracted_text_6', sortable: true, filter: true, resizable: true},
        {headerName: 'Bank Cheque/Ref Number', field: 'int_extracted_text_7', sortable: true, filter: true, resizable: true},
        {headerName: 'Bank Clearning Date', field: 'int_reference_date_time_4', sortable: true, filter: true, resizable: true},
        {headerName: 'Bank Debit Amount', field: 'int_amount_2', sortable: true, filter: true, resizable: true}
      ];

      this.reportDownloadType = this.reportType;
    }
  }

  public getProperDateFormat(dateString : string) : string {
    let date = dateString.split("T")[0];
    return date.split("-")[2] + "/" + date.split("-")[1] + "/" + date.split("-")[0];
  }

  public getReportValues() : void {
    this.ngxService.start();

    let params = {
      "tenantsId": this.tenantsId,
      "groupsId": this.groupsId,
      "entityId": this.entitiesId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.getProcessingLayerId(this.alcsType),
      "paymentDate": this.reportDate
    }

    // console.log("Report Values Input", params);

    this.alcsReportService.getReportFromServer(params)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        // console.log("Report Response", responseData);
        let rowData = responseData;
        rowData.forEach((item, index) => {
          if (item["int_reference_date_time_1"] != null)
          {
            item["int_reference_date_time_1"] = this.getProperDateFormat(item["int_reference_date_time_1"]);
          }
          else
          {
            item["int_reference_date_time_1"] = '';
          };

          if (item["int_reference_date_time_2"] != null)
          {
            item["int_reference_date_time_2"] = this.getProperDateFormat(item["int_reference_date_time_2"]);
          }
          else
          {
            item["int_reference_date_time_2"] = '';
          };

          if (item["int_reference_date_time_3"] != null)
          {
            item["int_reference_date_time_3"] = this.getProperDateFormat(item["int_reference_date_time_3"]);
          }
          else
          {
            item["int_reference_date_time_3"] = '';
          };

          if (item["int_reference_date_time_4"] != null)
          {
            item["int_reference_date_time_4"] = this.getProperDateFormat(item["int_reference_date_time_4"]);
          }
          else
          {
            item["int_reference_date_time_4"] = '';
          };
          
        });
        this.alcsRowData = rowData;
        this.ngxService.stop();
      },
      (error : any) => {
        this.HandleErrorResponse(error);
      }
    )
  }

  public getDailyLettersReport() : void {
    this.ngxService.start();
    let params = {
      "tenantsId": this.tenantsId,
      "groupsId": this.groupsId,
      "entitiesId": this.entitiesId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "paymentDate": this.reportDate
    }
    this.alcsReportService.getDailyLettersReportFromServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Daily Letters Report Response", responseData);
        if (responseData["Status"] == "Success")
        {
          let data = responseData["data"];
          let rowData = data["data"];
          let rowHeaders = data["headers"];
          // console.log("Daily Letters Report Response ", rowData);
          this.dailyLettersReportColumnDefs = rowHeaders;
          this.dailyLettersReportRowData = rowData;
          this.excelExportDailyLettersData = responseData["excel_export_data"];
          
          this.ngxService.stop();
        }
        else if (responseData["Status"] == "Error")
        {
          alert("Error in Generating Daily Letters Report. Please Contact Advents Support!!!");
          this.ngxService.stop();
        }
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public onAlcsReportGridReady(event : any) : void {
    this.alcsReportGridApi = event.api;
    this.alcsReportGridColumnApi = event.columnApi;
  }

  public onAlcsReportRowClicked(e : any) : void {
    if (e.event.target !== undefined) {
      let data = e.data;
      let alcsReportActionType = e.event.target.getAttribute("data-action-type");
      this.alcsReportActionType = alcsReportActionType;
      this.clickedData = data;
      switch (alcsReportActionType) {
        case 'Edit':
          return this.editAlcsReportData();
      }
    }
  };

  public onDailyLettersReportGridReady(event : any) : void {
    this.dailyLettersReportGridApi = event.api;
    this.dailyLettersReportColumnApi = event.columnApi;
  }
  
  public onDailyLettersReportRowClicked(e : any) : void {

  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public editAlcsReportData() : void {
    this.open(this.content);
  }

  public updateAlcsDetails() : void {
    this.ngxService.start();
    const DATE_TIME_FORMAT = 'YYYY-MM-DDTHH:mm:ss'; 
    let dateTime = new Date().toISOString();
    let params = {
      "id": this.clickedData["id"],
      "int_processing_status_1": "Rejected",
      "modified_by": this.userId,
      "modified_date": dateTime
    };
    this.alcsReportService.rejectAlcsDataToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Alcs Reject Response ", responseData);
        if (responseData["id"] == this.clickedData["id"])
        {
          this.getReportValues();
          this.ngxService.stop();
          alert("Record Rejected Successfully!!!");
        }
        else
        {
          alert("Error in Updating Record. Kindly contact Advents Support!!!");
          this.ngxService.stop();
        }
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    }
  }

  public onExportButtonClick(): void {
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'ALCS_Report_' + this.reportDownloadType + "_" + this.reportDate +'.csv'
    };
    this.alcsReportGridApi.exportDataAsCsv(params);
  }

  public fileOnChange(event : any) : void {
    let files = event.target.files;
    this.fileInputName = files[0];
  };

  public postUtrFile() : void {
    if (this.fileInputName == '' || this.fileInputName === undefined)
    {
      alert("Please Choose ALCS UTR Upload Template and give Upload.");
    }
    else if (this.fileInputName.name.split(".")[this.fileInputName.name.split(".").length - 1] === 'csv')
    {
      this.ngxService.start();
      const formData = new FormData();

      formData.append("fileName", this.fileInputName);
      formData.append("tenantsId", String(this.tenantsId));
      formData.append("groupsId", String(this.groupsId));
      formData.append("entityId", String(this.entitiesId));
      formData.append("mProcessingLayerId", String(this.mProcessingLayerId));
      formData.append("mProcessingSubLayerId", String(this.mProcessingSubLayerId));
      formData.append("paymentDate", this.reportDate);

      this.fileUpload = formData;

      this.alcsReportService.postUtrFileToServer(this.fileUpload)
      .subscribe(
        receivedData => {
          let resData = receivedData;
          console.log("Post UTR File to Server Response, ", resData);
          if (resData["Status"] == "Success")
          {
            this.reportDownload = true;
            this.reportFileGenerated = resData["report_url"];
            this.fileInput.nativeElement.value = '';
            this.fileInputName = undefined;
            this.ngxService.stop();
          }
          else if (resData["Status"] == "columnMismatch")
          {
            alert("Found Column Mismatch. Please Check the columns in ALCS Template. It should be " + this.getAlcsUploadTemplateColumnString());
            this.fileInput.nativeElement.value = '';
            this.fileInputName = undefined;
            this.ngxService.stop();
          }
          else if (resData["Status"] == "columnCount")
          {
            alert("Found Column Count MistMatch. It Should be 13 columns in ALCS Upload Template. Please Check the file and reupload!!!");
            this.ngxService.stop();
          }
          else if (resData["Status"] == "Error")
          {
            alert("Error in Updating UTR for ALCS Upload Template Uploaded. Kindly contact Advents Support!!!");
            this.ngxService.stop();
          }
          else if (resData["Status"] == "NoData")
          {
            alert("No Records Found in the Uploaded File. Please Check the file and reupload!!!");
            this.ngxService.stop();
          }
        }
      ),
      (error : any) => {
        this.HandleErrorResponse(error);
        this.fileInput.nativeElement.value = '';
        this.fileInputName = undefined;
        this.ngxService.stop();
      }
    }
    else
    {
      alert("Please Choose the Proper File Type for ALCS Template and Upload!!!");
    }
  }

  public getALCSReport() : void {

    this.ngxService.start();

    let params = {
      "tenantsId": this.tenantsId,
      "groupsId": this.groupsId,
      "entitiesId": this.entitiesId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processingLayerId,
      "reportDate": this.reportDate
    };
    
    console.log("ALCS Report Params ", params);

    this.alcsReportService.getAlcsReportFromServer(params)
    .subscribe({
      next : (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get ALCS Report Response ", responseData);
        
        let recordsColumnDefs = responseData["data"]["headers"];
        let recordsRowData = responseData["data"]["data"];
        this.excelExportData = responseData["excel_data"];

        recordsColumnDefs.forEach((item, index) => {
          if (item.sortable == "true")
          {
            if(index == 0)
            {
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
              item.template = `
                <a>
                  <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
                </a>
              `
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            };

            if (item.field == "id")
            {
              item["hide"] = true;
            }
          }
        });

        this.alcsColumnDefs = recordsColumnDefs;
        this.alcsRowData = recordsRowData;

        this.ngxService.stop();
      },
      error : (error : any) => {
        console.log("Get ALCS Report Error", error);
        this.ngxService.stop();
      }
    });
  }

  public onExportAlcsReportXlsxClick() : void {
    this.ngxService.start();
    this.getTodayDate();
    // console.log("Excel Export Data", this.excelExportData);
    this.excelService.exportAsExcelFile(this.excelExportData, "ALCS_Report_" + this.processingLayerName + "_" + this.todayDate);
    this.ngxService.stop();
  }

  public onExportDailyLettersXlsxClick() : void {
    this.ngxService.start();
    this.getTodayDate();
    this.excelService.exportAsExcelFile(this.excelExportDailyLettersData, "Daily_Letters_Report_" + this.processingLayerName + "_" + this.todayDate);
    this.ngxService.stop();
  }


  public HandleErrorResponse(err : any)
  {
    console.log("Error", err);
  }
}
