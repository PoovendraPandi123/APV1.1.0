import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SourceService {
  lstReturn: any;
  public  port="50003";
  // public  port1="10002";

  constructor(private httpClient: HttpClient, private router: Router, 
    // private Util: Util, 
    private CS: CommonService) {
  }

  
  postsourceFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/update_source/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getsourceFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/source_list/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getDatabaseValuesFromServer(prminputs)
  {
    var resData = CommonService.authReq(this.port+'/source/get_database_values/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

  postSourceToServer(prminputs)
  {
    var resData = CommonService.authReq(this.port+'/source/get_insert_source/');
    return this.CS.SendToAPI("post", resData, prminputs);
  }

}
