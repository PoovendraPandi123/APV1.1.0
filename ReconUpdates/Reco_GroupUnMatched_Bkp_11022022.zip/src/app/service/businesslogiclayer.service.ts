import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { CommonService } from './common.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class BusinesslogiclayerService {
  lstReturn: any;
  public  port="50003";
  
  constructor(private httpClient: HttpClient, private router: Router, 
    private CS: CommonService) {
  }

  
  postbusinesslogiclayerFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/update_business_layer/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }

  getbusinesslogicFromServer(prminputs) {
    var resData = CommonService.authReq(this.port+'/source/business_layer_source/');
    return this.CS.SendToAPI("post", resData, prminputs);
   
  }
}
