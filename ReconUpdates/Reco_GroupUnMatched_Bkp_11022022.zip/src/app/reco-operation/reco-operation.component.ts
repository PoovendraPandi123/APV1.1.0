import { Component, OnInit, ViewChild } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { ChartType} from 'chart.js';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/auth.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-reco-operation',
  templateUrl: './reco-operation.component.html',
  styleUrls: ['./reco-operation.component.css']
})
export class RecoOperationComponent implements OnInit {

  @ViewChild('agGrid')
  agGrid!: AgGridAngular;

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Reconciliation Summary",
      fontSize : 16,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : true
    }
  };
  public barChartOptionsTransaction = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "Transaction Type",
      fontSize : 16,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartOptionsBrs = {
    scaleShowVerticalLines: false,
    responsive: true,
    title : {
      display : true,
      text : "BRS",
      fontSize : 16,
      fontColor : '#004e98',
    },
    legend : {
      position : "right",
      display : false
    }
  };
  public barChartLabels = [] as any;
  public barChartLabelsTransaction = ["Sweep", "Letters", "UTR", "Transfers"]
  public barChartLabelsBrs = ["GL Debits", "GL Credits", "Bank Debits", "Bank Credits"]
  public barChartType: ChartType = 'doughnut';
  public barChartTypeTransaction: ChartType = 'bar';
  public barChartTypeBrs: ChartType = 'bar';
  public barChartLegend = true;
  public barChartLegendTransaction = true;
  public barChartLegendBrs = true;
  public barChartData = [{ data : []}] as any;
  public barChartDataTransaction = [{data: [100, 247, 326, 451]}];
  public barChartDataBrs = [{data: [15248756, 1548745, 2354789, 567845]}];
  public colorOptions : any;
  public colorOptionsTransaction = [{backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400']}]
  public colorOptionsBrs = [{backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400']}];

  public userModelList: any;
  public tenantId : any;
  public groupId : any;
  public entityId : any;
  public mProcessingLayerId : any;
  public mProcessingSubLayerId : any;
  public userId : any;
  public processingLayerIdsUser : any;
  public processingLayerList : any;
  public selectProcessingLayer : any;
  public processing_layer_id : Number;
  public pagination : boolean = false;
  public paginationSize : Number = 0;

  public matchedSearchGrid: boolean = false;
  public unMatchedSearchGrid: boolean = false;
  public groupMatchedSearchGrid: boolean = false;
  public contraSearchGrid: boolean = false;
  public groupUnMatchedSearchGrid: boolean = false;

  public matchedDisplayGrid:boolean = false;
  public groupMatchedDisplayGrid: boolean = false;
  public unMatchedDisplayGrid:boolean = false;
  public contraDisplayGrid: boolean = false;
  public groupUnMatchedDisplayGrid: boolean = false;

  public displaySelectedMatchedGrid:boolean = false;
  public displaySelectedUnMatchedGrid:boolean = false;
  public displaySelectedGroupMatchedGrid: boolean = false;
  public displaySelectedContraGrid: boolean = false;
  public displaySelectedGroupUnMatchedGrid: boolean = false;

  public displaySelectedExternalGridContra: boolean = false;
  public displaySelectedInternalGridContra: boolean = false;

  public externalColumnDefs : any;
  public internalColumnDefs : any;
  public unMatchedExternalColumnDefs : any;
  public unMatchedInternalColumnDefs : any;
  public groupMatchedExternalColumnDefs : any;
  public groupMatchedInternalColumnDefs : any;
  public contraExternalColumnDefs : any;
  public contraInternalColumnDefs : any;
  public groupUnMatchedExternalColumnDefs : any;
  public groupUnMatchedInternalColumnDefs : any;

  public selectedUnMatchedExternalColumnDefs : any;
  public selectedUnMatchedInternalColumnDefs : any;
  public selectedGroupMatchedExternalColumnDefs: any;
  public selectedGroupMatchedInternalColumnDefs: any;
  public selectedContraExternalColumnDefs: any;
  public selectedContraInternalColumnDefs: any;
  public selectedGroupUnMatchedExternalColumnDefs: any;
  public selectedGroupUnMatchedInternalColumnDefs: any;

  public externalRowData : any;
  public internalRowData : any;
  public unMatchedExternalRowData : any;
  public unMatchedInternalRowData : any;
  public groupMatchedExternalRowData : any;
  public groupMatchedInternalRowData : any;
  public contraExternalRowData : any;
  public contraInternalRowData : any;
  public groupUnMatchedExternalRowData : any;
  public groupUnMatchedInternalRowData : any;

  public selectedUnMatchedExternalRowData : any;
  public selectedUnMatchedInternalRowData : any;
  public selectedGroupMatchedExternalRowData: any;
  public selectedGroupMatchedInternalRowData: any;
  public selectedContraExternalRowData: any;
  public selectedContraInternalRowData: any;
  public selectedGroupUnMatchedExternalRowData: any;
  public selectedGroupUnMatchedInternalRowData: any;

  public selectedExternalRowData : any;
  public SelectedinternalRowData : any;
  
  public externalGridApi : any;
  public internalGridApi : any;
  public externalUnMatchedGridApi : any;
  public internalUnMatchedGridApi : any;
  public externalGroupMatchedGridApi : any;
  public internalGroupMatchedGridApi : any;
  public externalContraGridApi: any;
  public internalContraGridApi: any;
  public externalGroupUnMatchedGridApi: any;
  public internalGroupUnMatchedGridApi: any;
  
  public externalGridColumnApi : any;
  public internalGridColumnApi : any;
  public externalUnMatchedGridColumnApi : any;
  public internalUnMatchedgridColumnApi : any;
  public externalGroupMatchedGridColumnApi : any;
  public internalGroupMatchedGridColummApi : any;
  public externalContraGridColumnApi : any;
  public internalContraGridColumnApi : any;
  public externalGroupUnMatchedColumnApi : any;
  public internalGroupUnMatchedColumnApi : any;

  public searchValue : any;
  public searchValueUnMatched : any;
  public searchValueGroupMatched : any;
  public searchValueContra: any;
  public searchValueGroupUnMatched : any;
  
  public matchButtonEnable : boolean = false;
  public contraButtonEnable: boolean = false;
  public contraUnmatchButtonEnable: boolean = false;

  public groupMatchButtonDisabled : boolean = true;
  public groupUnMatchedMatchButton : boolean;
  public groupUnMatchedUnMatchButton : boolean;

  public amountTolerance : any;
  
  public selectedUnMatchedExternalAmount : Number = 0.00;
  public selectedUnMatchedInternalAmount : Number = 0.00;
  public selectedGroupedUnMatchedExternalAmount : Number = 0.00;
  public selectedGroupedUnMatchedInternalAmount : Number = 0.00;

  public totalSelectedUnMatchedAmount : Number = 0.00;

  constructor(public http:HttpClient, public obj_auth_service: AuthService, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.userModelList = JSON.parse(sessionStorage.getItem("user_model_list"));
    this.userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerIdsUser = this.userModelList["processing_layer_ids"];
    this.getTransactionCount();
    this.getProcessingLayerList();
    this.selectProcessingLayer = {
      "processing_layer_id":0
    };
    this.pagination = true;
    this.paginationSize = 10;
    this.groupUnMatchedMatchButton = false;
    this.groupUnMatchedUnMatchButton = false;
    // console.log(sessionStorage);
  }

  getProcessingLayerList(){
    this.ngxService.start();
    // console.log(this.userModelList);
    let data = {
      "tenantId" : this.tenantId,
      "groupId" : this.groupId,
      "entityId" : this.entityId,
      "mProcessingLayerId" : this.mProcessingLayerId,
      "mProcessingSubLayerId" : this.mProcessingSubLayerId,
      "typeId": JSON.parse(sessionStorage.getItem("user_model_list"))["type_id"]
    }

    this.obj_auth_service.getProcessingLayerListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Processing Layer List Response: ", response_data);
        this.processingLayerList = response_data["processing_layer_list"];
        this.ngxService.stop();
      }
    )

  }

  getSelectedProcessingLayer(processingLayerId){
    this.ngxService.start();
    let processing_layer_id = Number(processingLayerId);
    this.processing_layer_id = Number(processingLayerId);

    let data = {
      "tenant_id" : this.tenantId,
      "group_id" : this.groupId,
      "entity_id" : this.entityId,
      "m_processing_layer_id" : this.mProcessingLayerId,
      "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
      "processing_layer_id" : processing_layer_id
    }

    this.matchedDisplayGrid = false; // Hide the Matched grid
    this.unMatchedDisplayGrid = false; // Hide the Unmatched grid
    this.groupMatchedDisplayGrid = false; // Hide the Group Matched grid
    this.contraDisplayGrid = false; // Hide the Contra Grid
    this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid

    this.displaySelectedMatchedGrid = false; // Hide the Selected Matched Grid
    this.displaySelectedGroupMatchedGrid = false; // Hide the Selected Group Matched Grid
    this.displaySelectedUnMatchedGrid = false; // Hide the Selected UnMatched Grid
    this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
    this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid

    this.matchedSearchGrid = false; // Hide the Matched Search Option
    this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
    this.groupMatchedSearchGrid = false; // Hide the Group Matched Search Option
    this.contraSearchGrid = false; // Hide the Contra Search Option
    this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option

    // Setting the column and Row definitions of grids to undefined
    this.externalColumnDefs = undefined;
    this.externalRowData = undefined;
    this.internalColumnDefs = undefined;
    this.internalRowData = undefined;

    this.unMatchedExternalColumnDefs = undefined;
    this.unMatchedExternalRowData = undefined;
    this.unMatchedInternalColumnDefs = undefined;
    this.unMatchedInternalRowData = undefined;

    this.contraExternalColumnDefs = undefined;
    this.contraExternalRowData = undefined;
    this.contraInternalColumnDefs = undefined;
    this.contraInternalRowData = undefined;

    this.groupMatchedExternalColumnDefs = undefined;
    this.groupMatchedExternalRowData = undefined;
    this.groupMatchedInternalColumnDefs = undefined;
    this.groupMatchedInternalRowData = undefined;

    this.groupUnMatchedExternalColumnDefs = undefined;
    this.groupUnMatchedExternalRowData = undefined;
    this.groupUnMatchedInternalColumnDefs = undefined;
    this.groupUnMatchedInternalRowData = undefined;

    this.selectedUnMatchedExternalColumnDefs = undefined;
    this.selectedUnMatchedExternalRowData = undefined;
    this.selectedUnMatchedInternalColumnDefs = undefined;
    this.selectedUnMatchedInternalRowData = undefined;

    this.selectedContraExternalRowData = undefined;
    this.selectedContraExternalColumnDefs = undefined;
    this.selectedContraInternalColumnDefs = undefined;
    this.selectedContraInternalRowData = undefined;

    this.selectedGroupMatchedInternalRowData = undefined;
    this.selectedGroupMatchedInternalColumnDefs = undefined;
    this.selectedGroupMatchedExternalRowData = undefined;
    this.selectedGroupMatchedExternalColumnDefs = undefined;

    this.selectedGroupUnMatchedExternalColumnDefs = undefined;
    this.selectedGroupUnMatchedInternalColumnDefs = undefined;
    this.selectedGroupUnMatchedExternalRowData = undefined;
    this.selectedGroupUnMatchedInternalRowData = undefined;

    if (processing_layer_id != 0)
    {
      this.obj_auth_service.getTransactionCountFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          console.log("All Data Response: ", response_data);
          this.barChartLabels = response_data["label"];
          this.barChartData = [
            {
              data : response_data["data"]
            }
          ];
          this.colorOptions = [
            {
              backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400', '#948bf8']
            }
          ];
          this.ngxService.stop();
      },
      (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
    }
    else if(processing_layer_id == 0)
    {
      this.getTransactionCount();
      this.ngxService.stop();
    }
  }

  getTransactionCount(){
    this.ngxService.start();
    let processing_layer_id = 0;

    let data = {
      "tenant_id" : this.tenantId,
      "group_id" : this.groupId,
      "entity_id" : this.entityId,
      "m_processing_layer_id" : this.mProcessingLayerId,
      "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
      "processing_layer_id" : processing_layer_id
    }

    this.obj_auth_service.getTransactionCountFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("All Data Response: ", response_data);
        this.barChartLabels = response_data["label"];
        this.barChartData = [
          {
            data : response_data["data"]
          }
        ];
        this.colorOptions = [
          {
            backgroundColor: ['#acc3a6', '#547caf', '#e8cabf', '#ffa400', '#948bf8']
          }
        ];
        this.ngxService.stop();
      },
      (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      }
    )

  }

  onChartClick(event: any){
    if (this.processing_layer_id === undefined || this.processing_layer_id == 0)
    {
      alert("Kindly Choose Reconciliation Type!!!");
    }
    else
    {
      // this.ngxService.start();
      if (event.active.length > 0) {
        const chart = event.active[0]._chart;
        const activePoints = chart.getElementAtEvent(event.event);
        if ( activePoints.length > 0) 
        {
          // get the internal index of slice in pie chart
          const clickedElementIndex = activePoints[0]._index;
          const label = chart.data.labels[clickedElementIndex];
          // get value by index
          const value = chart.data.datasets[0].data[clickedElementIndex];
          // console.log(clickedElementIndex, label, value);
          console.log(label);

          let processing_layer_id = this.processing_layer_id;
          let record_status = label;

          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : processing_layer_id,
            "record_status" : record_status
          }

          if(record_status === "Matched")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = true; // Display the Matched Search Option
            this.matchedDisplayGrid = true; // Display the Matched grid
            this.unMatchedDisplayGrid = false; // Hide the Unmatched grid
            this.displaySelectedMatchedGrid = false; // Display the Selected Matched grid
            this.displaySelectedUnMatchedGrid = false; // Hide the Selected UnMatched grid
            this.groupMatchedDisplayGrid = false; // Hide the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Hide the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the Selected Group Matched Grid
            this.contraSearchGrid = false; // Hide the Contra Search Option
            this.contraDisplayGrid = false; // Hide the Contra Gid
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.matchedGridShow(data);
          }
          else if(record_status === "UnMatched")
          {
            this.unMatchedSearchGrid = true; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched grid
            this.unMatchedDisplayGrid = true; // Display the Unmatched grid
            this.displaySelectedMatchedGrid = false; // Hide the Selected Matched grid
            this.displaySelectedUnMatchedGrid = false; // Hide the Selected UnMatched grid
            this.groupMatchedDisplayGrid = false; // Hide the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Hide the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the Selected Group Matched Grid
            this.contraSearchGrid = false; // Hide the Contra Search Option
            this.contraDisplayGrid = false; // Hide the Contra Gid
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.unMatchedGridShow(data);
          }
          else if(record_status === "GroupMatched")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched Grid
            this.unMatchedDisplayGrid = false;  // Hide the UnMatched Grid
            this.displaySelectedMatchedGrid = false; // Hide the Selectd Matched Grid
            this.displaySelectedUnMatchedGrid = false;  // Hide the Selected UnMatched Grid
            this.groupMatchedDisplayGrid = true; // Display the Group Matched Grid
            this.groupMatchedSearchGrid = true; // Disaply the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the selected Group Matched Grid
            this.contraSearchGrid = false; // Hide the Contra Search Option
            this.contraDisplayGrid = false; // Hide the Contra Gid
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.groupMatchedShow(data);
          }
          else if(record_status === "Contra")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched Grid
            this.unMatchedDisplayGrid = false;  // Hide the UnMatched Grid
            this.displaySelectedMatchedGrid = false; // Hide the Selectd Matched Grid
            this.displaySelectedUnMatchedGrid = false;  // Hide the Selected UnMatched Grid
            this.groupMatchedDisplayGrid = false; // Display the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Disaply the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the selected Group Matched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.contraSearchGrid = true; // Display the Contra Search Option
            this.contraDisplayGrid = true; // Display the Contra Gid
            this.groupUnMatchedDisplayGrid = false; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = false; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.contraShow(data);
          }
          else if(record_status === "GroupUnMatched")
          {
            this.unMatchedSearchGrid = false; // Hide the UnMatched Search Option
            this.matchedSearchGrid = false; // Hide the Matched Search Option
            this.matchedDisplayGrid = false; // Hide the Matched Grid
            this.unMatchedDisplayGrid = false;  // Hide the UnMatched Grid
            this.displaySelectedMatchedGrid = false; // Hide the Selectd Matched Grid
            this.displaySelectedUnMatchedGrid = false;  // Hide the Selected UnMatched Grid
            this.groupMatchedDisplayGrid = false; // Display the Group Matched Grid
            this.groupMatchedSearchGrid = false; // Disaply the Group Matched Search Option
            this.displaySelectedGroupMatchedGrid = false; // Hide the selected Group Matched Grid
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.displaySelectedContraGrid = false; // Hide the Selected Contra Grid
            this.contraSearchGrid = false; // Display the Contra Search Option
            this.contraDisplayGrid = false; // Display the Contra Gid
            this.groupUnMatchedDisplayGrid = true; // Hide the Group UnMatched Grid
            this.groupUnMatchedSearchGrid = true; // Hide the Group UnMatched Search Option
            this.displaySelectedGroupUnMatchedGrid = false; // Hide the Selected Group UnMatched Grid
            this.groupUnMatchedShow(data);
          }
        }
      }
    }
    // this.ngxService.stop();
  }

  matchedGridShow(data)
  {
    this.ngxService.start();
    this.obj_auth_service.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Matched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        // console.log(externalRecordsAllColumnDefs);

        this.externalColumnDefs = externalRecordsAllColumnDefs;
        this.externalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.internalColumnDefs = internalRecordsAllColumnDefs;
        this.internalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  onExternalGridReady(params){
    this.externalGridApi = params.api;
    this.externalGridColumnApi = params.columnApi;
  }

  onInternalGridReady(params){
    this.internalGridApi = params.api;
    this.internalGridColumnApi = params.columnApi;
  }

  quickSearch(){
    this.internalGridApi.setQuickFilter(this.searchValue);
    this.externalGridApi.setQuickFilter(this.searchValue);
  }

  onExportButtonClick(){
    const params = {
      columnGroups: true,
      allColumns: false,
      fileName: 'file.csv'
    };
    this.externalGridApi.exportDataAsCsv(params);
  }

  onExternalSelectionChanged(params){
    try 
    {
      this.ngxService.start();
      this.displaySelectedMatchedGrid = true;
      this.selectedExternalRowData = params.api.getSelectedRows();

      let selectedExternalRecordsId = this.selectedExternalRowData[0]["external_records_id"];

      console.log(selectedExternalRecordsId);

      let data = {
        "tenant_id" : this.tenantId,
        "group_id" : this.groupId,
        "entity_id" : this.entityId,
        "m_processing_layer_id" : this.mProcessingLayerId,
        "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
        "processing_layer_id" : this.processing_layer_id,
        "external_records_id" : selectedExternalRecordsId
      }

      this.obj_auth_service.getIntExtRecordsFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          let internalRecords = response_data["internal_records"]["data"];
          console.log("Selected Internal Row Response: ", response_data);
          this.SelectedinternalRowData = internalRecords;
          this.ngxService.stop();
        },(error:any) => {this.HandleErrorResponse(error)})
    } 
    catch(error) 
    {
      this.SelectedinternalRowData = '';
      this.displaySelectedMatchedGrid = false;
      this.ngxService.stop();
    }
  }

  onInternalSelectionChanged(params){
    try
    {
      this.ngxService.start();
      this.displaySelectedMatchedGrid = true;
      this.SelectedinternalRowData = params.api.getSelectedRows();
      var selectedInternalRecordsId = this.SelectedinternalRowData[0]["internal_records_id"];
  
      let data = {
        "tenant_id" : this.tenantId,
        "group_id" : this.groupId,
        "entity_id" : this.entityId,
        "m_processing_layer_id" : this.mProcessingLayerId,
        "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
        "processing_layer_id" : this.processing_layer_id,
        "internal_records_id" : selectedInternalRecordsId
      }
  
      this.obj_auth_service.getIntExtRecordsFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          let externalRecords = response_data["external_records"]["data"];
          console.log("Selected External Row Response: ", response_data);
          this.selectedExternalRowData = externalRecords;
          this.ngxService.stop();
        },(error:any) => {this.HandleErrorResponse(error)})
    }
    catch(error)
    {
      this.selectedExternalRowData = '';
      this.displaySelectedMatchedGrid = false;
      this.ngxService.stop();
    }

  }

  unMatchedGridShow(data)
  {
    this.ngxService.start();
    this.obj_auth_service.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("UnMatched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["headerCheckboxSelection"] = true;
              item["headerCheckboxSelectionFilteredOnly"] = true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.unMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
        this.unMatchedExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["headerCheckboxSelection"] = true;
              item["headerCheckboxSelectionFilteredOnly"] = true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.unMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
        this.unMatchedInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();
        
      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  onUnMatchedExternalGridReady(params){
    this.externalUnMatchedGridApi = params.api;
    this.externalUnMatchedGridColumnApi = params.columnApi;
  }

  onUnMatchedInternalGridReady(params){
    this.internalUnMatchedGridApi = params.api;
    this.internalUnMatchedgridColumnApi = params.columnApi;
  }

  quickSearchUnMatched(){
    this.externalUnMatchedGridApi.setQuickFilter(this.searchValueUnMatched);
    this.internalUnMatchedGridApi.setQuickFilter(this.searchValueUnMatched);
  }

  onUnMatchedExternalSelectionChanged(params){  
    let processingLayerId = this.processing_layer_id;
    let headerSide = "External";
    
    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": processingLayerId,
      "headerSide": headerSide
    }

    this.obj_auth_service.getInternalExternalHeadersFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log(responseData);
        if (responseData["Status"] === "Success")
        {
          let externalHeaders = responseData["external_records"]["headers"];
          externalHeaders.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["headerCheckboxSelection"] = true;
                item["headerCheckboxSelectionFilteredOnly"] = true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedUnMatchedExternalColumnDefs = externalHeaders;
        }
    }, (error : any) => {this.HandleErrorResponse(error)});


    this.selectedUnMatchedExternalRowData = params.api.getSelectedRows();
    
    if(this.selectedUnMatchedExternalRowData.length == 0 && this.selectedUnMatchedInternalRowData.length == 0)
    {
      console.log(this.selectedUnMatchedExternalRowData.length);
      this.displaySelectedUnMatchedGrid = false;
    }
    else if(this.selectedUnMatchedExternalRowData.length > 0 || this.selectedUnMatchedInternalRowData.length > 0)
    {
      this.displaySelectedUnMatchedGrid = true;
      let selectedExternalDebitAmount = 0.00;
      let selectedExternalCreditAmount = 0.00;
      for(let i:number = 0; i<this.selectedUnMatchedExternalRowData.length; i++)
      {
        selectedExternalDebitAmount = selectedExternalDebitAmount + parseFloat(this.selectedUnMatchedExternalRowData[i].external_debit);
        selectedExternalCreditAmount = selectedExternalCreditAmount + parseFloat(this.selectedUnMatchedExternalRowData[i].external_credit);
        this.selectedUnMatchedExternalAmount = selectedExternalDebitAmount + selectedExternalCreditAmount;
      }

      if(Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0 && Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0)
      {
        if(this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length > 0)
        {
          this.contraButtonEnable = false;
        }
        else
        {
          this.contraButtonEnable = true;
        }
        
      }
      else if(Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) > 0 || Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) > 0)
      {
        this.contraButtonEnable = false;
      }
      else if(Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0 || Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0)
      {
        this.contraButtonEnable = true;
      }
    }

    if (this.selectedUnMatchedInternalRowData.length === 0)
    {
      this.selectedUnMatchedInternalAmount = 0.00;
    }

    if (this.selectedUnMatchedExternalRowData.length === 0)
    {
      this.selectedUnMatchedExternalAmount = 0.00;
    }

    if(this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length > 0)
    {
      let amountTolerance = Number(this.amountTolerance);
      let selectedUnMatchedInternalAmount = Number(this.selectedUnMatchedInternalAmount);
      let selectedUnMatchedExternalAmount = Number(this.selectedUnMatchedExternalAmount);
      // let totalSelectedUnMatchedAmountString = Number(String(selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount).replace("-", ""));
      this.totalSelectedUnMatchedAmount = Number(String(selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount).replace("-", ""));
  
      if(this.totalSelectedUnMatchedAmount <= amountTolerance)
      {
        this.matchButtonEnable = true;
      }
      else
      {
        this.matchButtonEnable = false;
      }
    }
    
    if((this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length === 0) || (this.selectedUnMatchedInternalRowData.length > 0 && this.selectedUnMatchedExternalRowData.length === 0))
    {
      this.matchButtonEnable = false;
    }
    else
    {
      this.matchButtonEnable = true;
    }

  }

  onUnMatchedInternalSelectionChanged(params){
    let processingLayerId = this.processing_layer_id;
    let headerSide = "Internal";
    
    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": processingLayerId,
      "headerSide": headerSide
    }

    this.obj_auth_service.getInternalExternalHeadersFromServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log(responseData);
        if (responseData["Status"] === "Success")
        {
          let internalHeaders = responseData["internal_records"]["headers"];
          internalHeaders.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["headerCheckboxSelection"] = true;
                item["headerCheckboxSelectionFilteredOnly"] = true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedUnMatchedInternalColumnDefs = internalHeaders;
        }
    }, (error : any) => {this.HandleErrorResponse(error)});

    this.selectedUnMatchedInternalRowData = params.api.getSelectedRows();
    if(this.selectedUnMatchedExternalRowData.length == 0 && this.selectedUnMatchedInternalRowData.length == 0)
    {
      this.displaySelectedUnMatchedGrid = false;
    }
    else if(this.selectedUnMatchedExternalRowData.length > 0 || this.selectedUnMatchedInternalRowData.length > 0)
    {
      this.displaySelectedUnMatchedGrid = true;
      let selectedInternalDebitAmount = 0.00;
      let selectedInternalCreditAmount = 0.00;
      for(let i:number = 0; i<this.selectedUnMatchedInternalRowData.length; i++)
      {
        selectedInternalDebitAmount = selectedInternalDebitAmount + parseFloat(this.selectedUnMatchedInternalRowData[i].internal_debit);
        selectedInternalCreditAmount = selectedInternalCreditAmount + parseFloat(this.selectedUnMatchedInternalRowData[i].internal_credit);
        this.selectedUnMatchedInternalAmount = selectedInternalDebitAmount + selectedInternalCreditAmount;
      }

      if(Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0 && Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0)
      {
        if(this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length > 0)
        {
          this.contraButtonEnable = false;
        }
        else
        {
          this.contraButtonEnable = true;
        }
        
      }
      else if(Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) > 0 || Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) > 0)
      {
        this.contraButtonEnable = false;
      }
      else if(Number(String(this.selectedUnMatchedInternalAmount).replace("-", "")) === 0 || Number(String(this.selectedUnMatchedExternalAmount).replace("-", "")) === 0)
      {
        this.contraButtonEnable = true;
      }
    }

    if (this.selectedUnMatchedInternalRowData.length === 0)
    {
      this.selectedUnMatchedInternalAmount = 0.00;
    }

    if (this.selectedUnMatchedExternalRowData.length === 0)
    {
      this.selectedUnMatchedExternalAmount = 0.00;
    }

    if(this.selectedUnMatchedExternalRowData.length > 0 || this.selectedUnMatchedInternalRowData.length > 0)
    {
      let amountTolerance = Number(this.amountTolerance);
      let selectedUnMatchedInternalAmount = Number(this.selectedUnMatchedInternalAmount);
      let selectedUnMatchedExternalAmount = Number(this.selectedUnMatchedExternalAmount);
      this.totalSelectedUnMatchedAmount = Number(String(selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount).replace("-", ""));

      if(this.totalSelectedUnMatchedAmount <= amountTolerance)
      {
        this.matchButtonEnable = true;
      }
      else
      {
        this.matchButtonEnable = false;
      }
    }
    
    if((this.selectedUnMatchedExternalRowData.length > 0 && this.selectedUnMatchedInternalRowData.length === 0) || (this.selectedUnMatchedInternalRowData.length > 0 && this.selectedUnMatchedExternalRowData.length === 0))
    {
      this.matchButtonEnable = false;
    }
    else
    {
      this.matchButtonEnable = true;
    }
  }

  onMatchButtonClick(){
    this.ngxService.start();
    let amountTolerance = Number(this.amountTolerance);
    let selectedUnMatchedInternalAmount = Number(this.selectedUnMatchedInternalAmount);
    let selectedUnMatchedExternalAmount = Number(this.selectedUnMatchedExternalAmount);
    this.totalSelectedUnMatchedAmount = selectedUnMatchedInternalAmount - selectedUnMatchedExternalAmount;

    this.resetFilter();
    // console.log(this.totalSelectedUnMatchedAmount);
    
    if(this.totalSelectedUnMatchedAmount > amountTolerance)
    {
      this.ngxService.stop();
      alert("Amounts are not Matching!!!");
    }
    else if(this.totalSelectedUnMatchedAmount <= amountTolerance)
    {
      
      let selectedUnMatchedExternalRowData = this.selectedUnMatchedExternalRowData;
      let selectedUnMatchedInternalRowData = this.selectedUnMatchedInternalRowData;
      let selectedExternalRecordsIdList = [];
      let selectedInternalRecordsIdList = [];

      for(let i=0; i<selectedUnMatchedExternalRowData.length; i++)
      {
        selectedExternalRecordsIdList.push(selectedUnMatchedExternalRowData[i]["external_records_id"]);
      }

      for(let j=0; j<selectedUnMatchedInternalRowData.length; j++)
      {
        selectedInternalRecordsIdList.push(selectedUnMatchedInternalRowData[j]["internal_records_id"]);
      }

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "user_id": this.userId,
        "external_record_id_list": selectedExternalRecordsIdList,
        "internal_record_id_list": selectedInternalRecordsIdList
      }

      this.obj_auth_service.sendUnMatchedToMatchToServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          console.log("Match Buton Click Response: ", response_data);
          if(response_data["Status"] === "Success")
          {
            this.displaySelectedUnMatchedGrid = false;
            this.getSelectedProcessingLayer(this.processing_layer_id);

            let data = {
              "tenant_id" : this.tenantId,
              "group_id" : this.groupId,
              "entity_id" : this.entityId,
              "m_processing_layer_id" : this.mProcessingLayerId,
              "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
              "processing_layer_id" : this.processing_layer_id,
              "record_status" : "UnMatched"
            }

            this.unMatchedGridShow(data);
            this.unMatchedDisplayGrid = true;
            this.unMatchedSearchGrid = true;
            this.selectedUnMatchedExternalRowData = '';
            this.selectedUnMatchedInternalRowData = '';
            this.ngxService.stop();

          }
          else if(response_data["Status"] === "Error")
          {
            alert("Error in Matching Records. Kindly Contact Advents Support!!!");
            this.ngxService.stop();
          }
          else if(response_data["Status"] === "File")
          {
            alert("File is Processing in Backend. Kindly try after sometime!!!");
            this.ngxService.stop();
          }

        }, (error:any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })
    }
  }

  onContraButtonClick(){
    this.ngxService.start();
    let selectedExternalRowData = this.selectedUnMatchedExternalRowData;
    let selectedInternalRowData = this.selectedUnMatchedInternalRowData;
    let selectedExternalContraIdList = [];
    let selectedInternalContraIdList = [];

    this.resetFilter();

    for(let i:number = 0; i<selectedExternalRowData.length; i++)
    {
      selectedExternalContraIdList.push(selectedExternalRowData[i]["external_records_id"]);
    }

    for(let j:number = 0; j<selectedInternalRowData.length; j++)
    {
      selectedInternalContraIdList.push(selectedInternalRowData[j]["internal_records_id"]);
    }

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "externalContraList": selectedExternalContraIdList,
      "internalContraList": selectedInternalContraIdList,
      "userId": this.userId
    }

    this.obj_auth_service.sendUnmatchedToContraToServer(data)
    .subscribe(
      received_data => {
        let responseData = received_data;
        console.log("Contra Button Click Respose: ", responseData);
        if(responseData["Status"] === "Success")
        {
          this.displaySelectedUnMatchedGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
          
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "UnMatched"
          }

          this.unMatchedGridShow(data);
          this.unMatchedDisplayGrid = true;
          this.unMatchedSearchGrid = true;
          this.selectedUnMatchedExternalRowData = '';
          this.selectedUnMatchedInternalRowData = '';
          this.ngxService.stop();

        }
        else if(responseData["Status"] === "Error")
        {
          alert("Error in Updating Contra. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    )

  }

  onUnMatchButtonClick(){
    this.ngxService.start();
    let userId = JSON.parse(sessionStorage.getItem("user_details"))["user_id"];
    let externalRecordId = this.selectedExternalRowData[0]["external_records_id"];
    let internalRecordId = this.SelectedinternalRowData[0]["internal_records_id"];

    this.resetFilter();

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": userId,
      "externalRecordId": externalRecordId,
      "internalRecordId": internalRecordId
    }

    this.obj_auth_service.sendMatchedToUnMatchToServer(data)
    .subscribe(received_data => {
      let response_data = received_data;
      console.log("UnMatch Buton Click Response: ", response_data);
      if (response_data["Status"] === "Success")
      {
        this.displaySelectedMatchedGrid = false;
        this.getSelectedProcessingLayer(this.processing_layer_id);

        let data = {
          "tenant_id" : this.tenantId,
          "group_id" : this.groupId,
          "entity_id" : this.entityId,
          "m_processing_layer_id" : this.mProcessingLayerId,
          "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
          "processing_layer_id" : this.processing_layer_id,
          "record_status" : "Matched"
        }

        this.matchedGridShow(data);
        this.matchedDisplayGrid = true;
        this.matchedSearchGrid = true;
        this.selectedExternalRowData = '';
        this.SelectedinternalRowData = '';
        this.ngxService.stop();
      }

      else if (response_data["Status"] === "Error")
      {
        alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
        this.ngxService.stop();
      }

    }, (error:any) => {
      this.HandleErrorResponse(error);
      this.ngxService.stop();
    })
  }

  groupMatchedShow(data)
  {
    this.ngxService.start();
    this.obj_auth_service.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("GroupMatched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.groupMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
        this.groupMatchedExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.groupMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
        this.groupMatchedInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  onGroupMatchedExternalGridReady(params){
    this.externalGroupMatchedGridApi = params.api;
    this.externalGroupMatchedGridColumnApi = params.columnApi;
  }

  onGroupMatchedInternalGridReady(params){
    this.internalGroupMatchedGridApi = params.api;
    this.internalGroupMatchedGridColummApi = params.columnApi;
  }

  quickSearchGroupMatched(){
    this.externalGroupMatchedGridApi.setQuickFilter(this.searchValueGroupMatched);
    this.internalGroupMatchedGridApi.setQuickFilter(this.searchValueGroupMatched)
  }

  onGroupMatchedExternalSelectionChanged(params){
    try
    {
      this.ngxService.start();
      this.displaySelectedGroupMatchedGrid = true;
      this.groupMatchButtonDisabled = false;
      let selectedGroupMatchedExternalRowData = params.api.getSelectedRows();

      console.log(selectedGroupMatchedExternalRowData);

      let selectedGroupMatchedExternalRecordId = selectedGroupMatchedExternalRowData[0]["external_group_id"];

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "selected_group_id": selectedGroupMatchedExternalRecordId
      }

      this.obj_auth_service.getGroupIdTransactionsFromServer(data)
      .subscribe(
        received_data => {
          let responseData = received_data;
          console.log(responseData);
          if (responseData["Status"] === "Success")
          {
            let groupExternalRecordsData = responseData["external_records"]["data"];
            let groupExternalRecordsHeader = responseData["external_records"]["headers"];
            let groupInternalRecordsData = responseData["internal_records"]["data"];
            let groupInternalRecordsHeader = responseData["internal_records"]["headers"];
            this.updateSelectedGroupMatchedgrid(
              groupExternalRecordsData, groupExternalRecordsHeader, groupInternalRecordsData, groupInternalRecordsHeader
            );
            this.ngxService.stop();
          }
          else if(responseData["Status"] === "Error")
          {
            this.displaySelectedGroupMatchedGrid = false;
            this.ngxService.stop();
          }

        },(error:any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })
    }
    catch(error)
    {
      this.displaySelectedGroupMatchedGrid = false;
      this.groupMatchButtonDisabled = true;
      this.ngxService.stop();
    }
  }

  onGroupMatchedInternalSelectionChanged(params){
    try
    {
      this.ngxService.start();
      this.displaySelectedGroupMatchedGrid = true;
      this.groupMatchButtonDisabled = false;
      let selectedGroupMatchedInternalRowData = params.api.getSelectedRows();

      console.log(selectedGroupMatchedInternalRowData);

      let selectedGroupMatchedInternalRecordId = selectedGroupMatchedInternalRowData[0]["internal_group_id"];

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "selected_group_id": selectedGroupMatchedInternalRecordId
      }

      this.obj_auth_service.getGroupIdTransactionsFromServer(data)
      .subscribe(
        received_data => {
          let responseData = received_data;
          console.log(responseData);
          if (responseData["Status"] === "Success")
          {
            let groupExternalRecordsData = responseData["external_records"]["data"];
            let groupExternalRecordsHeader = responseData["external_records"]["headers"];
            let groupInternalRecordsData = responseData["internal_records"]["data"];
            let groupInternalRecordsHeader = responseData["internal_records"]["headers"];
            this.updateSelectedGroupMatchedgrid(
              groupExternalRecordsData, groupExternalRecordsHeader, groupInternalRecordsData, groupInternalRecordsHeader
            );
            this.ngxService.stop();
          }
          else if(responseData["Status"] === "Error")
          {
            this.displaySelectedGroupMatchedGrid = false;
            this.ngxService.stop();
          }

        },(error:any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        });

    }
    catch(error)
    {
      this.displaySelectedGroupMatchedGrid = false;
      this.groupMatchButtonDisabled = true;
      this.ngxService.stop();
    }
  }

  updateSelectedGroupMatchedgrid(groupExternalRecordsData, groupExternalRecordsHeader, groupInternalRecordsData, groupInternalRecordsHeader)
  {
    // Internal
    groupInternalRecordsHeader.forEach((item, index) => {
      if(item.sortable=="true"){
        if(index === 0){
          item["checkboxSelection"] = true;
          item["maxWidth"] = 40;
          item["pinned"] = 'left';
          item.sortable=true;
          item.filter=false;
          item.resizable=false;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item.lockPosition=true;
        }
        else if (index !== 0){
          item.sortable=true;
          item.filter=true;
          item.resizable=true;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item["minWidth"] = 50;
        }

        // Hiding
        if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
        {
          item["hide"] = true;
        }

      }
    });

    this.selectedGroupMatchedInternalRowData = groupInternalRecordsData;
    this.selectedGroupMatchedInternalColumnDefs = groupInternalRecordsHeader;

    // External
    groupExternalRecordsHeader.forEach((item, index) => {
      if(item.sortable=="true"){
        if(index === 0){
          item["checkboxSelection"] = true;
          item["maxWidth"] = 40;
          item["pinned"] = 'left';
          item.sortable=true;
          item.filter=false;
          item.resizable=false;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item.lockPosition=true;
        }
        else if (index !== 0){
          item.sortable=true;
          item.filter=true;
          item.resizable=true;
          item.suppressAutoSize=true;
          item.suppressSizeToFit=true;
          item["minWidth"] = 50;
        }

        // Hiding
        if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
        {
          item["hide"] = true;
        }

      }
    });

    this.selectedGroupMatchedExternalRowData = groupExternalRecordsData;
    this.selectedGroupMatchedExternalColumnDefs = groupExternalRecordsHeader;
  }

  onGroupUnMatchButtonClick(){
    this.ngxService.start();
    let selectedGroupMatchedExternalRowData = this.selectedGroupMatchedExternalRowData;
    let selectedGroupId = selectedGroupMatchedExternalRowData[0]["external_group_id"];

    this.resetFilter();

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "selectedGroupId": selectedGroupId,
      "userId": this.userId
    }

    this.obj_auth_service.setGroupMatchedToUnMatchToServer(data)
    .subscribe(
      received_data => {
        let responseData = received_data;
        console.log(responseData);
        if (responseData["Status"] === "Success")
        {
          this.displaySelectedGroupMatchedGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);

          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "GroupMatched"
          }

          this.groupMatchedShow(data);
          this.groupMatchedDisplayGrid = true;
          this.groupMatchedSearchGrid = true;
          this.selectedGroupMatchedExternalRowData = '';
          this.selectedGroupMatchedInternalRowData = '';
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    )
  }

  onContraExternalGridReady(params){
    this.externalContraGridApi = params.api;
    this.externalContraGridColumnApi = params.columnApi;
  }

  onContraInternalGridReady(params){
    this.internalContraGridApi = params.api;
    this.internalContraGridColumnApi = params.columnApi;
  }

  quickSearchContra(){
    this.externalContraGridApi.setQuickFilter(this.searchValueContra);
    this.internalContraGridApi.setQuickFilter(this.searchValueContra);
  }

  contraShow(data)
  {
    this.ngxService.start();
    this.obj_auth_service.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Contra Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.contraExternalColumnDefs = externalRecordsAllColumnDefs;
        this.contraExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.contraInternalColumnDefs = internalRecordsAllColumnDefs;
        this.contraInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  onContraExternalSelectionChanged(params){
    try
    {
      this.ngxService.start();
      this.displaySelectedInternalGridContra = false;
      this.selectedContraInternalRowData = '';
      this.displaySelectedContraGrid = true;
      this.contraUnmatchButtonEnable = true;
      this.displaySelectedExternalGridContra = true;
      let selectedExternalContraRowData = params.api.getSelectedRows();

      console.log(selectedExternalContraRowData);

      let selectedContraExternalRecordId = selectedExternalContraRowData[0]["external_contra_id"];

      let data = {
        "tenantId": this.tenantId,
        "groupId": this.groupId,
        "entityId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "processingLayerId": this.processing_layer_id,
        "userId": this.userId,
        "externalContraId": selectedContraExternalRecordId
      }

      this.obj_auth_service.getSelectedContraRecordsFromServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log(responseData);
          if(responseData["Status"] === "Success")
          {
            let contraExternalRowData = responseData["external_records"]["data"];
            let contraExternalHeaders = responseData["external_records"]["headers"];

            contraExternalHeaders.forEach((item, index) => {
              if(item.sortable=="true"){
                if(index === 0){
                  item["checkboxSelection"] = true;
                  item["maxWidth"] = 40;
                  item["pinned"] = 'left';
                  item.sortable=true;
                  item.filter=false;
                  item.resizable=false;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item.lockPosition=true;
                }
                else if (index !== 0){
                  item.sortable=true;
                  item.filter=true;
                  item.resizable=true;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item["minWidth"] = 50;
                }
    
                // Hiding
                if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
                {
                  item["hide"] = true;
                }
              }
            });

            this.selectedContraExternalRowData = contraExternalRowData;
            this.selectedContraExternalColumnDefs = contraExternalHeaders;
            this.ngxService.stop();
          }

        },(error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })
    }
    catch(error)
    {
      this.selectedContraExternalRowData = '';
      this.displaySelectedContraGrid = false;
      this.ngxService.stop();
    }
    
  }

  onContraInternalSelectionChanged(params){
    try
    {
      this.ngxService.start();
      this.displaySelectedExternalGridContra = false;
      this.selectedContraExternalRowData = '';
      this.displaySelectedInternalGridContra = true;
      this.displaySelectedContraGrid = true;
      this.contraUnmatchButtonEnable = true;
      let selectedInternalContraRowData = params.api.getSelectedRows();

      console.log(selectedInternalContraRowData);

      let selectedContraInternalRecordId = selectedInternalContraRowData[0]["internal_contra_id"];

      let data = {
        "tenantId": this.tenantId,
        "groupId": this.groupId,
        "entityId": this.entityId,
        "mProcessingLayerId": this.mProcessingLayerId,
        "mProcessingSubLayerId": this.mProcessingSubLayerId,
        "processingLayerId": this.processing_layer_id,
        "userId": this.userId,
        "internalContraId": selectedContraInternalRecordId
      }

      this.obj_auth_service.getSelectedContraRecordsFromServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          console.log(responseData);
          if(responseData["Status"] === "Success")
          {
            let contraInternalRowData = responseData["internal_records"]["data"];
            let contraInternalHeaders = responseData["internal_records"]["headers"];

            contraInternalHeaders.forEach((item, index) => {
              if(item.sortable=="true"){
                if(index === 0){
                  item["checkboxSelection"] = true;
                  item["maxWidth"] = 40;
                  item["pinned"] = 'left';
                  item.sortable=true;
                  item.filter=false;
                  item.resizable=false;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item.lockPosition=true;
                }
                else if (index !== 0){
                  item.sortable=true;
                  item.filter=true;
                  item.resizable=true;
                  item.suppressAutoSize=true;
                  item.suppressSizeToFit=true;
                  item["minWidth"] = 50;
                }
    
                // Hiding
                if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
                {
                  item["hide"] = true;
                }
              }
            });

            this.selectedContraInternalColumnDefs = contraInternalHeaders;
            this.selectedContraInternalRowData = contraInternalRowData;
            this.ngxService.stop();
          }
        }, (error : any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        })

    }
    catch(error)
    {
      this.selectedContraInternalRowData = '';
      this.displaySelectedContraGrid = false;
      this.ngxService.stop();
    }
  }

  onContraUnMatchButtonClick(){
    this.ngxService.start();

    this.resetFilter();

    if(this.selectedContraInternalRowData !== "")
    {
      var contraSide = "Internal";
      var contraId = this.selectedContraInternalRowData[0]["internal_contra_id"];
    }

    if(this.selectedContraExternalRowData !== "")
    {
      var contraSide = "External";
      var contraId = this.selectedContraExternalRowData[0]["external_contra_id"];
    }

    let data = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": this.userId,
      "contraSide": contraSide,
      "contraId": contraId
    }

    this.obj_auth_service.setContraMatchedToUnMatchedToServer(data)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        if (responseData["Status"] === "Success")
        {
          // this.displaySelectedExternalGridContra = false;
          // this.displaySelectedInternalGridContra = false;
          this.displaySelectedContraGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
  
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "Contra"
          }
  
          this.contraShow(data);
          this.contraDisplayGrid = true;
          this.contraSearchGrid = true;
          this.selectedContraExternalRowData = '';
          this.selectedContraInternalRowData = '';
          this.ngxService.stop();
        }
        else if (responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }, (error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      });

  }

  public onGroupUnMatchedExternalGridReady(params : any) : void {
    this.externalGroupUnMatchedGridApi = params.api;
    this.externalGroupUnMatchedColumnApi = params.columnApi;
  }

  public onGroupUnMatchedInternalGridReady(params : any) : void {
    this.internalGroupUnMatchedGridApi = params.api;
    this.internalGroupUnMatchedColumnApi = params.columnApi;
  }

  public quickSearchGroupUnMatched() : void {
    this.externalGroupUnMatchedGridApi.setQuickFilter(this.searchValueGroupUnMatched);
    this.internalGroupUnMatchedGridApi.setQuickFilter(this.searchValueGroupUnMatched);
  }

  public groupUnMatchedShow(data : any) : void {
    this.ngxService.start();
    this.obj_auth_service.getTransactionRecordsFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Matched Chart Click Response: ", response_data);

        let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
        let externalRecordsAllrowData = response_data["external_records"]["data"];
        let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
        let internalRecordsAllrowData = response_data["internal_records"]["data"];
        this.amountTolerance = parseFloat(response_data["amount_tolerance"]);

        // External
        externalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
            {
              item["hide"] = true;
            }

          }
        });

        // console.log(externalRecordsAllColumnDefs);

        this.groupUnMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
        this.groupUnMatchedExternalRowData = externalRecordsAllrowData;

        // Internal
        internalRecordsAllColumnDefs.forEach((item, index) => {
          if(item.sortable=="true"){
            if(index === 0){
              item["checkboxSelection"] = true;
              item["maxWidth"] = 40;
              item["pinned"] = 'left';
              item.sortable=true;
              item.filter=false;
              item.resizable=false;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item.lockPosition=true;
            }
            else if (index !== 0){
              item.sortable=true;
              item.filter=true;
              item.resizable=true;
              item.suppressAutoSize=true;
              item.suppressSizeToFit=true;
              item["minWidth"] = 50;
            }

            // Hiding
            if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
            {
              item["hide"] = true;
            }

          }
        });

        this.groupUnMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
        this.groupUnMatchedInternalRowData = internalRecordsAllrowData;
        this.ngxService.stop();

      },(error:any) => {
        this.HandleErrorResponse(error);
        this.ngxService.stop();
      })
  }

  public onGroupUnMatchedExternalSelectionChanged(params) : void {
    try 
    {
      this.ngxService.start();
      this.displaySelectedGroupUnMatchedGrid = true;
      let groupUnMatchedExternalSelectedRow = params.api.getSelectedRows();

      let selectedGroupUnMatchedExternalRecordGroupId = groupUnMatchedExternalSelectedRow[0]["external_group_id"];

      let data = {
        "tenant_id": this.tenantId,
        "group_id": this.groupId,
        "entity_id": this.entityId,
        "m_processing_layer_id": this.mProcessingLayerId,
        "m_processing_sub_layer_id": this.mProcessingSubLayerId,
        "processing_layer_id": this.processing_layer_id,
        "selected_group_id": selectedGroupUnMatchedExternalRecordGroupId
      }

      this.obj_auth_service.getGroupUnMatchedTransactionsFromServer(data)
      .subscribe(
        received_data => {
          let response_data = received_data;
          console.log("Selected External Group UnMatched Row Response: ", response_data);

          let externalRecordsAllColumnDefs = response_data["external_records"]["headers"];
          let externalRecordsAllrowData = response_data["external_records"]["data"];
          let internalRecordsAllColumnDefs = response_data["internal_records"]["headers"];
          let internalRecordsAllrowData = response_data["internal_records"]["data"];
          
          externalRecordsAllColumnDefs.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "external_records_id" || item.field === "external_contra_id" || item.field === "external_group_id" || item.field === "ext_processing_status_1" || item.field === "external_debit" || item.field === "external_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedGroupUnMatchedExternalColumnDefs = externalRecordsAllColumnDefs;
          this.selectedGroupUnMatchedExternalRowData = externalRecordsAllrowData;

          internalRecordsAllColumnDefs.forEach((item, index) => {
            if(item.sortable=="true"){
              if(index === 0){
                item["checkboxSelection"] = true;
                item["maxWidth"] = 40;
                item["pinned"] = 'left';
                item.sortable=true;
                item.filter=false;
                item.resizable=false;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item.lockPosition=true;
              }
              else if (index !== 0){
                item.sortable=true;
                item.filter=true;
                item.resizable=true;
                item.suppressAutoSize=true;
                item.suppressSizeToFit=true;
                item["minWidth"] = 50;
              }
  
              // Hiding
              if (item.field === "internal_records_id" || item.field === "internal_contra_id" || item.field === "internal_group_id" || item.field === "int_processing_status_1" || item.field === "internal_debit" || item.field === "internal_credit")
              {
                item["hide"] = true;
              }
  
            }
          });

          this.selectedGroupUnMatchedInternalColumnDefs = internalRecordsAllColumnDefs;
          this.selectedGroupUnMatchedInternalRowData = internalRecordsAllrowData;

          this.updateGroupUnMatchedConsolidatedAmount();

          this.ngxService.stop();
        },
        (error:any) => 
          {
            this.HandleErrorResponse(error);
            this.ngxService.stop();
          }
        )
    } 
    catch(error) 
    {
      // console.log(error);
      this.selectedGroupUnMatchedExternalRowData = '';
      this.displaySelectedGroupUnMatchedGrid = false;
      this.ngxService.stop();
    }
  }

  public onSelectedGroupUnMatchedInternalSelectionChanged(params : any) : void {
    let selectedData = params.api.getSelectedRows();
    if (selectedData.length)
    {
      let newSelectedGroupUnMatchedInternalRecordsList = [];
      for (var i=0; i<this.selectedGroupUnMatchedInternalRowData.length; i++)
      {
        if (this.selectedGroupUnMatchedInternalRowData[i]["internal_records_id"] !== selectedData[0]["internal_records_id"])
        {
          newSelectedGroupUnMatchedInternalRecordsList.push(this.selectedGroupUnMatchedInternalRowData[i]);
        }
      };
      this.selectedGroupUnMatchedInternalRowData = '';
      this.selectedGroupUnMatchedInternalRowData = newSelectedGroupUnMatchedInternalRecordsList;
    }
    this.updateGroupUnMatchedConsolidatedAmount();
  }

  public onSelectedGroupUnMatchedExternalSelectionChanged(params : any) : void {
    let selectedData = params.api.getSelectedRows();
    if (selectedData.length)
    {
      let newSelectedGroupMatchedExternalRecordsList = [];
      for (var i=0; i<this.selectedGroupUnMatchedExternalRowData.length; i++)
      {
        if (this.selectedGroupUnMatchedExternalRowData[i]["external_records_id"] !== selectedData[0]["external_records_id"])
        {
          newSelectedGroupMatchedExternalRecordsList.push(this.selectedGroupUnMatchedExternalRowData[i]);
        }
      };
      this.selectedGroupUnMatchedExternalRowData = '';
      this.selectedGroupUnMatchedExternalRowData = newSelectedGroupMatchedExternalRecordsList;
    }
    this.updateGroupUnMatchedConsolidatedAmount();
  }

  public updateGroupUnMatchedConsolidatedAmount() : void {

    this.groupUnMatchedUnMatchButton = false;
    this.groupUnMatchedMatchButton = false;

    let selectedExternalDebitAmount = 0.00;
    let selectedExternalCreditAmount = 0.00;
    for(let i:number = 0; i<this.selectedGroupUnMatchedExternalRowData.length; i++)
    {
      selectedExternalDebitAmount = selectedExternalDebitAmount + parseFloat(this.selectedGroupUnMatchedExternalRowData[i].external_debit);
      selectedExternalCreditAmount = selectedExternalCreditAmount + parseFloat(this.selectedGroupUnMatchedExternalRowData[i].external_credit);
      this.selectedGroupedUnMatchedExternalAmount = selectedExternalDebitAmount + selectedExternalCreditAmount;
    };

    let selectedInternalDebitAmount = 0.00;
    let selectedInternalCreditAmount = 0.00;
    for(let i:number = 0; i<this.selectedGroupUnMatchedInternalRowData.length; i++)
    {
      selectedInternalDebitAmount = selectedInternalDebitAmount + parseFloat(this.selectedGroupUnMatchedInternalRowData[i].internal_debit);
      selectedInternalCreditAmount = selectedInternalCreditAmount + parseFloat(this.selectedGroupUnMatchedInternalRowData[i].internal_credit);
      this.selectedGroupedUnMatchedInternalAmount = selectedInternalDebitAmount + selectedInternalCreditAmount;
    }

    if (!this.selectedGroupUnMatchedExternalRowData.length)
    {
      this.selectedGroupedUnMatchedExternalAmount = 0.00;
    }

    if (!this.selectedGroupUnMatchedInternalRowData.length)
    {
      this.selectedGroupedUnMatchedInternalAmount = 0.00;
    }

    if (this.selectedGroupUnMatchedExternalRowData.length && this.selectedGroupUnMatchedInternalRowData.length)
    {
      this.groupUnMatchedUnMatchButton = true;
    }
    else if (!this.selectedGroupUnMatchedExternalRowData.length || !this.selectedGroupUnMatchedInternalRowData.length)
    {
      this.groupUnMatchedUnMatchButton = false;
      this.groupUnMatchedMatchButton = false;
    }

    if ( ( this.selectedGroupUnMatchedExternalRowData.length && this.selectedGroupUnMatchedInternalRowData.length ) && (this.selectedGroupedUnMatchedExternalAmount === this.selectedGroupedUnMatchedInternalAmount) )
    {
      this.groupUnMatchedUnMatchButton = false;
      this.groupUnMatchedMatchButton = true;
    }
  }

  public onGroupUnMatchedUnMatchButtonClick() : void {
    this.ngxService.start();
    let params = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": this.userId,
      "externalRecordsList": this.selectedGroupUnMatchedExternalRowData,
      "internalRecordsList": this.selectedGroupUnMatchedInternalRowData
    };
    // console.log("Get Update Group UnMatched Match Input Params", params);
    this.obj_auth_service.getUpdateGroupUnMatchedUnMatchToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        if (responseData["Status"] === "Success")
        {
          this.displaySelectedContraGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
  
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "GroupUnMatched"
          }
  
          this.groupUnMatchedShow(data);
          this.groupUnMatchedDisplayGrid = true;
          this.groupUnMatchedSearchGrid = true;
          this.selectedGroupUnMatchedExternalRowData = '';
          this.selectedGroupUnMatchedInternalRowData = '';
          this.ngxService.stop();
        }
        else if (responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    };
  }

  public onGroupUnMatchedMatchButtonClick() : void {
    this.ngxService.start();
    let params = {
      "tenantId": this.tenantId,
      "groupId": this.groupId,
      "entityId": this.entityId,
      "mProcessingLayerId": this.mProcessingLayerId,
      "mProcessingSubLayerId": this.mProcessingSubLayerId,
      "processingLayerId": this.processing_layer_id,
      "userId": this.userId,
      "externalRecordsList": this.selectedGroupUnMatchedExternalRowData,
      "internalRecordsList": this.selectedGroupUnMatchedInternalRowData
    };

    this.obj_auth_service.getUpdateGroupUnMatchedMatchToServer(params)
    .subscribe(
      receivedData => {
        let responseData = receivedData;
        console.log("Update Group UnMatched Match Response", responseData);
        if (responseData["Status"] === "Success")
        {
          this.displaySelectedContraGrid = false;
          this.getSelectedProcessingLayer(this.processing_layer_id);
  
          let data = {
            "tenant_id" : this.tenantId,
            "group_id" : this.groupId,
            "entity_id" : this.entityId,
            "m_processing_layer_id" : this.mProcessingLayerId,
            "m_processing_sub_layer_id" : this.mProcessingSubLayerId,
            "processing_layer_id" : this.processing_layer_id,
            "record_status" : "GroupUnMatched"
          }
  
          this.groupUnMatchedShow(data);
          this.groupUnMatchedDisplayGrid = true;
          this.groupUnMatchedSearchGrid = true;
          this.selectedGroupUnMatchedExternalRowData = '';
          this.selectedGroupUnMatchedInternalRowData = '';
          this.ngxService.stop();
        }
        else if (responseData["Status"] === "Error")
        {
          alert("Error in UnMatching Records. Kindly Contact Advents Support!!!");
          this.ngxService.stop();
        }
        else if(responseData["Status"] === "File")
        {
          alert("File is Processing in Backend. Kindly try after sometime!!!");
          this.ngxService.stop();
        }
      }
    ),
    (error : any) => {
      this.HandleErrorResponse(error);
    };
  }

  resetFilter()
  {
    this.searchValue = null;
    this.searchValueUnMatched = null;
    this.searchValueGroupMatched = null;
    this.searchValueContra = null;
    this.searchValueGroupUnMatched = null;

    if(this.internalGridApi !== undefined && this.externalGridApi !== undefined)
    {
      if (this.matchedDisplayGrid)
      {
        this.quickSearch();
      }
    }
    
    if(this.externalUnMatchedGridApi !== undefined && this.internalUnMatchedGridApi !== undefined)
    {
      if (this.unMatchedDisplayGrid)
      {
        this.quickSearchUnMatched();
      }
    }

    if(this.externalGroupMatchedGridApi !== undefined && this.internalGroupMatchedGridApi !== undefined)
    {
      if (this.groupMatchedDisplayGrid)
      {
        this.quickSearchGroupMatched();
      }
    }

    if(this.externalContraGridApi !== undefined && this.internalContraGridApi !== undefined)
    {
      if (this.contraDisplayGrid)
      {
        this.quickSearchContra();
      }
    }

    if(this.externalGroupUnMatchedGridApi !== undefined && this.internalGroupUnMatchedGridApi !== undefined)
    {
      if (this.groupUnMatchedDisplayGrid)
      {
        this.quickSearchGroupUnMatched();
      }
    }
  }

  HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

}

  // updateGrid(_value: any){
  //   console.log("value", _value[0]);
  //   this.externalRowData =[_value[0]];
  // }

  // getSelectedRows(): void {
  //   const selectedNodes = this.agGrid.api.getSelectedNodes();
  //   const selectedData = selectedNodes.map(node => node.data);
  //   const selectedDataStringPresentation = selectedData.map(node => `${node.make} ${node.model}`).join(', ');

  //   alert(`Selected nodes: ${selectedDataStringPresentation}`);
  // }



  // Grid
  // columnDefs = [
  //   { field: 'VendorName', sortable: true, filter: true, checkboxSelection: true },
  //   { field: 'amount', sortable: true, filter: true }
  //   // { field: 'price', sortable: true, filter: true }
  // ];

  // rowData: any[] = [];

    // public barChartOptions = {
  //   scaleShowVerticalLines: false,
  //   responsive: true,
  //   scales: {
  //     yAxes: [{
  //       scaleLabel: {
  //         display: false,
  //         labelString: 'Invoice Amount'
  //       }
  //     }],
  //     xAxes: [{
  //       scaleLabel: {
  //         display: false,
  //         labelString: 'Vendors'
  //       }
  //     }]
  //   },
  //   title : {
  //     display : true,
  //     text : "Top 10 Vendor Payments",
  //     fontSize : 14,
  //     fontColor : '#48CAE4',
  //   },
  //   legend : {
  //     position : "right",
  //     display : true
  //   }
  // };

  // public barChartLabels = [] as any;
  // public barChartType: ChartType = 'bar';
  // public barChartLegend = true;
  // public barChartData = [{ data : []}] as any;

  // Bar
  // public barChartLabels = ["Lable1", "Label2", "Label3", "Label4"];
  // public barChartType: ChartType = 'bar';
  // public barChartLegend = true;
  // public barChartData = [{ data : [1,2,3,4], label:"Chart Label"}];

  // updateChart(data: { [x: string]: { [x: string]: any; }[]; }){
  //   let vendorList = data["vendor_list"];
  //   console.log("data", data);
  //   console.log("list", vendorList);

  //   let n = vendorList.length;
  //   let vendor =[];
  //   let barChartData1 = [];
  //   // let gridRow = [];
  //   for (var i = 0; i < n; i++){
  //     vendor.push(vendorList[i]["VendorName"]);
  //     barChartData1.push(vendorList[i]["amount"]);
  //     // this.rowData.push(data["vendor_list"][i]);
  //   }
  //   // this.row
  //   console.log("vendor", barChartData1.map(i=>Number(i)));
  //   console.log("vendor", vendor);
  //   console.log("vendor", barChartData1);
  //   this.barChartLabels = vendor;
  //   this.barChartData = [{ data : barChartData1.map(i=>Number(i)),  label: 'Total Invoice Value (INR in lakhs)'}];
  // }