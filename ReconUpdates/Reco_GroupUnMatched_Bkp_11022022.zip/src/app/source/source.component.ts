import { Component, OnInit, OnDestroy } from '@angular/core';
import { Source } from './source.model'
import { SourceService } from '../service/source.service';
import { HttpClient  } from '@angular/common/http';
import { Router} from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MessageComponent } from '../message/message.component';
import { Subject } from 'rxjs';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService

@Component({
  selector: 'app-source',
  templateUrl: './source.component.html',
  styleUrls: ['./source.component.css']
})
export class SourceComponent implements OnInit,OnDestroy {

  public objsource: Source;
  public listButton: boolean = false;
  public createButton: boolean = true;
  public sourceName: boolean = true;
  public sourceType: boolean = true;
  public fileType: boolean = false;
  public textSeparator: boolean = false;
  public otherSeparator: boolean = false;
  public filePasswordRequired: boolean = false;
  public filePassword: boolean = false;
  public sheetNameRequired: boolean = false;
  public sheetName: boolean = false;
  public sheetPasswordRequired: boolean = false;
  public sheetPassword: boolean = false;
  public columnStartRow: boolean = true;
  public database: boolean = false;
  public dbUserName: boolean = false;
  public dbPassword: boolean = false;
  public dbHost: boolean = false;
  public dbPort: boolean = false;
  public schema: boolean = false;
  public table: boolean = false;
  public psqlDatabase: boolean = false;
  public importSequence: boolean = true;
  public userDetails: any;
  public schemaList: any;
  public tableList: any;
  public userModelList: any;
  public tenantId: any;
  public groupId: any;
  public entityId: any;
  public userId: any;
  public psqlDatabaseList: any;

  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject<any>();

  constructor(private router: Router, private objservice: SourceService, public http: HttpClient, private dialog: MatDialog, public ngxService: NgxUiLoaderService) { }

  ngOnInit(): void {
    this.objsource = new Source();
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userDetails["tenant_id"];
    this.groupId = this.userDetails["group_id"];
    this.entityId = this.userDetails["entity_id"];
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  getSourceType(sourceType)
  {
    if (sourceType === "file")
    {
      this.fileType = true;
      this.columnStartRow = true;
      this.textSeparator = false;
      this.otherSeparator = false;
      this.filePasswordRequired = false;
      this.filePassword = false;
      this.sheetNameRequired = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.database = false;
      this.dbUserName = false;
      this.dbPassword = false;
      this.dbHost = false;
      this.dbPort = false;
      this.schema = false;
      this.table = false;
      this.psqlDatabase = false;

      this.objsource.textSeparator = '';
      this.objsource.otherSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
      this.objsource.database = '';
      this.objsource.dbUserName = '';
      this.objsource.dbPassword = '';
      this.objsource.dbHost = '';
      this.objsource.dbPort = '';
      this.objsource.schema = '';
      this.objsource.table = '';
      this.objsource.psqlDatabase = '';
    }
    else if (sourceType === "db")
    {
      this.fileType = false;
      this.columnStartRow = false;
      this.textSeparator = false;
      this.otherSeparator = false;
      this.filePasswordRequired = false;
      this.filePassword = false;
      this.sheetNameRequired = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.database = true;
      this.dbUserName = true;
      this.dbPassword = true;
      this.dbHost = true;
      this.dbPort = true;
      this.schema = true;
      this.table = true;

      this.objsource.fileType = '';
      this.objsource.columnStartRow = '';
      this.objsource.textSeparator = '';
      this.objsource.otherSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
    }
    else
    {
      this.fileType = false;
      this.textSeparator = false;
      this.otherSeparator = false;
      this.filePasswordRequired = false;
      this.filePassword = false;
      this.sheetNameRequired = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.database = false;
      this.dbUserName = false;
      this.dbPassword = false;
      this.dbHost = false;
      this.dbPort = false;
      this.schema = false;
      this.table = false;
      this.psqlDatabase = false;

      this.objsource.fileType = '';
      this.objsource.textSeparator = '';
      this.objsource.otherSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
      this.objsource.database = '';
      this.objsource.dbUserName = '';
      this.objsource.dbPassword = '';
      this.objsource.dbHost = '';
      this.objsource.dbPort = '';
      this.objsource.schema = '';
      this.objsource.table = '';
      this.objsource.psqlDatabase = '';
    }
  }

  getFileType(fileType)
  {
    if (fileType === "excel")
    {
      this.filePasswordRequired = true;
      this.sheetNameRequired = true;
      this.otherSeparator = false;
      this.textSeparator = false;

      this.objsource.otherSeparator = '';
      this.objsource.textSeparator = '';
    }
    else if (fileType === "text")
    {
      this.textSeparator = true;
      this.filePasswordRequired = false;
      this.sheetNameRequired = false;
      this.filePassword = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;

      this.objsource.filePasswordRequired = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
    }
    else
    {
      this.textSeparator = false;
      this.filePasswordRequired = false;
      this.sheetNameRequired = false;
      this.filePassword = false;
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;
      this.otherSeparator = false;

      this.objsource.textSeparator = '';
      this.objsource.filePasswordRequired = '';
      this.objsource.sheetNameRequired = '';
      this.objsource.filePassword = '';
      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
      this.objsource.otherSeparator = '';
    }
  }

  getFilePasswordRequired(filePasswordRequired)
  {
    if (filePasswordRequired === "yes")
    {
      this.filePassword = true;
    }
    else
    {
      this.filePassword = false;
      this.objsource.filePassword = '';
    }
  }

  getSheetNameRequired(sheetNameRequired)
  {
    if (sheetNameRequired === "yes")
    {
      this.sheetName = true;
      this.sheetPasswordRequired = true;
    }
    else
    {
      this.sheetName = false;
      this.sheetPasswordRequired = false;
      this.sheetPassword = false;

      this.objsource.sheetName = '';
      this.objsource.sheetPasswordRequired = '';
      this.objsource.sheetPassword = '';
    }
  }

  getSheetPasswordRequired(sheetPasswordRequired)
  {
    if (sheetPasswordRequired === "yes")
    {
      this.sheetPassword = true;
    }
    else
    {
      this.sheetPassword = false;

      this.objsource.sheetPassword = '';
    }
  }

  getTextSeparator(textSeparator)
  {
    if (textSeparator === "others")
    {
      this.otherSeparator = true;
    }
    else
    {
      this.otherSeparator = false;

      this.objsource.otherSeparator = '';
    }
  }

  getDatabase(database)
  {
    if (database === "postgres")
    {
      this.psqlDatabase = true;
    }
    else
    {
      this.psqlDatabase = false;

      this.objsource.psqlDatabase = '';
    }
  }

  getpsqlDatabase(psqlDatabase)
  {
    // this.objsource.psqlDatabase = psqlDatabase;
    if (psqlDatabase === "select")
    {
      this.psqlDatabaseList = [
        {"result" : ""}
      ];
      this.schemaList = [
        {"result" : ""}
      ];
      this.tableList = [
        {"result" : ""}
      ];
      if (this.objsource.dbPort === "" || this.objsource.database === "" || this.objsource.dbHost === "" || this.objsource.dbUserName === "" || this.objsource.dbPassword === "")
      {
        alert("Kindly Fill Database, Port, UserName, Password and Host to choose the Schema!!!");
      }
      else
      {
        this.ngxService.start();
        
        let data = {
          "database": this.objsource.database,
          "host": this.objsource.dbHost,
          "port": this.objsource.dbPort,
          "username": this.objsource.dbUserName,
          "password": this.objsource.dbPassword,
          "type": "database"
        };

        this.objservice.getDatabaseValuesFromServer(data)
        .subscribe(
          receivedData => {
            let responseData = receivedData;
            if (responseData["Status"] === "Error")
            {
              alert(responseData["Message"]);
              this.ngxService.stop();
            }
            else if (responseData["Status"] === "Success")
            {
              // console.log(responseData);
              let data = responseData["data"];
              this.psqlDatabaseList = data;
              this.ngxService.stop();
            }
          }, 
          (error:any) => {
            this.HandleErrorResponse(error);
            this.ngxService.stop();
          }
        )
      }
    }
  }

  getSchema(schema)
  {
    if (schema === "select")
    {
      this.schemaList = [
        {"result" : ""}
      ];
      this.tableList = [
        {"result" : ""}
      ];
      if (this.objsource.dbPort === "" || this.objsource.database === "" || this.objsource.dbHost === "" || this.objsource.dbUserName === "" || this.objsource.dbPassword === "")
      {
        alert("Kindly Fill Database, Port, UserName, Password and Host to choose the Schema!!!");
      }
      else
      {
        this.ngxService.start();

        let data = {
          "database": this.objsource.database,
          "host": this.objsource.dbHost,
          "port": this.objsource.dbPort,
          "username": this.objsource.dbUserName,
          "password": this.objsource.dbPassword,
          "type": "schema",
          "psqlDatabase": this.objsource.psqlDatabase
        };

        this.objservice.getDatabaseValuesFromServer(data)
        .subscribe(
          receivedData => {
            let responseData = receivedData;
            if (responseData["Status"] === "Error")
            {
              alert(responseData["Message"]);
              this.ngxService.stop();
            }
            else if (responseData["Status"] === "Success")
            {
              // console.log(responseData);
              let data = responseData["data"];
              this.schemaList = data;
              this.ngxService.stop();
            }
          },
          (error:any) => {
            this.HandleErrorResponse(error);
            this.ngxService.stop();
          }
        )
      }
    }
  }

  getTable(table)
  {
    if (table === "select")
    {
      this.tableList = [
        {"result" : ""}
      ];
      if (this.objsource.schema === "" || this.objsource.schema === "select")
      {
        alert("Kindly choose Schema!!!");
      }
      else
      {
        this.ngxService.start();

        let data = {
          "database": this.objsource.database,
          "host": this.objsource.dbHost,
          "port": this.objsource.dbPort,
          "username": this.objsource.dbUserName,
          "password": this.objsource.dbPassword,
          "type": "table",
          "schema": this.objsource.schema,
          "psqlDatabase": this.objsource.psqlDatabase
        }

        this.objservice.getDatabaseValuesFromServer(data)
        .subscribe(
          receivedData => {
            let responseData = receivedData;
            if (responseData["Status"] === "Error")
            {
              alert(responseData["Message"]);
              this.ngxService.stop();
            }
            else if (responseData["Status"] === "Success")
            {
              // console.log(responseData);
              let data = responseData["data"];
              this.tableList = data;
              this.ngxService.stop();
            }
          },
          (error:any) => {
            this.HandleErrorResponse(error);
            this.ngxService.stop();
          }
        )
      }
    }
  }

  onSaveButtonClick()
  {

    if (this.objsource.sourceName === '')
    {
      alert("Source Name should not be Empty!!!");
    }
    else if (this.objsource.sourceType === "")
    {
      alert("Please Choose Source Type!!!");
    }
    else if (this.objsource.sourceType == "file" && this.objsource.fileType === "")
    {
      alert("Please Choose File Type!!!");
    }
    else if (this.objsource.fileType == "excel" && this.objsource.filePasswordRequired === "")
    {
      alert("Please Choose Excel File has a Password or not!!!");
    }
    else if (this.objsource.fileType == "excel" && this.objsource.sheetNameRequired === "")
    {
      alert("Please Choose Whether Sheet Name is Necessary or not!!!");
    }
    else if (this.objsource.filePasswordRequired == "yes" && this.objsource.filePassword === "")
    {
      alert("Please Enter the File Password!!!");
    }
    else if (this.objsource.sheetNameRequired == "yes" && this.objsource.sheetName === "")
    {
      alert("Please Enter the Sheet Name!!!");
    }
    else if (this.objsource.sheetNameRequired == "yes" && this.objsource.sheetPasswordRequired === "")
    {
      alert("Please Choose the Sheet has a Password or not!!!");
    }
    else if (this.objsource.sheetPasswordRequired == "yes" && this.objsource.sheetPassword === "")
    {
      alert("Please Enter the Sheet Password!!!");
    }
    else if (this.objsource.fileType == "text" && this.objsource.textSeparator === "")
    {
      alert("Please Choose the Text Separator!!!");
    }
    else if (this.objsource.textSeparator == "others" && this.objsource.otherSeparator === "")
    {
      alert("Please Enter the Other Separator!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.database === "")
    {
      alert("Please Choose the Type of Database!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbUserName === "")
    {
      alert("Please Enter the Database User Name!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbPassword === "")
    {
      alert("Please Enter the Database Password!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbHost === "")
    {
      alert("Please Enter the Host IP Address!!!");
    }
    else if (this.objsource.sourceType == "db" && this.objsource.dbHost === "")
    {
      alert("Please Enter the Database Port Number!!!");
    }
    else if (this.objsource.sourceType == "db" && (this.objsource.schema === "" || this.objsource.schema == "select"))
    {
      alert("Please Choose the Schema Name!!!");
    }
    else if (this.objsource.sourceType == "db" && (this.objsource.table === "" || this.objsource.table == "select"))
    {
      alert("Please Choose the Database Table!!!");
    }
    else if (this.objsource.database == "postgres" && (this.objsource.psqlDatabase === "" || this.objsource.psqlDatabase == "select"))
    {
      alert("Please Choose the PSQL Database!!!");
    }
    else
    {
      this.ngxService.start();

      let data = {
        "tenantId" : this.tenantId,
        "groupId" : this.groupId,
        "entityId" : this.entityId,
        "userId" : this.userId,
        "sourceName" : this.objsource.sourceName,
        "sourceType" : this.objsource.sourceType,
        "fileType" : this.objsource.fileType,
        "textSeparator" : this.objsource.textSeparator,
        "otherSeparator" : this.objsource.otherSeparator,
        "filePasswordRequired" : this.objsource.filePasswordRequired,
        "filePassword" : this.objsource.filePassword,
        "sheetNameRequired" : this.objsource.sheetNameRequired,
        "sheetName" : this.objsource.sheetName,
        "sheetPasswordRequired" : this.objsource.sheetPasswordRequired,
        "sheetPassword" : this.objsource.sheetPassword,
        "columnStartRow" : this.objsource.columnStartRow,
        "database" : this.objsource.database,
        "dbHost" : this.objsource.dbHost,
        "dbPort" : this.objsource.dbPort,
        "dbUserName" : this.objsource.dbUserName,
        "dbPassword" : this.objsource.dbPassword,
        "schema" : this.objsource.schema,
        "table" : this.objsource.table,
        "importSequence" : this.objsource.importSequence,
        "psqlDatabase" : this.objsource.psqlDatabase
      }
  
      this.objservice.postSourceToServer(data)
      .subscribe(
        receivedData => {
          let responseData = receivedData;
          if (responseData["Status"] === "Error")
          {
            alert("Error in Inserting Data!!!");
            this.ngxService.stop();
          }
          else if (responseData["Status"] === "Success")
          {
            this.ngxService.stop();
          }
        },
        (error:any) => {
          this.HandleErrorResponse(error);
          this.ngxService.stop();
        }
      );
    }

  }

  onClearButtonClick()
  {
    this.objsource.sourceName = '';
    this.objsource.sourceType = '';
  }

  HandleErrorResponse(err: any)
  {
   console.log("Error",err);
  }


}
