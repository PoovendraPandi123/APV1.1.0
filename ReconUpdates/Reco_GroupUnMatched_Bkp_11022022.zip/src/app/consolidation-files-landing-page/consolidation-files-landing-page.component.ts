import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consolidation-files-landing-page',
  templateUrl: './consolidation-files-landing-page.component.html',
  styleUrls: ['./consolidation-files-landing-page.component.css']
})
export class ConsolidationFilesLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
