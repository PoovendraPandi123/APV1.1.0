import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { ChartsModule } from 'ng2-charts';
import { AgGridModule } from 'ag-grid-angular';
// import 'ag-grid-enterprise';
import { AppComponent } from './app.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { SigninComponent } from './signin/signin.component';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { HttpClientModule} from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ModulelistComponent } from './modulelist/modulelist.component';
import { BrsLandingPageComponent } from './brs-landing-page/brs-landing-page.component';
import { ConsolidationFilesLandingPageComponent } from './consolidation-files-landing-page/consolidation-files-landing-page.component';
import { PoIssueLandingPageComponent } from './po-issue-landing-page/po-issue-landing-page.component';
import { VendorPaymentsLandingPageComponent } from './vendor-payments-landing-page/vendor-payments-landing-page.component';
import { TdsReconLandingPageComponent } from './tds-recon-landing-page/tds-recon-landing-page.component';
import { TaskManagementLandingPageComponent } from './task-management-landing-page/task-management-landing-page.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { SourceComponent } from './source/source.component';
import { SourceDefinitionComponent } from './source-definition/source-definition.component';
import { AggregatorsComponent } from './aggregators/aggregators.component';
import { TransformationDefinitionComponent } from './transformation-definition/transformation-definition.component';
import { ProcessingLayerDefinitionsComponent } from './processing-layer-definitions/processing-layer-definitions.component';
import { BusinessLogicLayerComponent } from './business-logic-layer/business-logic-layer.component';
import { BusinessLogicLayerDefinitionComponent } from './business-logic-layer-definition/business-logic-layer-definition.component';
import { BrsFileUploadComponent } from './brs-file-upload/brs-file-upload.component';
import { RecoOperationComponent } from './reco-operation/reco-operation.component';
import { BrsReportComponent } from './brs-report/brs-report.component';
import { NgxUiLoaderModule } from "ngx-ui-loader";
import { NgxUiLoaderService, NgxUiLoaderConfig, SPINNER, POSITION, PB_DIRECTION  } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { MatDialogModule } from '@angular/material/dialog';
import { MatTableModule } from "@angular/material/table";
import { MessageComponent } from './message/message.component';
import { DataTablesModule } from 'angular-datatables';
import { BrsConsolidationReportComponent } from './brs-consolidation-report/brs-consolidation-report.component';
import { BrsMonthendCloseComponent } from './brs-monthend-close/brs-monthend-close.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AsFileUploadComponent } from './as-file-upload/as-file-upload.component';
import { AsLandingPageComponent } from './as-landing-page/as-landing-page.component';
import { AsRecoOperationComponent } from './as-reco-operation/as-reco-operation.component';
import { AsNationalAccountDetailsComponent } from './as-national-account-details/as-national-account-details.component';
import { AsTanReportComponent } from './as-tan-report/as-tan-report.component';
import { AsNadReportComponent } from './as-nad-report/as-nad-report.component';
import { AsErpTanUpdateComponent } from './as-erp-tan-update/as-erp-tan-update.component';
import { MiFileUploadComponent } from './mi-file-upload/mi-file-upload.component';
import { MiLandingPageComponent } from './mi-landing-page/mi-landing-page.component';
import { MiMisPageComponent } from './mi-mis-page/mi-mis-page.component';
import { MiReportAdditionComponent } from './mi-report-addition/mi-report-addition.component';
import { MiReportDeletionComponent } from './mi-report-deletion/mi-report-deletion.component';
import { MiReportExplicitComponent } from './mi-report-explicit/mi-report-explicit.component';
import { AsNadOpenComponent } from './as-nad-open/as-nad-open.component';
import { MiInsurerPageComponent } from './mi-insurer-page/mi-insurer-page.component';
// import {LicenseManager} from "ag-grid-enterprise";
// LicenseManager.setLicenseKey("");


const ngxUiLoaderConfig: NgxUiLoaderConfig = {
  fgsColor: '#60627c',
  // fgsPosition: POSITION.bottomCenter,
  fgsSize: 100,
  fgsType: SPINNER.threeBounce,
  pbDirection: PB_DIRECTION.leftToRight, // progress bar direction
  pbThickness: 5, // progress bar thickness
};


@NgModule({
  declarations: [
    AppComponent,
    SideMenuComponent,
    SigninComponent,
    ModulelistComponent,
    BrsLandingPageComponent,
    ConsolidationFilesLandingPageComponent,
    PoIssueLandingPageComponent,
    VendorPaymentsLandingPageComponent,
    TdsReconLandingPageComponent,
    TaskManagementLandingPageComponent,
    SourceComponent,
    SourceDefinitionComponent,
    AggregatorsComponent,
    TransformationDefinitionComponent,
    ProcessingLayerDefinitionsComponent,
    BusinessLogicLayerComponent,
    BusinessLogicLayerDefinitionComponent,
    BrsFileUploadComponent,
    RecoOperationComponent,
    BrsReportComponent,
    MessageComponent,
    BrsConsolidationReportComponent,
    BrsMonthendCloseComponent,
    AsFileUploadComponent,
    AsLandingPageComponent,
    AsRecoOperationComponent,
    AsNationalAccountDetailsComponent,
    AsTanReportComponent,
    AsNadReportComponent,
    AsErpTanUpdateComponent,
    MiFileUploadComponent,
    MiLandingPageComponent,
    MiMisPageComponent,
    MiReportAdditionComponent,
    MiReportDeletionComponent,
    MiReportExplicitComponent,
    AsNadOpenComponent,
    MiInsurerPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatButtonModule,
    MatListModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    HttpClientModule,
    FormsModule,
    MatExpansionModule,
    ChartsModule,
    MatDialogModule,
    MatTableModule,
    DataTablesModule,
    AgGridModule.withComponents([]),
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    NgbModule
  ],
  providers: [NgxUiLoaderService],
  bootstrap: [AppComponent]
})
export class AppModule { }
