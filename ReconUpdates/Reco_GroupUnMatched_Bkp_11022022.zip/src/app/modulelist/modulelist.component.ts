import { Component, OnInit } from '@angular/core';
import { ModuleList } from './modulelist.model';
import { HttpClient  } from '@angular/common/http';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-modulelist',
  templateUrl: './modulelist.component.html',
  styleUrls: ['./modulelist.component.css']
})
export class ModulelistComponent implements OnInit {

  public module_list : ModuleList;
  public user_module_list: any;
  public modules_list: any;
  public clicked_module_list: any;
  public user_details: any;
  public user_model_list: any;

  constructor(public http:HttpClient, public obj_auth_service:AuthService, public router:Router) { }

  ngOnInit(): void {
    this.module_list = new ModuleList();
    this.getUserList();
  }

  getUserList(){
    let user_details = JSON.parse(sessionStorage.getItem("user_details"));
    this.module_list.username = user_details.user_name;
    let data = {
      "user_name" : this.module_list.username
    }
    console.log("Input Request: ", data);
    this.obj_auth_service.getModuleListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Return Response: ", response_data);
        this.user_module_list = response_data;
        this.modules_list = this.user_module_list["modules_list"]
        sessionStorage.setItem("user_module_list", JSON.stringify(this.user_module_list));
      },
      (error:any) => {this.HandleErrorResponse(error)}
    )
    
  }

  HandleErrorResponse(err: any)
  {
    //  this.objerrhandler.handleError(String(err));
   console.log("Error",err);
  }

  routeModule(module_id){
    this.user_details = JSON.parse(sessionStorage.getItem("user_details"));
    this.clicked_module_list = JSON.parse(sessionStorage.getItem("user_module_list"));

    let data = {
      "module_id": module_id,
      "user_id": this.user_details.user_id
    }
    console.log("Input Request: ", data);
    this.obj_auth_service.getModelListFromServer(data)
    .subscribe(
      received_data => {
        let response_data = received_data;
        console.log("Return Response: ", response_data);
        this.user_model_list = response_data;
        sessionStorage.setItem("user_model_list", JSON.stringify(this.user_model_list));
        if(this.user_model_list.Status == "Success")
        {
          this.router.navigate(['/SideMenu']);
        }
      },
      (error:any) => {this.HandleErrorResponse(error)}
    )
  }

  // routeModule(data){
  //   if(data == "Bank Reconciliation")
  //   {
  //     this.router.navigate(['/BrsLandingPage'])
  //   }
  //   else if(data == "Consolidation Files")
  //   {
  //     this.router.navigate(['/ConsolFilesLandingPage'])
  //   }
  //   else if(data == "PO Issue Process")
  //   {
  //     this.router.navigate(['/PoLandingPage'])
  //   }
  //   else if(data == "Vendor Payments")
  //   {
  //     this.router.navigate(['/VendorPaymentsLandingPage'])
  //   }
  //   else if(data == "26AS Reconciliation")
  //   {
  //     this.router.navigate(['/TdsLandingPage'])
  //   }
  //   else if(data == "Task Management")
  //   {
  //     this.router.navigate(['/TaskManagementLangingPage'])
  //   }
  //   else
  //   {
  //     alert("Kindly Wait, Process configure Soon!!!")
  //   }
    
  // }

}
