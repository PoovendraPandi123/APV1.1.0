from django.urls import path
from . import views

urlpatterns = [
    path('execute_procedures/', views.get_execute_procedures, name="execute_procedures"),
    path('send_executed_data/', views.send_executed_data, name="send_executed_data"),
    path('get_batch_files/', views.get_batch_files, name="get_batch_files"),
    path('get_update_unmatched_matched/', views.get_update_unmatched_matched, name="get_update_unmatched_matched"),
    path('get_update_matched_unmatched/', views.get_update_matched_unmatched, name="get_update_matched_unmatched"),
    path('get_unmatch_grouped_unmatched_transactions/', views.get_unmatch_grouped_unmatched_transactions, name="get_unmatch_grouped_unmatched_transactions"),
    path('get_update_contra/', views.get_update_contra, name="get_update_contra"),
    path('get_update_group_records_unmatched/', views.get_update_group_records_unmatched, name="get_update_group_records_unmatched"),
    path('get_match_grouped_unmatched_transactions/', views.get_match_grouped_unmatched_transactions, name="get_match_grouped_unmatched_transactions"),
    path('get_unmatch_matched_contra/', views.get_unmatch_matched_contra, name="get_unmatch_matched_contra")
]