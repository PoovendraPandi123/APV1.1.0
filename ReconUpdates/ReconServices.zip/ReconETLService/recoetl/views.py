from .models import *
from django.http import JsonResponse
import json
import logging
from django.db import connection
import pandas as pd
import numpy as np
import requests
from .packages import read_file
import warnings
warnings.filterwarnings("ignore")

# Create your views here.

logger = logging.getLogger("recon_etl_service")

def execute_sql_query(query, object_type):
    try:
        with connection.cursor() as cursor:
            cursor.execute(query)
            if object_type == "table":
                column_names = [col[0] for col in cursor.description]
                rows = dict_fetch_all(cursor)
                table_output = {"headers":column_names, "data":rows}
                output = json.dumps(table_output)
                return output
            elif object_type == "Normal":
                return "Success"
            elif object_type in["update", "create"]:
                return None
            else:
                rows = cursor.fetchall()
                column_header = [col[0] for col in cursor.description]
                df = pd.DataFrame(rows)
                return [df, column_header]
    except Exception as e:
        logger.info(query)
        logger.error(str(e))
        logger.error("Error in Executing SQL Query", exc_info=True)
        return None

def dict_fetch_all(cursor):
    "Return all rows from cursor as a dictionary"
    try:
        column_header = [col[0] for col in cursor.description]
        return [dict(zip(column_header, row)) for row in cursor.fetchall()]
    except Exception as e:
        logger.error("Error in converting cursor data to dictionary", exc_info=True)

def get_batch_files(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            for k,v in data.items():
                if k == "file_upload_list":
                    file_upload_list = v

            post_url_insert = "http://localhost:50003/source/get_source_insert_queries/"
            post_url_file = "http://localhost:50004/recon/get_update_file_status/"
            headers = {
                "Content-Type": "application/json"
            }
            file_run = 1
            for file in file_upload_list:
                tenants_id = file["tenants_id"]
                groups_id = file["groups_id"]
                entities_id = file["entities_id"]
                m_source_id = file["m_source_id"]
                m_processing_layer_id = file["m_processing_layer_id"]
                m_processing_sub_layer_id = file["m_processing_sub_layer_id"]
                processing_layer_id = file["processing_layer_id"]
                file_path = file["file_path"]
                file_uploads_id = file["id"]
                created_by = file["created_by"]
                modified_by = file["modified_by"]

                payload_insert = json.dumps({"tenants_id": tenants_id, "groups_id": groups_id, "entities_id": entities_id, "m_source_id" : m_source_id})

                response_insert = requests.get(post_url_insert, data=payload_insert,  headers=headers)
                if response_insert.content:
                    content_data_insert = json.loads(response_insert.content)
                    if content_data_insert["Status"] == "Success":
                        insert_query = content_data_insert["insert_query"]
                        attribute_name_list = content_data_insert["attribute_name_list"]
                        attribute_data_types_list = content_data_insert["attribute_data_types_list"]
                        unique_list = content_data_insert["unique_list"]
                        source_extension = content_data_insert["source_extension"]
                        column_start_row = content_data_insert["column_start_row"]
                        m_source_name = content_data_insert["m_source_name"]

                        read_file_output = read_file.get_data_from_file(
                            file_path = file_path,
                            sheet_name = "",
                            source_extension = source_extension,
                            attribute_list = attribute_name_list,
                            column_start_row = column_start_row,
                            password_protected = "",
                            source_password = "",
                            attribute_data_types_list = attribute_data_types_list,
                            unique_list = unique_list
                        )

                        if read_file_output["Status"] == "Success":
                            data = read_file_output["data"]["data"]
                            print(data)
                            if data is not None:
                                data_rows_list = []
                                for index, rows in data.iterrows():
                                    # create a list for the current row
                                    data_list = [rows[column] for column in data.columns]
                                    data_rows_list.append(data_list)

                                # Adding Common Necessary Fields to the rows
                                for row in data_rows_list:
                                    row.append(tenants_id)  # Tenants Id
                                    row.append(groups_id)  # Groups Id
                                    row.append(entities_id)  # Entities Id
                                    row.append(file_uploads_id) # File Uploads Id
                                    row.append(m_source_id) # M Source Id
                                    row.append(m_source_name) # M Source Name
                                    row.append("New") # processing_status
                                    row.append(m_processing_layer_id) # M Processing Layer Id
                                    row.append(m_processing_sub_layer_id) # M Processing Sub Layer Id
                                    row.append(processing_layer_id) # Processing Layer Id
                                    row.append(timezone.now()) # Processing Date Time
                                    row.append(1) # Is Active
                                    row.append(created_by) # Created By
                                    row.append(timezone.now()) # Created Date
                                    row.append(modified_by) # Modified By
                                    row.append(timezone.now()) # Modified Date

                                # Create a insert string from the list
                                records = []
                                for record_lists in data_rows_list:
                                    record_string = ''
                                    for record_list in record_lists:
                                        record_string = record_string + "'" + str(record_list) + "', "
                                    record_proper = "(" + record_string[:-2] + "),"
                                    records.append(record_proper)

                                insert_value_string = ''
                                for record in records:
                                    insert_value_string = insert_value_string + record

                                final_query = insert_query.replace("{source_values}", insert_value_string[:-1])
                                # Loading to the Proper Table
                                load_output = execute_sql_query(final_query, object_type="Normal")

                                # Updating the status of the file upload table
                                if load_output == "Success":
                                    payload_file = json.dumps({"file_uploads_id": file_uploads_id, "file_status": "Loaded"})
                                else:
                                    payload_file = json.dumps({"file_uploads_id": file_uploads_id, "file_status": "Loading Error"})

                                response_file = requests.get(post_url_file, data=payload_file, headers=headers)
                                if response_file.content:
                                    content_data_file = json.loads(response_file.content)
                                    if content_data_file["Status"] == "Success":
                                        if file_run == len(file_upload_list):
                                            return JsonResponse({"Status": "Success", "Message": "All Files Loaded Successfully!!!"})
                                        else:
                                            file_run = file_run + 1
                                            continue
                                    elif content_data_file["Status"] == "Error":
                                        return JsonResponse({"Status": "Error", "Message": "Error in Updating File Processing Status in Recon ETL Service!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Error in Getting Response for Updating File Processing Status in Recon ETL Service!!!"})
                        elif read_file_output["Status"] == "Error":
                            return JsonResponse({"Status": "Error", "Message": "Error in Getting Data From Reading File Package!!!"})
                        elif read_file_output["Status"] == "DataLength":
                            payload_file = json.dumps({"file_uploads_id": file_uploads_id, "file_status": "Loaded"})
                            response_file = requests.get(post_url_file, data=payload_file, headers=headers)
                            if response_file.content:
                                content_data_file = json.loads(response_file.content)
                                if content_data_file["Status"] == "Success":
                                    if file_run == len(file_upload_list):
                                        return JsonResponse({"Status": "Success", "Message": "All Files Loaded Successfully!!!"})
                                    else:
                                        file_run = file_run + 1
                                        continue
                                elif content_data_file["Status"] == "Error":
                                    return JsonResponse({"Status": "Error", "Message": "Error in Updating File Processing Status in Recon ETL Service!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "Error in Getting Response for Updating File Processing Status in Recon ETL Service!!!"})
                    elif content_data_insert["Status"] == "Error":
                        return JsonResponse({"Status": "Error", "Message": "Error in Getting Insert Query From Source Service!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": " Error in Getting Response For Getting Insert Query From Source Service!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "GET Method Not Received!!!"})

    except Exception:
        logger.error("Error in Getting Batching Files!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_execute_procedures(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            post_url_file = "http://localhost:50004/recon/get_update_file_status/"
            headers = {
                "Content-Type": "application/json"
            }

            for k,v in data.items():
                if k == "file_data_distinct_list":
                    file_data_distinct_list = v["data"]

            for data_list in file_data_distinct_list:
                tenants_id = data_list["tenants_id"]
                groups_id = data_list["groups_id"]
                entities_id = data_list["entities_id"]
                m_processing_layer_id = data_list["m_processing_layer_id"]
                m_processing_sub_layer_id = data_list["m_processing_sub_layer_id"]
                processing_layer_id = data_list["processing_layer_id"]
                user_id = 0

                etl_execution_tasks = ETLExecutionTasks.objects.filter(
                    tenants_id=tenants_id,
                    groups_id=groups_id,
                    entities_id=entities_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id,
                    is_active=1
                ).order_by('execution_sequence', 'execution_sub_sequence')

                procedure_list = []
                for task in etl_execution_tasks:
                    procedure_list.append(task.procedure_name)

                payload_file = json.dumps(
                    {
                        "tenants_id": tenants_id,
                        "groups_id": groups_id,
                        "entities_id": entities_id,
                        "m_processing_layer_id": m_processing_layer_id,
                        "m_processing_sub_layer_id": m_processing_sub_layer_id,
                        "processing_layer_id": processing_layer_id,
                        "file_status": "Processing"
                    }
                )
                requests.get(post_url_file, data=payload_file, headers=headers)

                for procedure in procedure_list:
                    final_procedure = procedure.replace("{params}", str(user_id) + "," + str(m_processing_layer_id) + "," + str(m_processing_sub_layer_id) + "," + str(processing_layer_id))
                    print(final_procedure)
                    final_procedure_output = execute_sql_query(final_procedure, object_type="Normal")
                    if final_procedure_output == "Success":
                        continue
                    else:
                        payload_file_processed = json.dumps(
                            {
                                "tenants_id": tenants_id,
                                "groups_id": groups_id,
                                "entities_id": entities_id,
                                "m_processing_layer_id": m_processing_layer_id,
                                "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                "processing_layer_id": processing_layer_id,
                                "file_status": "Processing Error"
                            }
                        )
                        requests.get(post_url_file, data=payload_file_processed, headers=headers)

                        logger.error("Error in Executing Procedures in Recon ETL Service")
                        logger.error(str(procedure))
                        return JsonResponse({"Status": "Error"})
            return JsonResponse({"Status": "Success", "Message": "Procedures Executed Successfully!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "GET Method not Received!!!"})

    except Exception:
        logger.error("Error in Executing Procedures!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_query_data(select_query, insert_query):
    try:
        query_out = execute_sql_query(select_query, object_type="")
        data, headers = query_out

        final_query = ''

        if len(data) > 0:
            data_proper = data.replace(np.nan, 'None').replace("'", "''")

            data_rows_list = []
            for index, rows in data_proper.iterrows():
                # create a list for the current row
                data_list = [rows[column] for column in data_proper.columns]
                data_rows_list.append(data_list)

            records = []
            for record_lists in data_rows_list:
                record_string = ''
                for record_list in record_lists:
                    record_string = record_string + "'" + str(record_list).replace('"', '#####').replace("'", "$$$$$").replace("\\", "\\\\") + "', "
                record_proper = "(" + record_string[:-2] + "),"
                records.append(record_proper)
            # print(len(records))
            insert_value_string = ''
            for record in records:
                insert_value_string = insert_value_string + record

            final_query = insert_query.replace("{source_values}", insert_value_string[:-1]).replace("None", "null").replace("True", "1").replace("False", "0").replace('"', '\\"')
        return final_query
    except Exception:
        logger.error("Error in Get Query Data!!!", exc_info=True)
        return "Error"

def send_executed_data(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenants_id = ''
            groups_id = ''
            entities_id = ''
            m_processing_layer_id = ''
            m_processing_sub_layer_id = ''

            post_url_file = "http://localhost:50004/recon/get_update_file_status/"

            for k,v in data.items():
                if k == "tenants_id":
                    tenants_id = v
                if k == "groups_id":
                    groups_id = v
                if  k == "entities_id":
                    entities_id = v
                if  k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if  k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v

            if len(str(tenants_id)) > 0:
                if len(str(groups_id)) > 0:
                    if len(str(entities_id)) > 0:
                        if len(str(m_processing_layer_id)) > 0:
                            if len(str(m_processing_sub_layer_id)) > 0:
                                external_select_query = ''
                                external_insert_query = ''
                                internal_insert_query = ''
                                internal_select_query = ''
                                recon_results_select_query = ''
                                recon_results_insert_query = ''

                                etl_setting_queries_external_select = ETLSettingQueries.objects.filter(setting_key='external_select_query')
                                etl_setting_queries_internal_select = ETLSettingQueries.objects.filter(setting_key='internal_select_query')
                                etl_setting_queries_external_insert = ETLSettingQueries.objects.filter(setting_key='external_insert_query')
                                etl_setting_queries_internal_insert = ETLSettingQueries.objects.filter(setting_key='internal_insert_query')
                                etl_setting_queries_recon_result_select = ETLSettingQueries.objects.filter(setting_key='recon_results_select_query')
                                etl_setting_queries_recon_result_insert = ETLSettingQueries.objects.filter(setting_key='recon_results_insert_query')

                                reco_settings_etl = RecoSettingsETL.objects.filter(setting_key = 'group_sequence')
                                reco_settings_etl_ext_contra = RecoSettingsETL.objects.filter(setting_key = 'ext_contra_id')
                                reco_settings_etl_int_contra = RecoSettingsETL.objects.filter(setting_key = 'int_contra_id')

                                reco_settings_group_id_values_list = list()
                                reco_settings_etl_ext_contra_list = list()
                                reco_settings_etl_int_contra_list = list()

                                for setting in reco_settings_etl:
                                    reco_settings_group_id_values_list.append({
                                        "tenants_id": setting.tenants_id,
                                        "groups_id": setting.groups_id,
                                        "entities_id": setting.entities_id,
                                        "m_processing_layer_id": setting.m_processing_layer_id,
                                        "m_processing_sub_layer_id": setting.m_processing_sub_layer_id,
                                        "processing_layer_id": setting.processing_layer_id,
                                        "group_id_value": setting.setting_value
                                    })

                                for setting in reco_settings_etl_ext_contra:
                                    reco_settings_etl_ext_contra_list.append({
                                        "tenants_id": setting.tenants_id,
                                        "groups_id": setting.groups_id,
                                        "entities_id": setting.entities_id,
                                        "m_processing_layer_id": setting.m_processing_layer_id,
                                        "m_processing_sub_layer_id": setting.m_processing_sub_layer_id,
                                        "processing_layer_id": setting.processing_layer_id,
                                        "ext_contra_id": setting.setting_value
                                    })

                                for setting in reco_settings_etl_int_contra:
                                    reco_settings_etl_int_contra_list.append({
                                        "tenants_id": setting.tenants_id,
                                        "groups_id": setting.groups_id,
                                        "entities_id": setting.entities_id,
                                        "m_processing_layer_id": setting.m_processing_layer_id,
                                        "m_processing_sub_layer_id": setting.m_processing_sub_layer_id,
                                        "processing_layer_id": setting.processing_layer_id,
                                        "int_contra_id": setting.setting_value
                                    })

                                for setting in etl_setting_queries_external_select:
                                    external_select_query = setting.setting_value

                                for setting in etl_setting_queries_internal_select:
                                    internal_select_query = setting.setting_value

                                for setting in etl_setting_queries_external_insert:
                                    external_insert_query = setting.setting_value

                                for setting in etl_setting_queries_internal_insert:
                                    internal_insert_query = setting.setting_value

                                for setting in etl_setting_queries_recon_result_select:
                                    recon_results_select_query = setting.setting_value

                                for setting in etl_setting_queries_recon_result_insert:
                                    recon_results_insert_query = setting.setting_value


                                external_query = get_query_data(external_select_query, external_insert_query)
                                internal_query = get_query_data(internal_select_query, internal_insert_query)
                                recon_results_query = get_query_data(recon_results_select_query, recon_results_insert_query)

                                # print(group_seq_update_select_query_output)
                                if external_query != "Error" and internal_query != "Error":
                                    post_url = "http://localhost:50004/recon/get_insert_records/"
                                    payload = json.dumps({
                                        "tenants_id": tenants_id,
                                        "groups_id": groups_id,
                                        "entities_id": entities_id,
                                        "m_processing_layer_id": m_processing_layer_id,
                                        "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                        "internal_query_file": "G:/AdventsProduct/V1.0.0/AFS/ReconETLService/static/internal.txt",
                                        "external_query_file": "G:/AdventsProduct/V1.0.0/AFS/ReconETLService/static/external.txt",
                                        "recon_results_query_file": "G:/AdventsProduct/V1.0.0/AFS/ReconETLService/static/result.txt",
                                        "reco_settings_group_id_values_list": reco_settings_group_id_values_list,
                                        "reco_settings_etl_ext_contra_list": reco_settings_etl_ext_contra_list,
                                        "reco_settings_etl_int_contra_list": reco_settings_etl_int_contra_list
                                    })
                                    headers = {
                                        "Content-Type": "application/json"
                                    }
                                    file = open(r"G:/AdventsProduct/V1.0.0/AFS/ReconETLService/static/internal.txt","w+")
                                    file.write(internal_query)
                                    file.close()

                                    file = open(r"G:/AdventsProduct/V1.0.0/AFS/ReconETLService/static/external.txt","w+")
                                    file.write(external_query)
                                    file.close()

                                    file = open(r"G:/AdventsProduct/V1.0.0/AFS/ReconETLService/static/result.txt","w+")
                                    file.write(recon_results_query)
                                    file.close()
                                    # return JsonResponse({"Status": "Success", "Message": "Records Inserted Successfully!!!"})
                                    # # print(payload)
                                    response = requests.get(post_url, data=payload, headers=headers)
                                    if response.content:
                                        # print(response.content)
                                        content_data = json.loads(response.content)
                                        if content_data["Status"] == "Success":

                                            payload_file_processed = json.dumps(
                                                {
                                                    "tenants_id": tenants_id,
                                                    "groups_id": groups_id,
                                                    "entities_id": entities_id,
                                                    "m_processing_layer_id": m_processing_layer_id,
                                                    "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                    "file_status": "Processed"
                                                }
                                            )
                                            requests.get(post_url_file, data=payload_file_processed, headers=headers)

                                            return JsonResponse({"Status": "Success", "Message": "Records Inserted Successfully!!!"})
                                        elif content_data["Status"] == "Error":

                                            payload_file_processed = json.dumps(
                                                {
                                                    "tenants_id": tenants_id,
                                                    "groups_id": groups_id,
                                                    "entities_id": entities_id,
                                                    "m_processing_layer_id": m_processing_layer_id,
                                                    "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                    "file_status": "Transfer Error"
                                                }
                                            )
                                            requests.get(post_url_file, data=payload_file_processed, headers=headers)

                                            return JsonResponse({"Status": "Error", "Message": "Error in Get Insert Records!!!"})
                                else:
                                    return JsonResponse({"Status": "Error"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entities Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "group Id Not Found!!!"})
            else:
                return JsonResponse({"Status" : "Error", "Message" : "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "GET Method not Received!!!"})
    except Exception:
        logger.error("Error in Sending Executed Data!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_update_unmatched_matched(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenants_id = ''
            groups_id = ''
            entities_id = ''
            m_processing_layer_id = ''
            m_processing_sub_layer_id = ''
            group_id_value = ''
            user_id = ''
            external_record_id_list = ''
            internal_record_id_list = ''
            processing_layer_id = ''

            for k, v in data.items():
                if k == "tenants_id":
                    tenants_id = v
                if k == "groups_id":
                    groups_id = v
                if k == "entities_id":
                    entities_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if  k == "reco_settings_group_id_value":
                    group_id_value = v
                if  k == "user_id":
                    user_id = v
                if  k == "external_record_id_list":
                    external_record_id_list = v
                if  k == "internal_record_id_list":
                    internal_record_id_list = v

            TransactionExternalRecordsETL.objects.filter(external_records_etl_id__in = external_record_id_list).update(ext_processing_status_1 = 'GroupMatched', ext_match_type_1 = 'USER-MATCHED', ext_record_status_1 = 1, ext_generated_number_1 = group_id_value, modified_by = user_id, modified_date = timezone.now())
            TransactionInternalRecordsETL.objects.filter(internal_records_etl_id__in = internal_record_id_list).update(int_processing_status_1 = 'GroupMatched', int_match_type_1 = 'USER-MATCHED', int_record_status_1 = 1, int_generated_number_1 = group_id_value, modified_by = user_id, modified_date = timezone.now())

            RecoResultsETL.objects.create(
                m_processing_layer_id = m_processing_layer_id,
                m_processing_sub_layer_id = m_processing_sub_layer_id,
                processing_layer_id = processing_layer_id,
                generated_number_1 = group_id_value,
                reco_status = "USER-MATCHED",
                is_active = True,
                created_by = user_id,
                created_date = timezone.now(),
                modified_by = user_id,
                modified_date = timezone.now()
            )

            reco_settings = RecoSettingsETL.objects.filter(tenants_id = tenants_id, groups_id = groups_id, entities_id = entities_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id, setting_key = 'group_sequence')
            for setting in reco_settings:
                setting.setting_value = str(int(group_id_value) + 1)
                setting.save()

            return JsonResponse({"Status": "Success"})

    except Exception:
        logger.error("Error in Updating UnMatched Matched!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_update_matched_unmatched(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            external_record_id = 0
            internal_record_id = 0

            for k, v in data.items():
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "user_id":
                    user_id = v
                if k == "external_record_id":
                    external_record_id = v
                if k == "internal_record_id":
                    internal_record_id = v

            reco_resuts_etl = RecoResultsETL.objects.filter(m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id, t_external_records_id = external_record_id, t_internal_records_id = internal_record_id)
            if reco_resuts_etl is not None:
                TransactionExternalRecordsETL.objects.filter(external_records_etl_id = external_record_id).update(ext_processing_status_1 = 'UnMatched', ext_match_type_1 = 'USER-UNMATCHED', ext_record_status_1 = 0, ext_generated_number_1 = None, modified_by = user_id, modified_date = timezone.now())
                TransactionInternalRecordsETL.objects.filter(internal_records_etl_id = internal_record_id).update(int_processing_status_1 = 'UnMatched', int_match_type_1 = 'USER-UNMATCHED', int_record_status_1 = 0, int_generated_number_1 = None, modified_by = user_id, modified_date = timezone.now())

                for result in reco_resuts_etl:
                    result.reco_status = 'USER-UNMATCHED'
                    result.is_active = False
                    result.modified_by = user_id
                    result.modified_date = timezone.now()
                    result.save()

                return JsonResponse({"Status": "Success"})
    except Exception:
        logger.error("Error in Updating Matched UnMatched!!!")
        return JsonResponse({"Status": "Error"})

def get_update_contra(request, *args, **kwargs):
    try:
        body = request.body.decode('utf-8')
        data = json.loads(body)

        tenant_id = 0
        group_id = 0
        entity_id = 0
        m_processing_layer_id = 0
        m_processing_sub_layer_id = 0
        processing_layer_id = 0
        user_id = 0
        external_contra_id_list = None
        internal_contra_id_list = None

        for k, v in data.items():
            if k == "tenants_id":
                tenant_id = v
            if k == "groups_id":
                group_id = v
            if k == "entities_id":
                entity_id = v
            if k == "m_processing_layer_id":
                m_processing_layer_id = v
            if k == "m_processing_sub_layer_id":
                m_processing_sub_layer_id = v
            if k == "processing_layer_id":
                processing_layer_id = v
            if k == "user_id":
                user_id = v
            if k == "external_contra_id_list":
                external_contra_id_list = v
            if k == "internal_contra_id_list":
                internal_contra_id_list = v
            if k == "ext_contra_id":
                ext_contra_id = v
            if k == "int_contra_id":
                int_contra_id = v

        if external_contra_id_list is not None:
            TransactionExternalRecordsETL.objects.filter(external_records_etl_id__in=external_contra_id_list).update(
                ext_match_type_1='Contra',
                ext_match_type_2='Contra',
                ext_processing_status_1='Contra',
                ext_contra_id=ext_contra_id,
                modified_by=user_id,
                modified_date=timezone.now()
            )

            reco_settings_etl = RecoSettingsETL.objects.filter(tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id, setting_key='ext_contra_id', is_active=1)

            for setting in reco_settings_etl:
                setting.setting_value = str(int(ext_contra_id) + 1)
                setting.save()

            return JsonResponse({"Status": "Success"})

        elif internal_contra_id_list is not None:
            TransactionInternalRecordsETL.objects.filter(internal_records_etl_id__in=internal_contra_id_list).update(
                int_match_type_1='Contra',
                int_match_type_2='Contra',
                int_processing_status_1='Contra',
                int_contra_id=int_contra_id,
                modified_by=user_id,
                modified_date=timezone.now()
            )

            reco_settings_etl = RecoSettingsETL.objects.filter(tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id, setting_key='int_contra_id', is_active=1)

            for setting in reco_settings_etl:
                setting.setting_value = str(int(int_contra_id) + 1)
                setting.save()

            return JsonResponse({"Status": "Success"})
        else:
            return JsonResponse({"Status": "Error"})

    except Exception:
        logger.error("Error in Updating Contra!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_update_group_records_unmatched(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0

            for k, v in data.items():
                if k == "tenants_id":
                    tenant_id = v
                if k == "groups_id":
                    group_id = v
                if k == "entities_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "user_id":
                    user_id = v
                if k == "selected_group_id":
                    selected_group_id = v

            if int(selected_group_id) > 0:

                reco_results_etl = RecoResultsETL.objects.filter(generated_number_1=selected_group_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id, is_active=1)

                if reco_results_etl is not None:
                    TransactionExternalRecordsETL.objects.filter(
                        ext_generated_number_1=selected_group_id,
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id,
                        is_active=1
                    ).update(
                        ext_processing_status_1='UnMatched',
                        ext_match_type_1='USER-UNMATCHED',
                        ext_record_status_1=0,
                        ext_generated_number_1=None,
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    TransactionInternalRecordsETL.objects.filter(
                        int_generated_number_1=selected_group_id,
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id,
                        is_active=1
                    ).update(
                        int_processing_status_1='UnMatched',
                        int_match_type_1='USER-UNMATCHED',
                        int_record_status_1=0,
                        int_generated_number_1=None,
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    for result in reco_results_etl:
                        result.reco_status = 'USER-UNMATCHED'
                        result.is_active = 0
                        result.modified_by = user_id
                        result.modified_date = timezone.now()
                        result.save()

                    return JsonResponse({"Status": "Success"})
            else:
                return JsonResponse({"Status": "Error"})

    except Exception:
        logger.error("Error in Updating Group Records Unmatched!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_unmatch_grouped_unmatched_transactions(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            selected_group_id = 0

            for k, v in data.items():
                if k == "tenants_id":
                    tenant_id = v
                if k == "groups_id":
                    group_id = v
                if k == "entities_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "user_id":
                    user_id = v
                if k == "selected_group_id":
                    selected_group_id = v

            if selected_group_id != 0:

                TransactionExternalRecordsETL.objects.filter(
                    ext_generated_number_2=selected_group_id,
                    tenants_id=tenant_id,
                    groups_id=group_id,
                    entities_id=entity_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id,
                    is_active=1
                ).update(
                    ext_processing_status_1='UnMatched',
                    ext_match_type_1='USER-UNMATCHED',
                    ext_record_status_1=0,
                    ext_generated_number_2=None,
                    modified_by=user_id,
                    modified_date=timezone.now()
                )

                TransactionInternalRecordsETL.objects.filter(
                    int_generated_number_2=selected_group_id,
                    tenants_id=tenant_id,
                    groups_id=group_id,
                    entities_id=entity_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id,
                    is_active=1
                ).update(
                    int_processing_status_1='UnMatched',
                    int_match_type_1='USER-UNMATCHED',
                    int_record_status_1=0,
                    int_generated_number_2=None,
                    modified_by=user_id,
                    modified_date=timezone.now()
                )

                RecoResultsETL.objects.filter(
                    generated_number_2=selected_group_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id,
                    is_active=1
                ).update(
                    reco_status='USER-UNMATCHED',
                    is_active=0,
                    modified_by=user_id,
                    modified_date=timezone.now()
                )

                return JsonResponse({"Status": "Success"})
            else:
                return JsonResponse({"Status": "Error"})
    except Exception:
        logger.error("Error in Updating UnMatch Group UnMatched Transactions!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_match_grouped_unmatched_transactions(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            selected_group_id = 0
            external_records_ids_list = list()
            internal_records_ids_list = list()

            for k, v in data.items():
                if k == "tenants_id":
                    tenant_id = v
                if k == "groups_id":
                    group_id = v
                if k == "entities_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "user_id":
                    user_id = v
                if k == "selected_group_id":
                    selected_group_id = v
                if k == "external_records_ids_list":
                    external_records_ids_list = v
                if k == "internal_records_ids_list":
                    internal_records_ids_list = v

            if selected_group_id != 0 and len(external_records_ids_list) > 0 and len(internal_records_ids_list) > 0:

                reco_settings = RecoSettingsETL.objects.filter(
                    tenants_id=tenant_id,
                    groups_id=group_id,
                    entities_id=entity_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id,
                    setting_key='group_sequence'
                )

                group_sequence = 0
                for setting in reco_settings:
                    group_sequence = setting.setting_value

                if group_sequence != 0:
                    TransactionExternalRecordsETL.objects.filter(
                        external_records_etl_id__in=external_records_ids_list
                    ).update(
                        ext_processing_status_1='GroupMatched',
                        ext_match_type_1='USER-MATCHED',
                        ext_record_status_1=1,
                        ext_generated_number_1=group_sequence,
                        ext_generated_number_2=None,
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    TransactionInternalRecordsETL.objects.filter(
                        internal_records_etl_id__in=internal_records_ids_list
                    ).update(
                        int_processing_status_1='GroupMatched',
                        int_match_type_1='USER-MATCHED',
                        int_record_status_1=1,
                        int_generated_number_1=group_sequence,
                        int_generated_number_2=None,
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    RecoResultsETL.objects.create(
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id,
                        generated_number_1=group_sequence,
                        reco_status="USER-MATCHED",
                        is_active=1,
                        created_by=user_id,
                        created_date=timezone.now(),
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    for setting in reco_settings:
                        setting.setting_value = str(int(group_sequence) + 1)
                        setting.save()

                    # Update Grouped UnMatch

                    TransactionExternalRecordsETL.objects.filter(
                        ext_generated_number_2=selected_group_id,
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id,
                        is_active=1
                    ).update(
                        ext_processing_status_1='UnMatched',
                        ext_match_type_1='USER-UNMATCHED',
                        ext_record_status_1=0,
                        ext_generated_number_2=None,
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    TransactionInternalRecordsETL.objects.filter(
                        int_generated_number_2=selected_group_id,
                        tenants_id=tenant_id,
                        groups_id=group_id,
                        entities_id=entity_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id,
                        is_active=1
                    ).update(
                        int_processing_status_1='UnMatched',
                        int_match_type_1='USER-UNMATCHED',
                        int_record_status_1=0,
                        int_generated_number_2=None,
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    RecoResultsETL.objects.filter(
                        generated_number_2=selected_group_id,
                        m_processing_layer_id=m_processing_layer_id,
                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                        processing_layer_id=processing_layer_id,
                        is_active=1
                    ).update(
                        reco_status='USER-UNMATCHED',
                        is_active=0,
                        modified_by=user_id,
                        modified_date=timezone.now()
                    )

                    return JsonResponse({"Status": "Success"})
                else:
                    return JsonResponse({"Status": "Error"})
            else:
                return JsonResponse({"Status": "Error"})
    except Exception:
        logger.error("Error in Matching Grouped UnMatched Transactions!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_unmatch_matched_contra(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            contra_side = ''
            contra_id = 0

            for k, v in data.items():
                if k == "tenants_id":
                    tenant_id = v
                if k == "groups_id":
                    group_id = v
                if k == "entities_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "user_id":
                    user_id = v
                if k == "contra_side":
                    contra_side = v
                if k == "contra_id":
                    contra_id = v

            if contra_side == "External":
                TransactionExternalRecordsETL.objects.filter(
                    ext_contra_id=contra_id,
                    tenants_id=tenant_id,
                    groups_id=group_id,
                    entities_id=entity_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id,
                    is_active=1
                ).update(
                    ext_processing_status_1='UnMatched',
                    ext_match_type_1='USER-UNMATCHED',
                    ext_record_status_1=0,
                    ext_contra_id=None,
                    modified_by=user_id,
                    modified_date=timezone.now()
                )
                return JsonResponse({"Status": "Success"})

            if contra_side == "Internal":
                TransactionInternalRecordsETL.objects.filter(
                    int_contra_id=contra_id,
                    tenants_id=tenant_id,
                    groups_id=group_id,
                    entities_id=entity_id,
                    m_processing_layer_id=m_processing_layer_id,
                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                    processing_layer_id=processing_layer_id,
                    is_active=1
                ).update(
                    int_processing_status_1='UnMatched',
                    int_match_type_1='USER-UNMATCHED',
                    int_record_status_1=0,
                    int_contra_id=None,
                    modified_by=user_id,
                    modified_date=timezone.now()
                )
                return JsonResponse({"Status": "Success"})
            else:
                return JsonResponse({"Status": "Error"})

    except Exception:
        logger.error("Error in updating UnMatched Matched Contra!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})