from django.apps import AppConfig


class RecoetlConfig(AppConfig):
    name = 'recoetl'
