import logging
import json
import re
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
from .models import  *
from django.http import JsonResponse
import requests
from django.db import connection
import pandas as pd
from .packages import write_brs, calendar_month, extract_files
import os
from pathlib import Path
import shutil

# import warnings
# warnings.filterwarnings("ignore")

# Create your views here.
logger = logging.getLogger("recon_one")

def execute_sql_query(query, object_type):
    try:
        with connection.cursor() as cursor:
            #logger.info("Executing SQL Query..")
            # logger.info(query)
            # print(query)
            cursor.execute(query)
            if object_type == "table":
                column_names = [col[0] for col in cursor.description]
                rows = dict_fetch_all(cursor)
                table_output = {"headers":column_names, "data":rows}
                output = json.dumps(table_output)
                return output
            elif object_type in ["data"]:
                column_names = [col[0] for col in cursor.description]
                rows = dict_fetch_all(cursor)
                table_output = {"headers": column_names, "data": rows}
                return table_output
            elif object_type == "Normal":
                return "Success"
            elif object_type in["update", "create"]:
                return None
            else:
                rows = cursor.fetchall()
                column_header = [col[0] for col in cursor.description]
                df = pd.DataFrame(rows)
                return [df, column_header]

    except Exception as e:
        logger.info("Error Executing SQL Query!!", exc_info=True)
        return None

def dict_fetch_all(cursor):
    "Return all rows from cursor as a dictionary"
    try:
        column_header = [col[0] for col in cursor.description]
        return [dict(zip(column_header, row)) for row in cursor.fetchall()]
    except Exception as e:
        logger.error("Error in converting cursor data to dictionary", exc_info=True)

def get_grid_transform(header, header_column):
    try:
        column_defs = []
        for header in header["headers"]:
            column_defs.append({
                "field": header
            })

        column_header_defs = []
        for header in header_column["headers"]:
            column_header_defs.append({
                "headerName": header
            })

        for i in range(0, len(column_defs)):
            column_defs[i]["headerName"] = column_header_defs[i]["headerName"]
            column_defs[i]["sortable"] = "true"

        return column_defs
    except Exception as e:
        logger.error("Error in Getting Grid Transformation!!!", exc_info=True)

@csrf_exempt
def get_file_list(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            user_id = 0

            for k,v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if  k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "userId":
                    user_id= v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(user_id) > 0:
                                    setting_queries = SettingQueries.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        setting_key = 'file_upload_select_query'
                                    )

                                    setting_queries_header = SettingQueries.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        setting_key = 'file_upload_header_query'
                                    )

                                    for query in setting_queries:
                                        file_upload_query = query.setting_value

                                    for header in setting_queries_header:
                                        file_upload_header = json.loads(header.setting_value)

                                    file_upload_query_proper = file_upload_query.replace("{tenants_id}", str(tenant_id)).\
                                        replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id))

                                    file_upload_query_output = json.loads(execute_sql_query(file_upload_query_proper, object_type="table"))

                                    file_upload_query_output["headers"] = get_grid_transform(file_upload_query_output, file_upload_header)

                                    return JsonResponse({"Status": "Success", "file_upload_data_list": file_upload_query_output})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Processing Layer Details!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_processing_layer_list(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            type_id = ''

            for k,v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if  k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "typeId":
                    type_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if len(str(type_id)) > 0:
                                    post_url = "http://localhost:50003/source/get_processing_layer_list/"
                                    payload = json.dumps(
                                        {"tenant_id": tenant_id, "group_id": group_id,
                                         "entity_id": entity_id, "m_processing_layer_id": m_processing_layer_id,
                                         "m_processing_sub_layer_id": m_processing_sub_layer_id})
                                    headers = {
                                        "Content-Type": "application/json"
                                    }
                                    response = requests.get(post_url, data=payload, headers=headers)
                                    if response.content:
                                        content_data = json.loads(response.content)
                                        status = content_data["Status"]
                                        if status == "Success":
                                            processing_layer_list = content_data["processing_layer_list"]
                                            return JsonResponse({"Status": "Success", "processing_layer_list" : processing_layer_list})
                                        elif status == "Error":
                                            return JsonResponse({"Status": "Error", "Message": "Error in Getting Processing Layer Details!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Type Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Processing Layer Details!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_transaction_count(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0

            for k,v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if  k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    reco_settings_external = RecoSettings.objects.filter(setting_key = 'ext_count_all', is_active = 1)
                                    reco_settings_internal = RecoSettings.objects.filter(setting_key = 'int_count_all', is_active = 1)

                                    for setting in reco_settings_external:
                                        external_count = setting.setting_value

                                    for setting in reco_settings_internal:
                                        internal_count = setting.setting_value

                                    external_count_proper = external_count.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "{processing_layer_id}", str(processing_layer_id)).replace(
                                        "{conditions}", "")

                                    internal_count_proper = internal_count.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "{processing_layer_id}", str(processing_layer_id)).replace(
                                        "{conditions}", "")

                                    # Matched
                                    matched_count_external_query = external_count_proper.replace("{processing_status_1}", "Matched")
                                    matched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "Matched")
                                    matched_count_external_out = execute_sql_query(matched_count_external_query, object_type="data")
                                    matched_count_internal_out = execute_sql_query(matched_count_internal_query, object_type="data")
                                    matched_count_overall = int(matched_count_external_out["data"][0]["external_count"]) + int(matched_count_internal_out["data"][0]["internal_count"])

                                    # Unmatched
                                    unmatched_count_external_query = external_count_proper.replace("{processing_status_1}", "UnMatched")
                                    unmatched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "UnMatched")
                                    unmatched_count_external_out = execute_sql_query(unmatched_count_external_query, object_type="data")
                                    unmatched_count_internal_out = execute_sql_query(unmatched_count_internal_query, object_type="data")
                                    unmatched_count_overall = int(unmatched_count_external_out["data"][0]["external_count"]) + int(unmatched_count_internal_out["data"][0]["internal_count"])

                                    # Group Matched
                                    grp_matched_count_external_query = external_count_proper.replace("{processing_status_1}", "GroupMatched")
                                    grp_matched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "GroupMatched")
                                    grp_matched_count_external_out = execute_sql_query(grp_matched_count_external_query,object_type="data")
                                    grp_matched_count_internal_out = execute_sql_query(grp_matched_count_internal_query, object_type="data")
                                    grp_matched_count_overall = int(grp_matched_count_external_out["data"][0]["external_count"]) + int(grp_matched_count_internal_out["data"][0]["internal_count"])

                                    # Group Unmatched
                                    grp_unmatched_count_external_query = external_count_proper.replace("{processing_status_1}", "GroupUnMatched")
                                    grp_unmatched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "GroupUnMatched")
                                    grp_unmatched_count_external_out = execute_sql_query(grp_unmatched_count_external_query,object_type="data")
                                    grp_unmatched_count_internal_out = execute_sql_query(grp_unmatched_count_internal_query, object_type="data")
                                    grp_unmatched_count_overall = int(grp_unmatched_count_external_out["data"][0]["external_count"]) + int(grp_unmatched_count_internal_out["data"][0]["internal_count"])

                                    # Contra
                                    contra_count_external_query = external_count_proper.replace("{processing_status_1}", "Contra")
                                    contra_count_internal_query = internal_count_proper.replace("{processing_status_1}", "Contra")
                                    contra_count_external_out = execute_sql_query(contra_count_external_query,object_type="data")
                                    contra_count_internal_out = execute_sql_query(contra_count_internal_query, object_type="data")
                                    contra_count_overall = int(contra_count_external_out["data"][0]["external_count"]) + int(contra_count_internal_out["data"][0]["internal_count"])

                                    return  JsonResponse(
                                        {
                                            "label" : ["Matched", "UnMatched", "GroupMatched", "GroupUnMatched", "Contra"],
                                            "data" : [matched_count_overall, unmatched_count_overall, grp_matched_count_overall, grp_unmatched_count_overall, contra_count_overall]
                                            # "Matched": matched_count_overall,
                                            # "UnMatched": unmatched_count_overall,
                                            # "GroupMatched": grp_matched_count_overall,
                                            # "GroupUnMatched": grp_unmatched_count_overall,
                                            # "Contra": contra_count_overall
                                        }
                                    )
                                elif int(processing_layer_id) == 0:
                                    reco_settings_external = RecoSettings.objects.filter(setting_key='ext_count_all',is_active=1)
                                    reco_settings_internal = RecoSettings.objects.filter(setting_key='int_count_all',is_active=1)

                                    for setting in reco_settings_external:
                                        external_count = setting.setting_value

                                    for setting in reco_settings_internal:
                                        internal_count = setting.setting_value

                                    external_count_proper = external_count.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "AND processing_layer_id = {processing_layer_id}", "").replace(
                                        "{conditions}", "")

                                    internal_count_proper = internal_count.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "AND processing_layer_id = {processing_layer_id}", "").replace(
                                        "{conditions}", "")

                                    # Matched
                                    matched_count_external_query = external_count_proper.replace("{processing_status_1}", "Matched")
                                    matched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "Matched")
                                    matched_count_external_out = execute_sql_query(matched_count_external_query,object_type="data")
                                    matched_count_internal_out = execute_sql_query(matched_count_internal_query,object_type="data")
                                    #print(matched_count_external_out)
                                    #print(matched_count_internal_out)
                                    matched_count_overall = int(matched_count_external_out["data"][0]["external_count"]) + int(matched_count_internal_out["data"][0]["internal_count"])

                                    # Unmatched
                                    unmatched_count_external_query = external_count_proper.replace("{processing_status_1}", "UnMatched")
                                    unmatched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "UnMatched")
                                    unmatched_count_external_out = execute_sql_query(unmatched_count_external_query,object_type="data")
                                    unmatched_count_internal_out = execute_sql_query(unmatched_count_internal_query,object_type="data")
                                    unmatched_count_overall = int(unmatched_count_external_out["data"][0]["external_count"]) + int(unmatched_count_internal_out["data"][0]["internal_count"])

                                    # Group Matched
                                    grp_matched_count_external_query = external_count_proper.replace("{processing_status_1}", "GroupMatched")
                                    grp_matched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "GroupMatched")
                                    grp_matched_count_external_out = execute_sql_query(grp_matched_count_external_query,object_type="data")
                                    grp_matched_count_internal_out = execute_sql_query(grp_matched_count_internal_query,object_type="data")
                                    grp_matched_count_overall = int(grp_matched_count_external_out["data"][0]["external_count"]) + int(grp_matched_count_internal_out["data"][0]["internal_count"])

                                    # Group Unmatched
                                    grp_unmatched_count_external_query = external_count_proper.replace("{processing_status_1}", "GroupUnMatched")
                                    grp_unmatched_count_internal_query = internal_count_proper.replace("{processing_status_1}", "GroupUnMatched")
                                    grp_unmatched_count_external_out = execute_sql_query(grp_unmatched_count_external_query, object_type="data")
                                    grp_unmatched_count_internal_out = execute_sql_query(grp_unmatched_count_internal_query, object_type="data")
                                    grp_unmatched_count_overall = int(grp_unmatched_count_external_out["data"][0]["external_count"]) + int(grp_unmatched_count_internal_out["data"][0]["internal_count"])

                                    # Contra
                                    contra_count_external_query = external_count_proper.replace("{processing_status_1}","Contra")
                                    contra_count_internal_query = internal_count_proper.replace("{processing_status_1}","Contra")
                                    contra_count_external_out = execute_sql_query(contra_count_external_query,object_type="data")
                                    contra_count_internal_out = execute_sql_query(contra_count_internal_query,object_type="data")
                                    contra_count_overall = int(contra_count_external_out["data"][0]["external_count"]) + int(contra_count_internal_out["data"][0]["internal_count"])

                                    return JsonResponse(
                                        {
                                            "label": ["Matched", "UnMatched", "GroupMatched", "GroupUnMatched","Contra"],
                                            "data": [matched_count_overall, unmatched_count_overall,grp_matched_count_overall, grp_unmatched_count_overall,contra_count_overall]
                                            # "Matched": matched_count_overall,
                                            # "UnMatched": unmatched_count_overall,
                                            # "GroupMatched": grp_matched_count_overall,
                                            # "GroupUnMatched": grp_unmatched_count_overall,
                                            # "Contra": contra_count_overall
                                        }
                                    )
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                            return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                        return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                    return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Transaction Count!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_transaction_records(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            record_status = ''

            for k,v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if  k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "record_status":
                    record_status = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if record_status in ["Matched", "UnMatched", "Contra"]:
                                        reco_settings_external = RecoSettings.objects.filter(setting_key = 'ext_select_query_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)
                                        reco_settings_internal = RecoSettings.objects.filter(setting_key = 'int_select_query_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)

                                        setting_header_external = RecoSettings.objects.filter(setting_key = 'ext_header_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)
                                        setting_header_internal = RecoSettings.objects.filter(setting_key = 'int_header_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)

                                        for setting in reco_settings_external:
                                            external_select_query = setting.setting_value

                                        for setting in reco_settings_internal:
                                            internal_select_query = setting.setting_value

                                        for setting in setting_header_external:
                                            header_external = json.loads(setting.setting_value)

                                        for setting in setting_header_internal:
                                            header_internal = json.loads(setting.setting_value)

                                        external_select_query_proper = external_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", " ORDER BY ext_reference_date_time_1 ASC")
                                        # print(external_select_query_proper)
                                        internal_select_query_proper = internal_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", " ORDER BY int_reference_date_time_1 ASC")
                                        # print(internal_select_query_proper)
                                        external_query_out = json.loads(execute_sql_query(external_select_query_proper, object_type="table"))
                                        internal_query_out = json.loads(execute_sql_query(internal_select_query_proper, object_type="table"))

                                        external_query_out["headers"] = get_grid_transform(external_query_out, header_external)
                                        internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                        reco_settings = RecoSettings.objects.filter(
                                            tenants_id=tenant_id,
                                            groups_id=group_id,
                                            entities_id=entity_id,
                                            m_processing_layer_id=m_processing_layer_id,
                                            m_processing_sub_layer_id=m_processing_sub_layer_id,
                                            processing_layer_id=processing_layer_id,
                                            setting_key='amount_tolerance'
                                        )

                                        for setting in reco_settings:
                                            amount_tolerance = setting.setting_value

                                        return JsonResponse({
                                            "Status": "Success",
                                            "external_records" : external_query_out,
                                            "internal_records" : internal_query_out,
                                            "amount_tolerance" : amount_tolerance
                                        })
                                    elif record_status in ["GroupMatched"]:
                                        reco_settings_external = RecoSettings.objects.filter(setting_key='ext_select_query_group_matched', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)
                                        reco_settings_internal = RecoSettings.objects.filter(setting_key='int_select_query_group_matched', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)

                                        setting_header_external = RecoSettings.objects.filter(setting_key='ext_header_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)
                                        setting_header_internal = RecoSettings.objects.filter(setting_key='int_header_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)

                                        for setting in reco_settings_external:
                                            external_select_query = setting.setting_value

                                        for setting in reco_settings_internal:
                                            internal_select_query = setting.setting_value

                                        for setting in setting_header_external:
                                            header_external = json.loads(setting.setting_value)

                                        for setting in setting_header_internal:
                                            header_internal = json.loads(setting.setting_value)

                                        external_select_query_proper = external_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", " ORDER BY ext_reference_date_time_1 ASC")

                                        internal_select_query_proper = internal_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", " ORDER BY int_reference_date_time_1 ASC")

                                        external_query_out = json.loads(execute_sql_query(external_select_query_proper, object_type="table"))
                                        internal_query_out = json.loads(execute_sql_query(internal_select_query_proper, object_type="table"))

                                        external_query_out["headers"] = get_grid_transform(external_query_out, header_external)
                                        internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                        reco_settings = RecoSettings.objects.filter(
                                            tenants_id=tenant_id,
                                            groups_id=group_id,
                                            entities_id=entity_id,
                                            m_processing_layer_id=m_processing_layer_id,
                                            m_processing_sub_layer_id=m_processing_sub_layer_id,
                                            processing_layer_id=processing_layer_id,
                                            setting_key='amount_tolerance'
                                        )

                                        for setting in reco_settings:
                                            amount_tolerance = setting.setting_value

                                        return JsonResponse({
                                            "Status": "Success",
                                            "external_records": external_query_out,
                                            "internal_records": internal_query_out,
                                            "amount_tolerance": amount_tolerance
                                        })

                                    elif record_status in ["GroupUnMatched"]:
                                        reco_settings_external = RecoSettings.objects.filter(setting_key='ext_select_query_group_unmatched', is_active=1, tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id)
                                        reco_settings_internal = RecoSettings.objects.filter(setting_key='int_select_query_group_unmatched', is_active=1, tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id)

                                        setting_header_external = RecoSettings.objects.filter(setting_key='ext_header_all', is_active=1, tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id)
                                        setting_header_internal = RecoSettings.objects.filter(setting_key='int_header_all', is_active=1, tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id)

                                        for setting in reco_settings_external:
                                            external_select_query = setting.setting_value

                                        for setting in reco_settings_internal:
                                            internal_select_query = setting.setting_value

                                        for setting in setting_header_external:
                                            header_external = json.loads(setting.setting_value)

                                        for setting in setting_header_internal:
                                            header_internal = json.loads(setting.setting_value)

                                        external_select_query_proper = external_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", " ORDER BY ext_reference_date_time_1 ASC")

                                        internal_select_query_proper = internal_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", " ORDER BY int_reference_date_time_1 ASC")

                                        external_query_out = json.loads(execute_sql_query(external_select_query_proper, object_type="table"))
                                        internal_query_out = json.loads(execute_sql_query(internal_select_query_proper, object_type="table"))

                                        external_query_out["headers"] = get_grid_transform(external_query_out, header_external)
                                        internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                        reco_settings = RecoSettings.objects.filter(
                                            tenants_id=tenant_id,
                                            groups_id=group_id,
                                            entities_id=entity_id,
                                            m_processing_layer_id=m_processing_layer_id,
                                            m_processing_sub_layer_id=m_processing_sub_layer_id,
                                            processing_layer_id=processing_layer_id,
                                            setting_key='amount_tolerance'
                                        )

                                        for setting in reco_settings:
                                            amount_tolerance = setting.setting_value

                                        return JsonResponse({
                                            "Status": "Success",
                                            "external_records": external_query_out,
                                            "internal_records": internal_query_out,
                                            "amount_tolerance": amount_tolerance
                                        })

                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "Proper Record Status not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Transaction Records!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_int_ext_transactions(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            external_records_id = 0
            internal_records_id = 0
            external_group_id  = 0
            internal_group_id = 0
            external_contra_id = 0
            internal_contra_id = 0
            t_internal_records_id=0
            t_external_records_id=0
            reco_results_ext=None
            reco_results_ext_group=None
            reco_results_ext_contra=None
            reco_results_int_contra=None
            t_generated_number_1=0
            t_generated_number_2=0
            ext_condition=''
            int_condition=''
            ext_contra=[]
            int_contra = []

            for k, v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if  k == "external_records_id":
                    external_records_id = v
                if k == "internal_records_id":
                    internal_records_id = v
                if  k == "external_group_id":
                    external_group_id = v
                if  k == "internal_group_id":
                    internal_group_id = v
                if  k == "external_contra_id":
                    external_contra_id = v
                if  k == "internal_contra_id":
                    internal_contra_id = v


            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(external_records_id) > 0 :
                                        reco_results_ext = RecoResults.objects.get(t_external_records_id=external_records_id, is_active=1)
                                    elif int(internal_records_id) > 0:
                                        reco_results_ext = RecoResults.objects.get(t_internal_records_id=internal_records_id, is_active=1)
                                    elif int(external_group_id) > 0 :
                                        reco_results_ext_group = TransactionExternalRecords.objects.get(external_records_id=external_group_id, is_active=1)
                                        t_generated_number_1 =  reco_results_ext_group.ext_generated_number_1
                                    elif int(internal_group_id) > 0:
                                        reco_results_ext_group = TransactionInternalRecords.objects.get(internal_records_id=internal_group_id, is_active=1)
                                        t_generated_number_1 = reco_results_ext_group.int_generated_number_1
                                    if int(external_contra_id) > 0 :
                                        reco_results_ext_contra = TransactionExternalRecords.objects.get(external_records_id=external_contra_id, is_active=1)
                                        ext_contra.append(reco_results_ext_contra.external_records_id)
                                        ext_contra.append(reco_results_ext_contra.ext_contra_id)
                                    elif int(internal_contra_id) > 0:
                                        reco_results_int_contra = TransactionInternalRecords.objects.get(internal_records_id=internal_contra_id, is_Active=1)
                                        int_contra.append(reco_results_int_contra.internal_records_id)
                                        int_contra.append(reco_results_int_contra.int_contra_id)

                                    if(reco_results_ext is not None) :
                                        t_external_records_id = reco_results_ext.t_external_records_id
                                        t_internal_records_id = reco_results_ext.t_internal_records_id
                                        ext_condition = "AND external_records_id =" + str(t_external_records_id)
                                        int_condition = "AND internal_records_id =" + str(t_internal_records_id)
                                    elif(reco_results_ext_group is not None) :
                                        ext_condition = "AND ext_generated_number_1 =" + str(t_generated_number_1)
                                        int_condition = "AND int_generated_number_1 =" + str(t_generated_number_1)
                                    elif(reco_results_ext_contra is not None) :
                                        ext_condition = "AND external_records_id in "+str(ext_contra)
                                    elif(reco_results_int_contra is not None) :
                                        intcontrastr=''
                                        for intcontra in int_contra:
                                            intcontrastr=str(intcontra)+","
                                        intcontrastr=intcontrastr[:-1]
                                        int_condition = "AND internal_records_id in ("+intcontrastr+")"

                                    reco_settings_external = RecoSettings.objects.filter(setting_key='ext_select_query_all', is_active=1)
                                    reco_settings_internal = RecoSettings.objects.filter(setting_key='int_select_query_all', is_active=1)

                                    setting_header_external = RecoSettings.objects.filter(setting_key='ext_header_all', is_active=1)
                                    setting_header_internal = RecoSettings.objects.filter(setting_key='int_header_all', is_active=1)

                                    for setting in reco_settings_external:
                                        external_select_query = setting.setting_value

                                    for setting in reco_settings_internal:
                                        internal_select_query = setting.setting_value

                                    for setting in setting_header_external:
                                        header_external = json.loads(setting.setting_value)

                                    for setting in setting_header_internal:
                                        header_internal = json.loads(setting.setting_value)

                                    external_select_query_proper = external_select_query.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "{processing_layer_id}", str(processing_layer_id)).replace(
                                        "AND ext_processing_status_1 = '{processing_status_1}'", "").replace(
                                        "{conditions}", ext_condition)
                                    # print(external_select_query_proper)

                                    internal_select_query_proper = internal_select_query.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}", str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "{processing_layer_id}", str(processing_layer_id)).replace(
                                        "AND int_processing_status_1 = '{processing_status_1}'", "").replace(
                                        "{conditions}", int_condition)
                                    # print(internal_select_query_proper)
                                    external_query_out = json.loads(
                                        execute_sql_query(external_select_query_proper, object_type="table"))
                                    internal_query_out = json.loads(
                                        execute_sql_query(internal_select_query_proper, object_type="table"))

                                    external_query_out["headers"] = get_grid_transform(external_query_out, header_external)
                                    internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                    return JsonResponse({
                                        "Status": "Success",
                                        "external_records": external_query_out,
                                        "internal_records": internal_query_out
                                    })
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Internal External Transaction Records!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_group_id_transactions(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            selected_group_id = 0

            for k, v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "selected_group_id":
                    selected_group_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(selected_group_id) > 0:

                                        reco_results = RecoResults.objects.filter(generated_number_1 = selected_group_id, is_active = 1)

                                        for result in reco_results:
                                            reco_result_id = result.t_reco_result_id

                                        # print(reco_result_id)
                                        if len(str(reco_result_id)) > 0:
                                            reco_settings_external = RecoSettings.objects.filter(setting_key='ext_select_query_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)
                                            reco_settings_internal = RecoSettings.objects.filter(setting_key='int_select_query_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)

                                            setting_header_external = RecoSettings.objects.filter(setting_key='ext_header_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)
                                            setting_header_internal = RecoSettings.objects.filter(setting_key='int_header_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)

                                            for setting in reco_settings_external:
                                                external_select_query = setting.setting_value

                                            for setting in reco_settings_internal:
                                                internal_select_query = setting.setting_value

                                            for setting in setting_header_external:
                                                header_external = json.loads(setting.setting_value)

                                            for setting in setting_header_internal:
                                                header_internal = json.loads(setting.setting_value)

                                            record_status = "GroupMatched"

                                            external_select_query_proper = external_select_query.replace(
                                                "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                        str(group_id)).replace(
                                                "{entities_id}", str(entity_id)).replace(
                                                "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                                "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                                "{processing_layer_id}", str(processing_layer_id)).replace(
                                                "{processing_status_1}", record_status).replace("{conditions}", "AND ext_generated_number_1 = " + str(selected_group_id))
                                            # print(external_select_query_proper)
                                            internal_select_query_proper = internal_select_query.replace(
                                                "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                        str(group_id)).replace(
                                                "{entities_id}", str(entity_id)).replace(
                                                "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                                "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                                "{processing_layer_id}", str(processing_layer_id)).replace(
                                                "{processing_status_1}", record_status).replace("{conditions}", "AND int_generated_number_1 = " + str(selected_group_id))
                                            # print(internal_select_query_proper)
                                            external_query_out = json.loads(execute_sql_query(external_select_query_proper, object_type="table"))
                                            internal_query_out = json.loads(execute_sql_query(internal_select_query_proper, object_type="table"))

                                            external_query_out["headers"] = get_grid_transform(external_query_out, header_external)
                                            internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                            return JsonResponse({
                                                "Status": "Success",
                                                "external_records": external_query_out,
                                                "internal_records": internal_query_out
                                            })

                                        return JsonResponse({"Status": "Success"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
    except Exception:
        logger.error("Error in Getting Group Id Transactions!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_grouped_unmatch_transactions(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            selected_group_id = 0

            for k, v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "selected_group_id":
                    selected_group_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(selected_group_id) > 0:

                                        reco_results = RecoResults.objects.filter(generated_number_2 = selected_group_id, is_active = 1)

                                        for result in reco_results:
                                            reco_result_id = result.t_reco_result_id

                                        # print(reco_result_id)
                                        if len(str(reco_result_id)) > 0:
                                            reco_settings_external = RecoSettings.objects.filter(setting_key='ext_select_query_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)
                                            reco_settings_internal = RecoSettings.objects.filter(setting_key='int_select_query_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)

                                            setting_header_external = RecoSettings.objects.filter(setting_key='ext_header_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)
                                            setting_header_internal = RecoSettings.objects.filter(setting_key='int_header_all', tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id , processing_layer_id = processing_layer_id, is_active=1)

                                            for setting in reco_settings_external:
                                                external_select_query = setting.setting_value

                                            for setting in reco_settings_internal:
                                                internal_select_query = setting.setting_value

                                            for setting in setting_header_external:
                                                header_external = json.loads(setting.setting_value)

                                            for setting in setting_header_internal:
                                                header_internal = json.loads(setting.setting_value)

                                            record_status = "GroupUnMatched"

                                            external_select_query_proper = external_select_query.replace(
                                                "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                        str(group_id)).replace(
                                                "{entities_id}", str(entity_id)).replace(
                                                "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                                "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                                "{processing_layer_id}", str(processing_layer_id)).replace(
                                                "{processing_status_1}", record_status).replace("{conditions}", "AND ext_generated_number_2 = " + str(selected_group_id))
                                            # print(external_select_query_proper)
                                            internal_select_query_proper = internal_select_query.replace(
                                                "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                        str(group_id)).replace(
                                                "{entities_id}", str(entity_id)).replace(
                                                "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                                "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                                "{processing_layer_id}", str(processing_layer_id)).replace(
                                                "{processing_status_1}", record_status).replace("{conditions}", "AND int_generated_number_2 = " + str(selected_group_id))
                                            # print(internal_select_query_proper)
                                            external_query_out = json.loads(execute_sql_query(external_select_query_proper, object_type="table"))
                                            internal_query_out = json.loads(execute_sql_query(internal_select_query_proper, object_type="table"))

                                            external_query_out["headers"] = get_grid_transform(external_query_out, header_external)
                                            internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                            return JsonResponse({
                                                "Status": "Success",
                                                "external_records": external_query_out,
                                                "internal_records": internal_query_out
                                            })

                                        return JsonResponse({"Status": "Success"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
    except Exception:
        logger.error("Error in Getting Grouped UnMatch Transactions!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_intext_unmatched_transactions(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)
            print(data)
            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            external_records_id = 0
            internal_records_id = 0
            external_contra_ids = None
            internal_contra_ids = None
            external_group_ids  = None
            internal_group_ids = None
            t_internal_records_id=0
            t_external_records_id=0
            reco_results_ext=None
            reco_results_ext_group=None
            t_generated_number_1=0
            t_generated_number_2=0
            ext_condition=''
            int_condition=''
            update_record_status = ''

            for k, v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if  k == "external_records_ids":
                    external_records_id = v
                if k == "internal_records_ids":
                    internal_records_id = v
                if  k == "external_group_ids":
                    external_group_ids = v
                if  k == "internal_group_ids":
                    internal_group_ids = v
                if  k == "external_contra_ids":
                    external_contra_ids = v
                if k == "internal_contra_ids":
                    internal_contra_ids = v
                if k == "update_record_status":
                    update_record_status = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if (update_record_status == 'UNMATCHED'):
                                        if int(external_records_id[0]) > 0 and int(internal_records_id[0]) > 0:
                                            TransactionExternalRecords.objects.filter(external_records_id=external_records_id[0]).update(ext_processing_status_1='UnMatched')
                                            TransactionInternalRecords.objects.filter(internal_records_id=internal_records_id[0]).update(int_processing_status_1='UnMatched')
                                            RecoResults.objects.filter(t_external_records_id=external_records_id[0],t_internal_records_id=internal_records_id[0]).delete()
                                        elif external_group_ids is not None and  internal_group_ids is not None:
                                            print("first no",external_group_ids)
                                            reco_results_ext_group = TransactionExternalRecords.objects.get(external_records_id = external_group_ids[0])
                                            print("set ",reco_results_ext_group)
                                            t_generated_number_1 = reco_results_ext_group.ext_generated_number_1
                                            TransactionExternalRecords.objects.filter(external_records_id__in=external_group_ids).update(ext_processing_status_1='UnMatched',ext_generated_number_1=None)
                                            TransactionInternalRecords.objects.filter(internal_records_id__in=internal_group_ids).update(int_processing_status_1='UnMatched',int_generated_number_1=None)

                                            RecoResults.objects.filter(generated_number_1=t_generated_number_1).delete()
                                        elif external_contra_ids is not None:
                                            TransactionExternalRecords.objects.filter(external_records_id__in=external_contra_ids).update(ext_processing_status_1='UnMatched',ext_contra_id=None)
                                        elif internal_contra_ids is not None:
                                            TransactionInternalRecords.objects.filter(internal_records_id__in=internal_contra_ids).update(int_processing_status_1='UnMatched', int_contra_id=None)

                                        record_status = "Matched"
                                        reco_settings_external = RecoSettings.objects.filter(
                                            setting_key='ext_select_query_all', is_active=1)
                                        reco_settings_internal = RecoSettings.objects.filter(
                                            setting_key='int_select_query_all', is_active=1)

                                        setting_header_external = RecoSettings.objects.filter(
                                            setting_key='ext_header_all', is_active=1)
                                        setting_header_internal = RecoSettings.objects.filter(
                                            setting_key='int_header_all', is_active=1)

                                        for setting in reco_settings_external:
                                            external_select_query = setting.setting_value

                                        for setting in reco_settings_internal:
                                            internal_select_query = setting.setting_value

                                        for setting in setting_header_external:
                                            header_external = json.loads(setting.setting_value)

                                        for setting in setting_header_internal:
                                            header_internal = json.loads(setting.setting_value)

                                        external_select_query_proper = external_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", "")

                                        internal_select_query_proper = internal_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", record_status).replace("{conditions}", "")

                                        external_query_out = json.loads(
                                            execute_sql_query(external_select_query_proper, object_type="table"))
                                        internal_query_out = json.loads(
                                            execute_sql_query(internal_select_query_proper, object_type="table"))

                                        external_query_out["headers"] = get_grid_transform(external_query_out,
                                                                                           header_external)
                                        internal_query_out["headers"] = get_grid_transform(internal_query_out,
                                                                                           header_internal)

                                        return JsonResponse({
                                            "Status": "Success",
                                            "external_records": external_query_out,
                                            "internal_records": internal_query_out
                                        })
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "Unmatched Status Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Internal External Transaction Records!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_unmatched_transactions(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            external_records_ids = 0
            internal_records_ids = 0
            external_query_out = ''
            internal_query_out = ''

            for k, v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if  k == "external_records_ids":
                    external_records_ids = v
                if k == "internal_records_ids":
                    internal_records_ids = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(external_records_ids) > 0 :
                                        reco_settings_external = RecoSettings.objects.filter(setting_key = 'ext_select_query_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)
                                        setting_header_external = RecoSettings.objects.filter(setting_key = 'ext_header_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)

                                        for setting in reco_settings_external:
                                            external_select_query = setting.setting_value

                                        for setting in setting_header_external:
                                            header_external = json.loads(setting.setting_value)

                                        ext_condition = "AND external_records_id =" + str(external_records_ids)

                                        external_select_query_proper = external_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "AND ext_processing_status_1 = '{processing_status_1}'", "").replace(
                                            "{conditions}", ext_condition)
                                        # print(external_select_query_proper)
                                        external_query_out = json.loads(
                                            execute_sql_query(external_select_query_proper, object_type="table"))

                                        external_query_out["headers"] = get_grid_transform(external_query_out,
                                                                                           header_external)

                                    if int(internal_records_ids) > 0:
                                        reco_settings_internal = RecoSettings.objects.filter(setting_key='int_select_query_all', is_active=1)
                                        setting_header_internal = RecoSettings.objects.filter(setting_key='int_header_all',is_active=1)
                                        for setting in reco_settings_internal:
                                            internal_select_query = setting.setting_value
                                        for setting in setting_header_internal:
                                            header_internal = json.loads(setting.setting_value)
                                        int_condition = "AND internal_records_id =" + str(internal_records_ids)

                                        internal_select_query_proper = internal_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "AND int_processing_status_1 = '{processing_status_1}'", "").replace(
                                            "{conditions}", int_condition)
                                        print(internal_select_query_proper)
                                        internal_query_out = json.loads(
                                            execute_sql_query(internal_select_query_proper, object_type="table"))

                                        internal_query_out["headers"] = get_grid_transform(internal_query_out,
                                                                                           header_internal)
                                    return JsonResponse({
                                        "Status": "Success",
                                        "external_records": external_query_out,
                                        "internal_records": internal_query_out
                                    })
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Internal External Transaction Records!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

# @csrf_exempt
# def get_unmatched_matched_transactions(request, *args, **kwargs):
#     try:
#         if request.method == "POST":
#             body = request.body.decode('utf-8')
#             data = json.loads(body)
#
#             tenant_id = 0
#             group_id = 0
#             entity_id = 0
#             m_processing_layer_id = 0
#             m_processing_sub_layer_id = 0
#             processing_layer_id = 0
#             external_records_id = 0
#             internal_records_id = 0
#             external_contra_ids = None
#             internal_contra_ids = None
#             external_group_ids  = None
#             internal_group_ids = None
#             t_internal_records_id=0
#             t_external_records_id=0
#             reco_results_ext=None
#             reco_results_ext_group=None
#             t_generated_number_1=0
#             t_generated_number_2=0
#             ext_condition=''
#             int_condition=''
#             update_record_status = ''
#
#             for k, v in data.items():
#                 if k == "tenant_id":
#                     tenant_id = v
#                 if k == "group_id":
#                     group_id = v
#                 if k == "entity_id":
#                     entity_id = v
#                 if k == "m_processing_layer_id":
#                     m_processing_layer_id = v
#                 if k == "m_processing_sub_layer_id":
#                     m_processing_sub_layer_id = v
#                 if k == "processing_layer_id":
#                     processing_layer_id = v
#                 if  k == "external_records_id":
#                     external_records_id = v
#                 if k == "internal_records_id":
#                     internal_records_id = v
#                 if  k == "external_group_ids":
#                     external_group_ids = v
#                 if  k == "internal_group_ids":
#                     internal_group_ids = v
#                 if  k == "external_contra_ids":
#                     external_contra_ids = v
#                 if k == "internal_contra_ids":
#                     internal_contra_ids = v
#                 if k == "update_record_status":
#                     update_record_status = v
#
#             if int(tenant_id) > 0:
#                 if int(group_id) > 0:
#                     if int(entity_id) > 0:
#                         if int(m_processing_layer_id) > 0:
#                             if int(m_processing_sub_layer_id) > 0:
#                                 if int(processing_layer_id) > 0:
#                                     if (update_record_status == 'Matched'):
#                                         if int(external_records_id) > 0 and int(internal_records_id) > 0:
#                                             TransactionExternalRecords.objects.filter(external_records_id=external_records_id).update(ext_processing_status_1='Matched')
#                                             TransactionInternalRecords.objects.filter(internal_records_id=internal_records_id).update(int_processing_status_1='Matched')
#                                             RecoResults.objects.create(
#                                                 t_external_records_id=external_records_id,
#                                                 t_internal_records_id=internal_records_id,
#                                                 m_processing_sub_layer_id = m_processing_sub_layer_id,
#                                                 processing_layer_id = processing_layer_id,
#                                                 reco_status = "SYSTEM-MATCHED",
#                                                 reco_category ="R_10_1" ,
#                                                 tenants_id=tenant_id,
#                                                 groups_id=group_id,
#                                                 entities_id=entity_id,
#                                                 is_active=1,
#                                                 created_by=1,
#                                                 created_date=timezone.now()
#                                             )
#                                         elif external_group_ids is not None and  internal_group_ids is not None:
#                                             recosettings=RecoSettings.objects.get(setting_key="group_id",m_processing_layer_id=processing_layer_id)
#                                             TransactionExternalRecords.objects.filter(external_records_id__in=external_group_ids).update(ext_processing_status_1='Matched',ext_generated_number_1=recosettings.setting_value)
#                                             TransactionInternalRecords.objects.filter(internal_records_id__in=internal_group_ids).update(int_processing_status_1='Matched',int_generated_number_1=recosettings.setting_value)
#
#                                             RecoResults.objects.create(
#                                                 m_processing_layer_id=m_processing_layer_id,
#                                                 m_processing_sub_layer_id=m_processing_sub_layer_id,
#                                                 processing_layer_id=processing_layer_id,
#                                                 generated_number_1=recosettings.setting_value,
#                                                 reco_status="SYSTEM-MATCHED",
#                                                 reco_category="R_10_G_AM_1",
#                                                 tenants_id=tenant_id,
#                                                 groups_id=group_id,
#                                                 entities_id=entity_id,
#                                                 is_active=1,
#                                                 created_by=1,
#                                                 created_date=timezone.now()
#
#                                             )
#                                         elif external_contra_ids is not None:
#                                             TransactionExternalRecords.objects.filter(external_records_id__in=external_contra_ids).update(ext_processing_status_1='Matched',ext_contra_id=None)
#                                         elif internal_contra_ids is not None:
#                                             TransactionInternalRecords.objects.filter(internal_records_id__in=internal_contra_ids).update(int_processing_status_1='Matched', int_contra_id=None)
#                                             RecoResults.objects.create(
#                                                 t_external_records_id=external_records_id,
#                                                 t_internal_records_id=internal_records_id,
#                                                 m_processing_layer_id=m_processing_layer_id,
#                                                 m_processing_sub_layer_id=m_processing_sub_layer_id,
#                                                 processing_layer_id=processing_layer_id,
#                                                 # generated_number_1=,
#                                                 # generated_number_2=,
#                                                 # generated_number_3=,
#                                                 # generated_number_4=,
#                                                 # generated_number_5=,
#                                                 reco_status="SYSTEM-MATCHED",
#                                                 reco_category="R_10_1",
#                                                 tenants_id=tenant_id,
#                                                 groups_id=group_id,
#                                                 entities_id=entity_id,
#                                                 is_active=1,
#                                                 created_by=1,
#                                                 created_date=timezone.now()
#
#                                             )
#
#                                         record_status = "Matched"
#                                         reco_settings_external = RecoSettings.objects.filter(
#                                             setting_key='ext_select_query_all', is_active=1)
#                                         reco_settings_internal = RecoSettings.objects.filter(
#                                             setting_key='int_select_query_all', is_active=1)
#
#                                         setting_header_external = RecoSettings.objects.filter(
#                                             setting_key='ext_header_all', is_active=1)
#                                         setting_header_internal = RecoSettings.objects.filter(
#                                             setting_key='int_header_all', is_active=1)
#
#                                         for setting in reco_settings_external:
#                                             external_select_query = setting.setting_value
#
#                                         for setting in reco_settings_internal:
#                                             internal_select_query = setting.setting_value
#
#                                         for setting in setting_header_external:
#                                             header_external = json.loads(setting.setting_value)
#
#                                         for setting in setting_header_internal:
#                                             header_internal = json.loads(setting.setting_value)
#
#                                         external_select_query_proper = external_select_query.replace(
#                                             "{tenants_id}", str(tenant_id)).replace("{groups_id}",
#                                                                                     str(group_id)).replace(
#                                             "{entities_id}", str(entity_id)).replace(
#                                             "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
#                                             "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
#                                             "{processing_layer_id}", str(processing_layer_id)).replace(
#                                             "{processing_status_1}", record_status).replace("{conditions}", "")
#
#                                         internal_select_query_proper = internal_select_query.replace(
#                                             "{tenants_id}", str(tenant_id)).replace("{groups_id}",
#                                                                                     str(group_id)).replace(
#                                             "{entities_id}", str(entity_id)).replace(
#                                             "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
#                                             "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
#                                             "{processing_layer_id}", str(processing_layer_id)).replace(
#                                             "{processing_status_1}", record_status).replace("{conditions}", "")
#
#                                         external_query_out = json.loads(
#                                             execute_sql_query(external_select_query_proper, object_type="table"))
#                                         internal_query_out = json.loads(
#                                             execute_sql_query(internal_select_query_proper, object_type="table"))
#
#                                         external_query_out["headers"] = get_grid_transform(external_query_out,
#                                                                                            header_external)
#                                         internal_query_out["headers"] = get_grid_transform(internal_query_out,
#                                                                                            header_internal)
#
#                                         return JsonResponse({
#                                             "Status": "Success",
#                                             "external_records": external_query_out,
#                                             "internal_records": internal_query_out
#                                         })
#                                     else:
#                                         return JsonResponse({"Status": "Error", "Message": "Unmatched Status Not Found!!!"})
#                                 else:
#                                     return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
#                             else:
#                                 return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
#                         else:
#                             return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
#                     else:
#                         return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
#                 else:
#                     return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
#             else:
#                 return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
#         else:
#             return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
#     except Exception:
#         logger.error("Error in Getting Internal External Transaction Records!!!", exc_info=True)
#         return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_update_unmatched_matched(request, *args, **Kwargs):
    try:
        file_processing = ''
        file_uploads = ReconFileUploads.objects.filter(is_processing = 1)
        for file in file_uploads:
            file_processing = "FILE"

        if file_processing == "":

            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            external_record_id_list = None
            internal_record_id_list = None

            for k, v in data.items():
                if k == "tenant_id":
                    tenant_id = v
                if k == "group_id":
                    group_id = v
                if k == "entity_id":
                    entity_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if k == "user_id":
                    user_id = v
                if k == "external_record_id_list":
                    external_record_id_list = v
                if  k == "internal_record_id_list":
                    internal_record_id_list = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if external_record_id_list is not None:
                                            if internal_record_id_list is not None:

                                                reco_settings = RecoSettings.objects.filter(tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id, setting_key='group_id')
                                                for setting in reco_settings:
                                                    group_id_value = setting.setting_value

                                                post_url = "http://localhost:50005/recon_etl/get_update_unmatched_matched/"
                                                payload = json.dumps({
                                                    "tenants_id": tenant_id,
                                                    "groups_id": group_id,
                                                    "entities_id": entity_id,
                                                    "m_processing_layer_id": m_processing_layer_id,
                                                    "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                    "processing_layer_id": processing_layer_id,
                                                    "reco_settings_group_id_value": group_id_value,
                                                    "user_id": user_id,
                                                    "external_record_id_list": external_record_id_list,
                                                    "internal_record_id_list": internal_record_id_list
                                                })
                                                headers = {
                                                    "Content-Type": "application/json"
                                                }
                                                response = requests.get(post_url, data=payload, headers=headers)
                                                if response.content:
                                                    # print(response.content)
                                                    content_data = json.loads(response.content)
                                                    if content_data["Status"] == "Success":

                                                        TransactionExternalRecords.objects.filter(external_records_id__in=external_record_id_list).update(ext_processing_status_1='GroupMatched', ext_match_type_1='USER-MATCHED', ext_record_status_1=1, ext_generated_number_1=group_id_value, modified_by=user_id, modified_date=timezone.now())
                                                        TransactionInternalRecords.objects.filter(internal_records_id__in=internal_record_id_list).update(int_processing_status_1='GroupMatched', int_match_type_1='USER-MATCHED', int_record_status_1=1, int_generated_number_1=group_id_value, modified_by=user_id, modified_date=timezone.now())

                                                        RecoResults.objects.create(
                                                            m_processing_layer_id=m_processing_layer_id,
                                                            m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                            processing_layer_id=processing_layer_id,
                                                            generated_number_1=group_id_value,
                                                            reco_status="USER-MATCHED",
                                                            is_active=1,
                                                            created_by=user_id,
                                                            created_date=timezone.now(),
                                                            modified_by=user_id,
                                                            modified_date=timezone.now()
                                                        )

                                                        for setting in reco_settings:
                                                            setting.setting_value = str(int(group_id_value) + 1)
                                                            setting.save()
                                                        return JsonResponse({"Status": "Success"})

                                                    elif content_data["Status"] == "Error":
                                                        logger.error("Error in Updating UnMatched Matched Records in Recon ETL Service!!!")
                                                        return JsonResponse({"Status": "Error"})
                                            else:
                                                return JsonResponse({"Status" : "Error", "Message": "Internal Record Id List Not Found!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "External Record Id List Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status" : "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "File", "Message": "File is Processing!!!"})
    except Exception:
        logger.error("Error in Updating to Matched!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_update_contra(request, *args, **kwargs):
    try:
        file_processing = ''
        file_uploads = ReconFileUploads.objects.filter(is_processing = 1)
        for file in file_uploads:
            file_processing = "FILE"

        if file_processing == "":

            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            external_contra_id_list = None
            internal_contra_id_list = None

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v
                if k == "userId":
                    user_id = v
                if k == "externalContraList":
                    external_contra_id_list = v
                if k == "internalContraList":
                    internal_contra_id_list = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if len(external_contra_id_list) > 0:
                                            reco_settings = RecoSettings.objects.filter(tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id, setting_key = 'ext_contra_id', is_active = 1)
                                            for setting in reco_settings:
                                                ext_contra_id = int(setting.setting_value)

                                            post_url = "http://localhost:50005/recon_etl/get_update_contra/"
                                            payload = json.dumps({
                                                "tenants_id": tenant_id,
                                                "groups_id": group_id,
                                                "entities_id": entity_id,
                                                "m_processing_layer_id": m_processing_layer_id,
                                                "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                "processing_layer_id": processing_layer_id,
                                                "ext_contra_id": ext_contra_id,
                                                "user_id": user_id,
                                                "external_contra_id_list": external_contra_id_list
                                            })
                                            headers = {
                                                "Content-Type": "application/json"
                                            }
                                            response = requests.get(post_url, data=payload, headers=headers)
                                            if response.content:
                                                # print(response.content)
                                                content_data = json.loads(response.content)
                                                if content_data["Status"] == "Success":

                                                    TransactionExternalRecords.objects.filter(external_records_id__in = external_contra_id_list).update(
                                                        ext_match_type_1 = 'Contra',
                                                        ext_match_type_2 = 'Contra',
                                                        ext_processing_status_1 = 'Contra',
                                                        ext_contra_id = ext_contra_id,
                                                        modified_by = user_id,
                                                        modified_date = timezone.now()
                                                    )

                                                    for setting in reco_settings:
                                                        setting.setting_value = str(ext_contra_id + 1)
                                                        setting.save()

                                                    return JsonResponse({"Status": "Success"})

                                                elif content_data["Status"] == "Error":
                                                    logger.error("Error in Updating External Contra in Recon ETL Service!!!")
                                                    return JsonResponse({"Status": "Error"})

                                        if len(internal_contra_id_list) > 0:
                                            reco_settings = RecoSettings.objects.filter(tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id, setting_key = 'int_contra_id', is_active = 1)
                                            for setting in reco_settings:
                                                int_contra_id = int(setting.setting_value)

                                            post_url = "http://localhost:50005/recon_etl/get_update_contra/"
                                            payload = json.dumps({
                                                "tenants_id": tenant_id,
                                                "groups_id": group_id,
                                                "entities_id": entity_id,
                                                "m_processing_layer_id": m_processing_layer_id,
                                                "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                "processing_layer_id": processing_layer_id,
                                                "int_contra_id": int_contra_id,
                                                "user_id": user_id,
                                                "internal_contra_id_list": internal_contra_id_list
                                            })
                                            headers = {
                                                "Content-Type": "application/json"
                                            }
                                            response = requests.get(post_url, data=payload, headers=headers)
                                            if response.content:
                                                # print(response.content)
                                                content_data = json.loads(response.content)
                                                if content_data["Status"] == "Success":

                                                    TransactionInternalRecords.objects.filter(internal_records_id__in = internal_contra_id_list).update(
                                                        int_match_type_1 = 'Contra',
                                                        int_match_type_2 = 'Contra',
                                                        int_processing_status_1 = 'Contra',
                                                        int_contra_id = int_contra_id,
                                                        modified_by = user_id,
                                                        modified_date = timezone.now()
                                                    )

                                                    for setting in reco_settings:
                                                        setting.setting_value = str(int_contra_id + 1)
                                                        setting.save()

                                                    return JsonResponse({"Status": "Success"})

                                                elif content_data["Status"] == "Error":
                                                    logger.error("Error in Updating Internal Contra in Recon ETL Service!!!")
                                                    return JsonResponse({"Status": "Error"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "File", "Message": "File is Processing!!!"})

    except Exception:
        logger.error("Error in Updating Contra Records!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_update_matched_unmatched(request, *args, **kwargs):
    try:

        file_processing = ''
        file_uploads = ReconFileUploads.objects.filter(is_processing = 1)
        for file in file_uploads:
            file_processing = "FILE"

        if file_processing == "":

            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            external_record_id = 0
            internal_record_id = 0

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v
                if k == "userId":
                    user_id = v
                if k == "externalRecordId":
                    external_record_id = v
                if  k == "internalRecordId":
                    internal_record_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if int(internal_record_id) > 0:
                                            if int(external_record_id) > 0:

                                                post_url = "http://localhost:50005/recon_etl/get_update_matched_unmatched/"
                                                payload = json.dumps({
                                                    "tenants_id": tenant_id,
                                                    "groups_id": group_id,
                                                    "entities_id": entity_id,
                                                    "m_processing_layer_id": m_processing_layer_id,
                                                    "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                    "processing_layer_id": processing_layer_id,
                                                    "user_id": user_id,
                                                    "external_record_id": external_record_id,
                                                    "internal_record_id": internal_record_id
                                                })
                                                headers = {
                                                    "Content-Type": "application/json"
                                                }
                                                response = requests.get(post_url, data=payload, headers=headers)

                                                if response.content:
                                                    # print(response.content)
                                                    content_data = json.loads(response.content)
                                                    if content_data["Status"] == "Success":

                                                        reco_results = RecoResults.objects.filter(m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id, t_external_records_id = external_record_id, t_internal_records_id = internal_record_id)

                                                        if reco_results is not None:
                                                            TransactionExternalRecords.objects.filter(external_records_id = external_record_id).update(ext_processing_status_1 = 'UnMatched', ext_match_type_1 = 'USER-UNMATCHED', ext_record_status_1 = 0, ext_generated_number_1 = None, modified_by = user_id, modified_date = timezone.now())
                                                            TransactionInternalRecords.objects.filter(internal_records_id = internal_record_id).update(int_processing_status_1 = 'UnMatched', int_match_type_1 = 'USER-UNMATCHED', int_record_status_1 = 0, int_generated_number_1 = None, modified_by = user_id, modified_date = timezone.now())

                                                            for result in reco_results:
                                                                result.reco_status = 'USER-UNMATCHED'
                                                                result.is_active = 0
                                                                result.modified_by = user_id
                                                                result.modified_date = timezone.now()
                                                                result.save()

                                                            return JsonResponse({"Status": "Success"})

                                                    elif content_data["Status"] == "Error":
                                                        logger.error("Error in Updating Matching UnMatched Records in Recon ETL Service!!!")
                                                        return JsonResponse({"Status": "Error"})
                                                else:
                                                    return JsonResponse({"Status" : "Error", "Message": "Response Content Not Found!!!"})
                                            else:
                                                return JsonResponse({"Status": "Error", "Message": "External Record Id Not Found!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "Internal Record Id Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "File", "Message": "File is Processing!!!"})
    except Exception:
        logger.error("Error in Updating to UnMatched!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_unmatch_grouped_unmatched_transactions(request, *args, **kwargs):
    try:
        file_processing = ''
        file_uploads = ReconFileUploads.objects.filter(is_processing = 1)
        for file in file_uploads:
            file_processing = "FILE"

        if file_processing == "":

            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            external_records_list = list()
            internal_records_list = list()

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v
                if k == "userId":
                    user_id = v
                if k == "externalRecordsList":
                    external_records_list = v
                if  k == "internalRecordsList":
                    internal_records_list = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if len(external_records_list) > 0:
                                            if len(internal_records_list) > 0:

                                                external_records_id = external_records_list[0]["external_records_id"]
                                                t_external_records = TransactionExternalRecords.objects.filter(external_records_id = external_records_id)

                                                generated_unmatched_sequence = 0

                                                for record in t_external_records:
                                                    generated_unmatched_sequence = record.ext_generated_number_2

                                                if generated_unmatched_sequence != 0:

                                                    post_url = "http://localhost:50005/recon_etl/get_unmatch_grouped_unmatched_transactions/"
                                                    payload = json.dumps({
                                                        "tenants_id": tenant_id,
                                                        "groups_id": group_id,
                                                        "entities_id": entity_id,
                                                        "m_processing_layer_id": m_processing_layer_id,
                                                        "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                        "processing_layer_id": processing_layer_id,
                                                        "user_id": user_id,
                                                        "selected_group_id": generated_unmatched_sequence
                                                    })
                                                    headers = {
                                                        "Content-Type": "application/json"
                                                    }
                                                    response = requests.get(post_url, data=payload, headers=headers)

                                                    if response.content:

                                                        content_data = json.loads(response.content)
                                                        if content_data["Status"] == "Success":

                                                            TransactionExternalRecords.objects.filter(
                                                                ext_generated_number_2=generated_unmatched_sequence,
                                                                tenants_id=tenant_id,
                                                                groups_id=group_id,
                                                                entities_id=entity_id,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id
                                                            ).update(
                                                                ext_processing_status_1='UnMatched',
                                                                ext_match_type_1='USER-UNMATCHED',
                                                                ext_record_status_1=0,
                                                                ext_generated_number_2=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            TransactionInternalRecords.objects.filter(
                                                                int_generated_number_2=generated_unmatched_sequence,
                                                                tenants_id=tenant_id,
                                                                groups_id=group_id,
                                                                entities_id=entity_id,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id
                                                            ).update(
                                                                int_processing_status_1='UnMatched',
                                                                int_match_type_1='USER-UNMATCHED',
                                                                int_record_status_1=0,
                                                                int_generated_number_2=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            RecoResults.objects.filter(
                                                                generated_number_2=generated_unmatched_sequence,
                                                                is_active=1,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id
                                                            ).update(
                                                                reco_status='USER-UNMATCHED',
                                                                is_active=0,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            return JsonResponse({"Status": "Success", "Message": "Records Updated Successfuly!!!"})
                                                        elif content_data["Status"] == "Error":
                                                            logger.error("Error in Updating Group UnMatched UnMatch Records in Recon ETL Service!!!")
                                                            return JsonResponse({"Status": "Error"})
                                                    else:
                                                        return JsonResponse({"Status": "Error", "Message": "Response Content Not Found!!!"})
                                                else:
                                                    return JsonResponse({"Status": "Error"})
                                            else:
                                                return JsonResponse({"Status": "Error", "Message": "Internal Records List Not Found!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "External Records List Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "File", "Message": "File is Processing!!!"})
    except Exception:
        logger.error("Error in Updating UnMatched Group UnMatched Transactions!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_match_grouped_unmatched_transactions(request, *args, **kwargs):
    try:

        file_processing = ''
        file_uploads = ReconFileUploads.objects.filter(is_processing = 1)
        for file in file_uploads:
            file_processing = "FILE"

        if file_processing == "":

            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            external_records_list = list()
            internal_records_list = list()

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v
                if k == "userId":
                    user_id = v
                if k == "externalRecordsList":
                    external_records_list = v
                if  k == "internalRecordsList":
                    internal_records_list = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if len(external_records_list) > 0:
                                            if len(internal_records_list) > 0:

                                                external_records_id = external_records_list[0]["external_records_id"]
                                                t_external_records = TransactionExternalRecords.objects.filter(external_records_id = external_records_id)

                                                generated_unmatched_sequence = 0

                                                for record in t_external_records:
                                                    generated_unmatched_sequence = record.ext_generated_number_2

                                                external_records_ids_list = list()
                                                internal_records_ids_list = list()

                                                for external_record in external_records_list:
                                                    external_records_ids_list.append(external_record["external_records_id"])

                                                for internal_record in internal_records_list:
                                                    internal_records_ids_list.append(internal_record["internal_records_id"])

                                                reco_settings = RecoSettings.objects.filter(
                                                    tenants_id = tenant_id,
                                                    groups_id = group_id,
                                                    entities_id = entity_id,
                                                    m_processing_layer_id = m_processing_layer_id,
                                                    m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                    processing_layer_id = processing_layer_id,
                                                    setting_key = 'group_id'
                                                )

                                                group_sequence = 0
                                                for setting in reco_settings:
                                                    group_sequence = setting.setting_value

                                                if group_sequence != 0:

                                                    post_url = "http://localhost:50005/recon_etl/get_match_grouped_unmatched_transactions/"
                                                    payload = json.dumps({
                                                        "tenants_id": tenant_id,
                                                        "groups_id": group_id,
                                                        "entities_id": entity_id,
                                                        "m_processing_layer_id": m_processing_layer_id,
                                                        "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                        "processing_layer_id": processing_layer_id,
                                                        "user_id": user_id,
                                                        "selected_group_id": generated_unmatched_sequence,
                                                        "external_records_ids_list": external_records_ids_list,
                                                        "internal_records_ids_list": internal_records_ids_list
                                                    })
                                                    headers = {
                                                        "Content-Type": "application/json"
                                                    }
                                                    response = requests.get(post_url, data=payload, headers=headers)

                                                    if response.content:

                                                        content_data = json.loads(response.content)
                                                        if content_data["Status"] == "Success":
                                                            TransactionExternalRecords.objects.filter(
                                                                external_records_id__in=external_records_ids_list
                                                            ).update(
                                                                ext_processing_status_1='GroupMatched',
                                                                ext_match_type_1='USER-MATCHED',
                                                                ext_record_status_1=1,
                                                                ext_generated_number_1=group_sequence,
                                                                ext_generated_number_2=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            TransactionInternalRecords.objects.filter(
                                                                internal_records_id__in=internal_records_ids_list
                                                            ).update(
                                                                int_processing_status_1='GroupMatched',
                                                                int_match_type_1='USER-MATCHED',
                                                                int_record_status_1=1,
                                                                int_generated_number_1=group_sequence,
                                                                int_generated_number_2=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            RecoResults.objects.create(
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id,
                                                                generated_number_1=group_sequence,
                                                                reco_status="USER-MATCHED",
                                                                is_active=1,
                                                                created_by=user_id,
                                                                created_date=timezone.now(),
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            for setting in reco_settings:
                                                                setting.setting_value = str(int(group_sequence) + 1)
                                                                setting.save()

                                                            TransactionExternalRecords.objects.filter(
                                                                ext_generated_number_2=generated_unmatched_sequence,
                                                                tenants_id=tenant_id,
                                                                groups_id=group_id,
                                                                entities_id=entity_id,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id
                                                            ).update(
                                                                ext_processing_status_1='UnMatched',
                                                                ext_match_type_1='USER-UNMATCHED',
                                                                ext_record_status_1=0,
                                                                ext_generated_number_2=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            TransactionInternalRecords.objects.filter(
                                                                int_generated_number_2=generated_unmatched_sequence,
                                                                tenants_id=tenant_id,
                                                                groups_id=group_id,
                                                                entities_id=entity_id,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id
                                                            ).update(
                                                                int_processing_status_1='UnMatched',
                                                                int_match_type_1='USER-UNMATCHED',
                                                                int_record_status_1=0,
                                                                int_generated_number_2=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )

                                                            RecoResults.objects.filter(
                                                                generated_number_2=generated_unmatched_sequence,
                                                                is_active=1,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id
                                                            ).update(
                                                                reco_status='USER-UNMATCHED',
                                                                is_active=0,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )
                                                        elif content_data["Status"] == "Error":
                                                            return JsonResponse({"Status": "Error", "Message": "Error in Updating Recon ETL Service"})
                                                    else:
                                                        return JsonResponse({"Status": "Error", "Message": "Response Content Not Found!!!"})

                                                    return JsonResponse({"Status": "Success"})
                                                else:
                                                    return JsonResponse({"Status": "Error"})
                                            else:
                                                return JsonResponse({"Status": "Error", "Message": "Internal Records List Not Found!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "External Records List Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "File", "Message": "File is Processing!!!"})
    except Exception:
        logger.error("Error in Updating Matched Group UnMatched Transactions!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_selected_contra_records(request, *args, **kwargs):
    try:
        body = request.body.decode('utf-8')
        data = json.loads(body)

        tenant_id = 0
        group_id = 0
        entity_id = 0
        m_processing_layer_id = 0
        m_processing_sub_layer_id = 0
        processing_layer_id = 0
        user_id = 0
        external_contra_id = 0
        internal_contra_id = 0

        for k, v in data.items():
            if k == "tenantId":
                tenant_id = v
            if k == "groupId":
                group_id = v
            if k == "entityId":
                entity_id = v
            if k == "mProcessingLayerId":
                m_processing_layer_id = v
            if k == "mProcessingSubLayerId":
                m_processing_sub_layer_id = v
            if k == "processingLayerId":
                processing_layer_id = v
            if k == "userId":
                user_id = v
            if k == "externalContraId":
                external_contra_id = v
            if k == "internalContraId":
                internal_contra_id = v

        if int(tenant_id) > 0:
            if int(group_id) > 0:
                if int(entity_id) > 0:
                    if int(m_processing_layer_id) > 0:
                        if int(m_processing_sub_layer_id) > 0:
                            if int(processing_layer_id) > 0:
                                if int(user_id) > 0:
                                    if int(external_contra_id) > 0:
                                        reco_settings_external = RecoSettings.objects.filter(setting_key = 'ext_select_query_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)
                                        setting_header_external = RecoSettings.objects.filter(setting_key = 'ext_header_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)

                                        for setting in reco_settings_external:
                                            external_select_query = setting.setting_value

                                        for setting in setting_header_external:
                                            header_external = json.loads(setting.setting_value)

                                        ext_condition = "AND ext_contra_id = " + str(external_contra_id)

                                        external_select_query_proper = external_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", "Contra").replace(
                                            "{conditions}", ext_condition)

                                        external_query_out = json.loads(execute_sql_query(external_select_query_proper, object_type="table"))
                                        external_query_out["headers"] = get_grid_transform(external_query_out, header_external)

                                        return JsonResponse({"Status": "Success", "external_records": external_query_out})

                                    elif int(internal_contra_id) > 0:
                                        reco_settings_internal = RecoSettings.objects.filter(setting_key = 'int_select_query_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)
                                        setting_header_internal = RecoSettings.objects.filter(setting_key = 'int_header_all', is_active = 1, tenants_id = tenant_id, groups_id = group_id, entities_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id)

                                        for setting in reco_settings_internal:
                                            internal_select_query = setting.setting_value

                                        for setting in setting_header_internal:
                                            header_internal = json.loads(setting.setting_value)

                                        int_condition = "AND int_contra_id = " + str(internal_contra_id)

                                        internal_select_query_proper = internal_select_query.replace(
                                            "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                    str(group_id)).replace(
                                            "{entities_id}", str(entity_id)).replace(
                                            "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                            "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                            "{processing_layer_id}", str(processing_layer_id)).replace(
                                            "{processing_status_1}", "Contra").replace(
                                            "{conditions}", int_condition)

                                        internal_query_out = json.loads(execute_sql_query(internal_select_query_proper, object_type="table"))
                                        internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                        return JsonResponse({"Status": "Success", "internal_records": internal_query_out})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing SUb Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})

    except Exception:
        logger.error("Error in Getting Selected Contra Records!!!", exc_info = True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_update_group_records_unmatched(request, *args, **kwargs):
    try:

        file_processing = ''
        file_uploads = ReconFileUploads.objects.filter(is_processing = 1)
        for file in file_uploads:
            file_processing = "FILE"

        if file_processing == "":

            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v
                if k == "userId":
                    user_id = v
                if k == "selectedGroupId":
                    selected_group_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if int(selected_group_id) > 0:

                                            post_url = "http://localhost:50005/recon_etl/get_update_group_records_unmatched/"
                                            payload = json.dumps({
                                                "tenants_id": tenant_id,
                                                "groups_id": group_id,
                                                "entities_id": entity_id,
                                                "m_processing_layer_id": m_processing_layer_id,
                                                "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                "processing_layer_id": processing_layer_id,
                                                "user_id": user_id,
                                                "selected_group_id": selected_group_id
                                            })
                                            headers = {
                                                "Content-Type": "application/json"
                                            }
                                            response = requests.get(post_url, data=payload, headers=headers)

                                            if response.content:
                                                # print(response.content)
                                                content_data = json.loads(response.content)
                                                if content_data["Status"] == "Success":

                                                    reco_results = RecoResults.objects.filter(generated_number_1 = selected_group_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id, is_active = 1)

                                                    if reco_results is not None:
                                                        TransactionExternalRecords.objects.filter(
                                                            ext_generated_number_1 = selected_group_id,
                                                            tenants_id = tenant_id,
                                                            groups_id = group_id,
                                                            entities_id = entity_id,
                                                            m_processing_layer_id = m_processing_layer_id,
                                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                            processing_layer_id = processing_layer_id,
                                                            is_active = 1
                                                        ).update(
                                                            ext_processing_status_1='UnMatched',
                                                            ext_match_type_1='USER-UNMATCHED',
                                                            ext_record_status_1=0,
                                                            ext_generated_number_1=None,
                                                            modified_by=user_id,
                                                            modified_date=timezone.now()
                                                        )

                                                        TransactionInternalRecords.objects.filter(
                                                            int_generated_number_1 = selected_group_id,
                                                            tenants_id=tenant_id,
                                                            groups_id=group_id,
                                                            entities_id=entity_id,
                                                            m_processing_layer_id=m_processing_layer_id,
                                                            m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                            processing_layer_id=processing_layer_id,
                                                            is_active=1
                                                        ).update(
                                                            int_processing_status_1='UnMatched',
                                                            int_match_type_1='USER-UNMATCHED',
                                                            int_record_status_1=0,
                                                            int_generated_number_1=None,
                                                            modified_by=user_id,
                                                            modified_date=timezone.now()
                                                        )

                                                        for result in reco_results:
                                                            result.reco_status = 'USER-UNMATCHED'
                                                            result.is_active = 0
                                                            result.modified_by = user_id
                                                            result.modified_date = timezone.now()
                                                            result.save()

                                                        return JsonResponse({"Status": "Success"})

                                                elif content_data["Status"] == "Success":
                                                    logger.error("Error in Updating group Records Matched UnMatched in Recon ETL Service!!!")
                                                    return JsonResponse({"Status": "Error"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "Selected Group Id Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "File", "Message": "File is Processing!!!"})
    except Exception:
        logger.error("Error in Updating Group Id Unmatched to Matched !!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_internal_external_headers(request, *args, **kwargs):
    try:
        body = request.body.decode('utf-8')
        data = json.loads(body)

        tenant_id = 0
        group_id = 0
        entity_id = 0
        m_processing_layer_id = 0
        m_processing_sub_layer_id = 0
        processing_layer_id = 0
        header_side = ''

        for k, v in data.items():
            if k == "tenantId":
                tenant_id = v
            if k == "groupId":
                group_id = v
            if k == "entityId":
                entity_id = v
            if k == "mProcessingLayerId":
                m_processing_layer_id = v
            if k == "mProcessingSubLayerId":
                m_processing_sub_layer_id = v
            if k == "processingLayerId":
                processing_layer_id = v
            if k == "headerSide":
                header_side = v

        if int(tenant_id) > 0:
            if int(group_id) > 0:
                if int(entity_id) > 0:
                    if int(m_processing_layer_id) > 0:
                        if int(m_processing_sub_layer_id) > 0:
                            if int(processing_layer_id) > 0:
                                if header_side == "External":
                                    reco_settings_external = RecoSettings.objects.filter(setting_key='ext_select_query_all', is_active=1, tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id)
                                    setting_header_external = RecoSettings.objects.filter(setting_key='ext_header_all', is_active=1, tenants_id=tenant_id, groups_id=group_id, entities_id=entity_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id)

                                    for setting in reco_settings_external:
                                        external_select_query = setting.setting_value

                                    for setting in setting_header_external:
                                        header_external = json.loads(setting.setting_value)

                                    external_select_query_proper = external_select_query.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "{processing_layer_id}", str(processing_layer_id)).replace(
                                        "{processing_status_1}", "").replace(
                                        "{conditions}", "")
                                    # print(external_select_query_proper)
                                    external_query_out = json.loads(execute_sql_query(external_select_query_proper, object_type="table"))

                                    external_query_out["headers"] = get_grid_transform(external_query_out, header_external)

                                    return JsonResponse({"Status": "Success", "external_records": external_query_out})

                                elif header_side == "Internal":

                                    reco_settings_internal = RecoSettings.objects.filter(setting_key='int_select_query_all', is_active=1)
                                    setting_header_internal = RecoSettings.objects.filter(setting_key='int_header_all', is_active=1)

                                    for setting in reco_settings_internal:
                                        internal_select_query = setting.setting_value

                                    for setting in setting_header_internal:
                                        header_internal = json.loads(setting.setting_value)

                                    internal_select_query_proper = internal_select_query.replace(
                                        "{tenants_id}", str(tenant_id)).replace("{groups_id}",
                                                                                str(group_id)).replace(
                                        "{entities_id}", str(entity_id)).replace(
                                        "{m_processing_layer_id}", str(m_processing_layer_id)).replace(
                                        "{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).replace(
                                        "{processing_layer_id}", str(processing_layer_id)).replace(
                                        "{processing_status_1}", "").replace(
                                        "{conditions}", "")

                                    internal_query_out = json.loads(execute_sql_query(internal_select_query_proper, object_type="table"))

                                    internal_query_out["headers"] = get_grid_transform(internal_query_out, header_internal)

                                    return JsonResponse({"Status": "Success", "internal_records": internal_query_out})

                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Header Side Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})

    except Exception:
        logger.error("Error in getting Internal External Headers!!!", exc_info = True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_unmatch_matched_contra(request, *args, **kwargs):
    try:
        file_processing = ''
        file_uploads = ReconFileUploads.objects.filter(is_processing = 1)
        for file in file_uploads:
            file_processing = "FILE"

        if file_processing == "":

            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            contra_side = ''
            contra_id = 0

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v
                if k == "userId":
                    user_id = v
                if k == "contraSide":
                    contra_side = v
                if k == "contraId":
                    contra_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if len(contra_side) > 0:
                                            if int(contra_id) > 0:
                                                post_url = "http://localhost:50005/recon_etl/get_unmatch_matched_contra/"
                                                payload = json.dumps({
                                                    "tenants_id": tenant_id,
                                                    "groups_id": group_id,
                                                    "entities_id": entity_id,
                                                    "m_processing_layer_id": m_processing_layer_id,
                                                    "m_processing_sub_layer_id": m_processing_sub_layer_id,
                                                    "processing_layer_id": processing_layer_id,
                                                    "user_id": user_id,
                                                    "contra_id": contra_id,
                                                    "contra_side": contra_side
                                                })
                                                headers = {
                                                    "Content-Type": "application/json"
                                                }
                                                response = requests.get(post_url, data=payload, headers=headers)

                                                if response.content:
                                                    # print(response.content)
                                                    content_data = json.loads(response.content)
                                                    if content_data["Status"] == "Success":
                                                        if contra_side == "External":
                                                            TransactionExternalRecords.objects.filter(
                                                                ext_contra_id = contra_id,
                                                                tenants_id=tenant_id,
                                                                groups_id=group_id,
                                                                entities_id=entity_id,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id,
                                                                is_active=1
                                                            ).update(
                                                                ext_processing_status_1='UnMatched',
                                                                ext_match_type_1='USER-UNMATCHED',
                                                                ext_record_status_1=0,
                                                                ext_contra_id=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )
                                                            return JsonResponse({"Status": "Success"})

                                                        if contra_side == "Internal":
                                                            TransactionInternalRecords.objects.filter(
                                                                int_contra_id=contra_id,
                                                                tenants_id=tenant_id,
                                                                groups_id=group_id,
                                                                entities_id=entity_id,
                                                                m_processing_layer_id=m_processing_layer_id,
                                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                                processing_layer_id=processing_layer_id,
                                                                is_active=1
                                                            ).update(
                                                                int_processing_status_1='UnMatched',
                                                                int_match_type_1='USER-UNMATCHED',
                                                                int_record_status_1=0,
                                                                int_contra_id=None,
                                                                modified_by=user_id,
                                                                modified_date=timezone.now()
                                                            )
                                                            return JsonResponse({"Status": "Success"})

                                                    elif content_data["Status"] == "Error":
                                                        logger.error("Error in UnMatching Matched Contra in Recon ETL Service!!!")
                                                        return JsonResponse({"Status": "Error"})
                                            else:
                                                return JsonResponse({"Status": "Error", "Message": "Contra Id List Not FOund!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "Contra Side Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "File", "Message": "File is Processing!!!"})
    except Exception:
        logger.error("Error in Unmatching matched Contra!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_insert_records(request, *args, **kwrgs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenants_id = 0
            groups_id = 0
            entities_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0

            for k, v in data.items():
                if k == "tenants_id":
                    tenants_id = v
                if k == "groups_id":
                    groups_id = v
                if k == "entities_id":
                    entities_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "internal_query_file":
                    internal_query_file = v
                if  k == "external_query_file":
                    external_query_file = v
                if  k == "recon_results_query_file":
                    recon_results_query_file = v
                if  k == "reco_settings_group_id_values_list":
                    reco_settings_group_id_values_list = v
                if  k == "reco_settings_etl_ext_contra_list":
                    reco_settings_etl_ext_contra_list = v
                if  k == "reco_settings_etl_int_contra_list":
                    reco_settings_etl_int_contra_list = v

            file = open(internal_query_file, 'r+')
            internal_query = file.read()
            file.close()

            file = open(external_query_file, 'r+')
            external_query = file.read()
            file.close()

            file = open(recon_results_query_file, 'r+')
            recon_results_query = file.read()
            file.close()

            setting_queries = SettingQueries.objects.filter(
                tenants_id = tenants_id,
                groups_id = groups_id,
                entities_id = entities_id,
                m_processing_layer_id = m_processing_layer_id,
                m_processing_sub_layer_id = m_processing_sub_layer_id,
                setting_key = 'insert_data'
            )

            for setting in reco_settings_group_id_values_list:
                reco_settings = RecoSettings.objects.filter(
                    tenants_id = setting["tenants_id"],
                    groups_id = setting["groups_id"],
                    entities_id = setting["entities_id"],
                    m_processing_layer_id = setting["m_processing_layer_id"],
                    m_processing_sub_layer_id = setting["m_processing_sub_layer_id"],
                    processing_layer_id = setting["processing_layer_id"],
                    setting_key = 'group_id'
                )
                for reco_setting in reco_settings:
                    reco_setting.setting_value = setting["group_id_value"]
                    reco_setting.save()

            for setting in reco_settings_etl_ext_contra_list:
                reco_settings = RecoSettings.objects.filter(
                    tenants_id = setting["tenants_id"],
                    groups_id = setting["groups_id"],
                    entities_id = setting["entities_id"],
                    m_processing_layer_id = setting["m_processing_layer_id"],
                    m_processing_sub_layer_id = setting["m_processing_sub_layer_id"],
                    processing_layer_id = setting["processing_layer_id"],
                    setting_key = 'ext_contra_id'
                )
                for reco_setting in reco_settings:
                    reco_setting.setting_value = setting["ext_contra_id"]
                    reco_setting.save()

            for setting in reco_settings_etl_int_contra_list:
                reco_settings = RecoSettings.objects.filter(
                    tenants_id=setting["tenants_id"],
                    groups_id=setting["groups_id"],
                    entities_id=setting["entities_id"],
                    m_processing_layer_id=setting["m_processing_layer_id"],
                    m_processing_sub_layer_id=setting["m_processing_sub_layer_id"],
                    processing_layer_id=setting["processing_layer_id"],
                    setting_key='int_contra_id'
                )
                for reco_setting in reco_settings:
                    reco_setting.setting_value = setting["int_contra_id"]
                    reco_setting.save()

            for setting in setting_queries:
                insert_data_query = setting.setting_value

            insert_data_query_proper = insert_data_query.replace("{params}", '"' + internal_query + '"' + "," + '"' + external_query + '"' + "," + '"' + recon_results_query + '"')
            # print(insert_data_query_proper)
            final_sp = execute_sql_query(insert_data_query_proper, object_type="Normal")
            if final_sp == "Success":
                logger.info("Data Inserted Successfully!!!")
                return JsonResponse({"Status": "Success", "Message": "Data Inserted Successfully!!!"})
            elif final_sp is None:
                logger.info("Error in Inserting Data!!!")
                return JsonResponse({"Status": "Error", "Message": "Error in Executing SP for Insert Records!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "GET Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Inserting Records!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_proper_file_name(file_name):
    try:
        file_name_extension = "." + file_name.split(".")[-1]
        file_name_without_extension = file_name.replace(file_name_extension, "")
        file_name_date = file_name_without_extension.replace(".", "") + "_" + str(datetime.now()).replace("-", "_").replace(" ", "_").replace(":", "_").replace(".","_") + file_name_extension
        file_name_proper = file_name_date.replace(" ", "_").replace("-", "_").replace("'", "").replace("#", "_No_").replace("&", "_").replace("(", "_").replace(")", "_")
        return file_name_proper
    except Exception:
        logger.error("Error in Getting Proper File Name!!!", exc_info=True)
        return "Error"

def get_proper_paths(input_path):
    try:
        file_location_to_data = input_path.split("Data/")[0] + "Data/"
        file_location_to_processing_layer_name = file_location_to_data + input_path.split("Data/")[1].split("/")[0]
        file_location_with_input = file_location_to_processing_layer_name + "/" + "input"
        return [file_location_to_processing_layer_name, file_location_with_input]
    except Exception:
        logger.error("Error in Getting Proper Paths!!!", exc_info=True)
        return "Error"

@csrf_exempt
def get_file_upload_transactions(request, *args, **kwargs):
    try:
        if request.method == "POST":

            tenant_id = request.POST.get("tenantId")
            group_id = request.POST.get("groupId")
            entity_id = request.POST.get("entityId")
            processing_layer_id = request.POST.get("processingLayerId")
            m_processing_layer_id = request.POST.get("mProcessingLayerId")
            m_processing_sub_layer_id = request.POST.get("mProcessingSubLayerId")
            user_id = request.POST.get("userId")
            file_uploaded = request.POST.get("fileUploaded")

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if len(file_uploaded) > 0:
                                            post_url = "http://localhost:50003/source/get_processing_layer_def_list/"
                                            payload = json.dumps(
                                                {"tenant_id": tenant_id, "group_id": group_id,
                                                 "entity_id": entity_id, "processing_layer_id": processing_layer_id})
                                            headers = {
                                                "Content-Type": "application/json"
                                            }
                                            response = requests.get(post_url, data=payload, headers=headers)
                                            # print(response)
                                            if response.content:
                                                content_data = json.loads(response.content)
                                                if content_data["Status"] == "Success":
                                                    if file_uploaded == "BOTH":

                                                        file_locations = content_data["file_locations"]

                                                        internal_file_name = request.FILES["internalFileName"].name
                                                        external_file_name = request.FILES["externalFileName"].name

                                                        internal_file_name_proper = get_proper_file_name(internal_file_name)
                                                        external_file_name_proper = get_proper_file_name(external_file_name)

                                                        internal_file_location = ''
                                                        external_file_location = ''

                                                        for file_location in file_locations :
                                                            if file_location['side'] == "Internal" :
                                                                int_source_id = file_location['source_id']
                                                                internal_file_location = file_location['input_location']
                                                                int_processing_layer_name = file_location['processing_layer_name']
                                                            elif file_location['side'] == "External" :
                                                                external_file_location = file_location['input_location']
                                                                ext_source_id = file_location['source_id']
                                                                ext_processing_layer_name = file_location['processing_layer_name']

                                                        file_uploads_internal = ReconFileUploads.objects.filter(m_source_id = int_source_id, is_processed = 0)
                                                        internal_file_upload_ids = []
                                                        for internal_file in file_uploads_internal:
                                                            internal_file_upload_ids.append(internal_file.m_source_id)

                                                        file_uploads_external = ReconFileUploads.objects.filter(m_source_id = ext_source_id, is_processed = 0)
                                                        external_file_upload_ids = []
                                                        for external_file in file_uploads_external:
                                                            external_file_upload_ids.append(external_file.m_source_id)

                                                        if len(internal_file_upload_ids) == 0 and len(external_file_upload_ids) == 0:
                                                            if len(internal_file_location) > 0 and len(external_file_location) > 0:

                                                                internal_file_upload_path_name_date = internal_file_location + internal_file_name_proper
                                                                external_file_upload_path_name_date = external_file_location + external_file_name_proper

                                                                internal_file_paths = get_proper_paths(internal_file_location)
                                                                external_file_paths = get_proper_paths(external_file_location)

                                                                if not os.path.exists(internal_file_paths[0]):
                                                                    os.mkdir(internal_file_paths[0])
                                                                if not os.path.exists(internal_file_paths[1]):
                                                                    os.mkdir(internal_file_paths[1])

                                                                if not os.path.exists(external_file_paths[0]):
                                                                    os.mkdir(external_file_paths[0])
                                                                if not os.path.exists(external_file_paths[1]):
                                                                    os.mkdir(external_file_paths[1])

                                                                with open(internal_file_upload_path_name_date, 'wb+') as destination:
                                                                    for chunk in request.FILES["internalFileName"]:
                                                                        destination.write(chunk)
                                                                internal_file_size = Path(internal_file_upload_path_name_date).stat().st_size

                                                                with open(external_file_upload_path_name_date, 'wb+') as destination:
                                                                    for chunk in request.FILES["externalFileName"]:
                                                                        destination.write(chunk)
                                                                external_file_size = Path(external_file_upload_path_name_date).stat().st_size

                                                                # TODO : Add row_count also in the below Table

                                                                ReconFileUploads.objects.create(
                                                                    tenants_id = tenant_id,
                                                                    groups_id = group_id,
                                                                    entities_id = entity_id,
                                                                    processing_layer_id = processing_layer_id,
                                                                    processing_layer_name = int_processing_layer_name,
                                                                    m_source_id = int_source_id,
                                                                    m_processing_layer_id = m_processing_layer_id,
                                                                    m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                                    source_type = 'FILE' ,
                                                                    extraction_type = "UPLOAD",
                                                                    file_name = internal_file_name_proper,
                                                                    file_size_bytes = internal_file_size,
                                                                    file_path = internal_file_upload_path_name_date,
                                                                    status = "BATCH",
                                                                    comments = "File in Batch!!!",
                                                                    is_processed = 0,
                                                                    is_processing = 0,
                                                                    is_active = 1,
                                                                    created_by = user_id,
                                                                    created_date = timezone.now(),
                                                                    modified_by = user_id,
                                                                    modified_date = timezone.now()
                                                                )

                                                                ReconFileUploads.objects.create(
                                                                    tenants_id = tenant_id,
                                                                    groups_id = group_id,
                                                                    entities_id = entity_id,
                                                                    processing_layer_id = processing_layer_id,
                                                                    processing_layer_name = ext_processing_layer_name,
                                                                    m_source_id = ext_source_id,
                                                                    m_processing_layer_id = m_processing_layer_id,
                                                                    m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                                    source_type = 'FILE',
                                                                    extraction_type = "UPLOAD",
                                                                    file_name = external_file_name_proper,
                                                                    file_size_bytes = external_file_size,
                                                                    file_path = external_file_upload_path_name_date,
                                                                    status = "BATCH",
                                                                    comments = "File in Batch!!!",
                                                                    is_processed = 0,
                                                                    is_processing = 0,
                                                                    is_active = 1,
                                                                    created_by = user_id,
                                                                    created_date = timezone.now(),
                                                                    modified_by = user_id,
                                                                    modified_date = timezone.now()
                                                                )
                                                                return JsonResponse({"Status": "Success","Message": "File Uploaded Sucessfully!!!"})
                                                            else:
                                                                logger.error("Error in Getting the input and external file locations!!!")
                                                                return JsonResponse({"Status": "Error"})
                                                        else:
                                                            return JsonResponse({"Status": "File Exists", "Message": "Already File Exists with Choosen relationship!!!"})

                                                    elif file_uploaded == "INTERNAL":
                                                        file_locations = content_data["file_locations"]
                                                        internal_file_name = request.FILES["internalFileName"].name
                                                        internal_file_name_proper = get_proper_file_name(internal_file_name)

                                                        internal_file_location = ''

                                                        for file_location in file_locations :
                                                            if file_location['side'] == "Internal" :
                                                                int_source_id = file_location['source_id']
                                                                internal_file_location = file_location['input_location']
                                                                int_processing_layer_name = file_location['processing_layer_name']

                                                        file_uploads_internal = ReconFileUploads.objects.filter(m_source_id = int_source_id, is_processed = 0)
                                                        internal_file_upload_ids = []
                                                        for internal_file in file_uploads_internal:
                                                            internal_file_upload_ids.append(internal_file.m_source_id)

                                                        if len(internal_file_upload_ids) == 0:
                                                            if len(internal_file_location) > 0:
                                                                internal_file_upload_path_name_date = internal_file_location + internal_file_name_proper
                                                                internal_file_paths = get_proper_paths(internal_file_location)

                                                                if not os.path.exists(internal_file_paths[0]):
                                                                    os.mkdir(internal_file_paths[0])
                                                                if not os.path.exists(internal_file_paths[1]):
                                                                    os.mkdir(internal_file_paths[1])

                                                                with open(internal_file_upload_path_name_date, 'wb+') as destination:
                                                                    for chunk in request.FILES["internalFileName"]:
                                                                        destination.write(chunk)
                                                                internal_file_size = Path(internal_file_upload_path_name_date).stat().st_size

                                                                # TODO : Add row_count also in the below Table

                                                                ReconFileUploads.objects.create(
                                                                    tenants_id = tenant_id,
                                                                    groups_id = group_id,
                                                                    entities_id = entity_id,
                                                                    processing_layer_id = processing_layer_id,
                                                                    processing_layer_name = int_processing_layer_name,
                                                                    m_source_id = int_source_id,
                                                                    m_processing_layer_id = m_processing_layer_id,
                                                                    m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                                    source_type = 'FILE' ,
                                                                    extraction_type = "UPLOAD",
                                                                    file_name = internal_file_name_proper,
                                                                    file_size_bytes = internal_file_size,
                                                                    file_path = internal_file_upload_path_name_date,
                                                                    status = "BATCH",
                                                                    comments = "File in Batch!!!",
                                                                    is_processed = 0,
                                                                    is_processing = 0,
                                                                    is_active = 1,
                                                                    created_by = user_id,
                                                                    created_date = timezone.now(),
                                                                    modified_by = user_id,
                                                                    modified_date = timezone.now()
                                                                )
                                                                return JsonResponse({"Status": "Success", "Message": "File Uploaded Sucessfully!!!"})
                                                            else:
                                                                logger.error("Error in Getting the Internal file locations!!!")
                                                                return JsonResponse({"Status": "Error"})
                                                        else:
                                                            return JsonResponse({"Status": "File Exists", "Message": "Already File Exists with Choosen relationship!!!"})

                                                    elif file_uploaded == "EXTERNAL":
                                                        file_locations = content_data["file_locations"]
                                                        external_file_name = request.FILES["externalFileName"].name

                                                        external_file_name_proper = get_proper_file_name(external_file_name)
                                                        external_file_location = ''

                                                        for file_location in file_locations :
                                                            if file_location['side'] == "External" :
                                                                external_file_location = file_location['input_location']
                                                                ext_source_id = file_location['source_id']
                                                                ext_processing_layer_name = file_location['processing_layer_name']

                                                        file_uploads_external = ReconFileUploads.objects.filter(m_source_id = ext_source_id, is_processed = 0)
                                                        external_file_upload_ids = []
                                                        for external_file in file_uploads_external:
                                                            external_file_upload_ids.append(external_file.m_source_id)

                                                        if len(external_file_upload_ids) == 0:
                                                            if len(external_file_location) > 0:
                                                                external_file_upload_path_name_date = external_file_location + external_file_name_proper
                                                                external_file_paths = get_proper_paths(external_file_location)

                                                                if not os.path.exists(external_file_paths[0]):
                                                                    os.mkdir(external_file_paths[0])
                                                                if not os.path.exists(external_file_paths[1]):
                                                                    os.mkdir(external_file_paths[1])

                                                                with open(external_file_upload_path_name_date, 'wb+') as destination:
                                                                    for chunk in request.FILES["externalFileName"]:
                                                                        destination.write(chunk)
                                                                external_file_size = Path(external_file_upload_path_name_date).stat().st_size

                                                                # TODO : Add row_count also in the below Table

                                                                ReconFileUploads.objects.create(
                                                                    tenants_id = tenant_id,
                                                                    groups_id = group_id,
                                                                    entities_id = entity_id,
                                                                    processing_layer_id = processing_layer_id,
                                                                    processing_layer_name = ext_processing_layer_name,
                                                                    m_source_id = ext_source_id,
                                                                    m_processing_layer_id = m_processing_layer_id,
                                                                    m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                                    source_type = 'FILE',
                                                                    extraction_type = "UPLOAD",
                                                                    file_name = external_file_name_proper,
                                                                    file_size_bytes = external_file_size,
                                                                    file_path = external_file_upload_path_name_date,
                                                                    status = "BATCH",
                                                                    comments = "File in Batch!!!",
                                                                    is_processed = 0,
                                                                    is_processing = 0,
                                                                    is_active = 1,
                                                                    created_by = user_id,
                                                                    created_date = timezone.now(),
                                                                    modified_by = user_id,
                                                                    modified_date = timezone.now()
                                                                )
                                                                return JsonResponse({"Status": "Success", "Message": "File Uploaded Sucessfully!!!"})
                                                            else:
                                                                logger.error("Error in Getting the External file locations!!!")
                                                                return JsonResponse({"Status": "Error"})
                                                        else:
                                                            return JsonResponse({"Status": "File Exists", "Message": "Already File Exists with Choosen relationship!!!"})
                                                    else:
                                                        return JsonResponse({"Status": "Error", "Message": "Unknown File Upload Tye Found!!!"})
                                                elif content_data["Status"] == "Error":
                                                    logger.error("Error in Getting Processing Layer Definition List from Recon ETL Service!!!")
                                                    return JsonResponse({"Status": "Error"})
                                            else:
                                                return JsonResponse({"Status": "Error", "Message": "File Uploaded Not Found!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "Unmatched Status Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        logger.error("Error in File Upload !!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_file_upload_list(request, *args, **kwargs):
    try:
        if request.method == "GET":
            recon_file_upload_list = []
            recon_file_uploads = ReconFileUploads.objects.filter(status="BATCH").order_by('processing_layer_id','id')
            for file in recon_file_uploads:
                recon_file_upload_list.append({
                    "id"  :  file.id,
                    "tenants_id" : file.tenants_id,
                    "groups_id" : file.groups_id,
                    "entities_id" : file.entities_id,
                    "m_source_id" : file.m_source_id,
                    "m_processing_layer_id" : file.m_processing_layer_id,
                    "m_processing_sub_layer_id" : file.m_processing_sub_layer_id,
                    "processing_layer_id" : file.processing_layer_id,
                    "processing_layer_name" : file.processing_layer_name,
                    "source_type" : file.source_type,
                    "extraction_type" : file.extraction_type,
                    "file_name" : file.file_name,
                    "file_size_bytes" : file.file_size_bytes,
                    "file_path" : file.file_path,
                    "status" : file.status,
                    "comments" : file.comments,
                    "file_row_count" : file.file_row_count,
                    "is_processed" : file.is_processed,
                    "is_processing": file.is_processing,
                    "is_active" : file.is_active,
                    "created_by" : file.created_by,
                    "created_date" : file.created_date,
                    "modified_by" : file.modified_by,
                    "modified_date" : file.modified_date
                })

            file_data_distinct_query = "SELECT tenants_id, groups_id, entities_id, m_processing_layer_id, m_processing_sub_layer_id, processing_layer_id FROM recon_one.recon_file_uploads WHERE status = 'BATCH' GROUP BY tenants_id, groups_id, entities_id, m_processing_layer_id, m_processing_sub_layer_id, processing_layer_id;"
            file_data_distinct_output = json.loads(execute_sql_query(file_data_distinct_query, object_type = "table"))

            return JsonResponse({"Status": "Success", "file_upload_list": recon_file_upload_list, "file_data_distinct_list" : file_data_distinct_output})
        else:
            return JsonResponse({"Status": "Error", "Message": "GET Method Not Received!!!"})
    except Exception:
        logger.error("Error in Getting Batch File List!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_file_processed_list(request, *args, **kwargs):
    try:
        if request.method == "GET":
            file_processed_list = []
            recon_file_uploads = ReconFileUploads.objects.filter(status="PROCESSED").order_by('processing_layer_id','id')
            for file in recon_file_uploads:
                file_processed_list.append({
                    "id"  :  file.id,
                    "tenants_id" : file.tenants_id,
                    "groups_id" : file.groups_id,
                    "entities_id" : file.entities_id,
                    "m_source_id" : file.m_source_id,
                    "m_processing_layer_id" : file.m_processing_layer_id,
                    "m_processing_sub_layer_id" : file.m_processing_sub_layer_id,
                    "processing_layer_id" : file.processing_layer_id,
                    "processing_layer_name" : file.processing_layer_name,
                    "source_type" : file.source_type,
                    "extraction_type" : file.extraction_type,
                    "file_name" : file.file_name,
                    "file_size_bytes" : file.file_size_bytes,
                    "file_path" : file.file_path,
                    "status" : file.status,
                    "comments" : file.comments,
                    "file_row_count" : file.file_row_count,
                    "is_processed" : file.is_processed,
                    "is_processing": file.is_processing,
                    "is_active" : file.is_active,
                    "created_by" : file.created_by,
                    "created_date" : file.created_date,
                    "modified_by" : file.modified_by,
                    "modified_date" : file.modified_date
                })
            return JsonResponse({"Status": "Success", "file_processed_list": file_processed_list})
    except Exception:
        logger.error("Error in Getting Processed File List!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_brs_report(request, *args, **kwargs):
    try:
        if request.method == "POST":
            report_generation = ReportGeneration.objects.filter(is_report_generating = False)
            if report_generation:

                body = request.body.decode('utf-8')
                data = json.loads(body)

                tenant_id = 0
                group_id = 0
                entity_id = 0
                m_processing_layer_id = 0
                m_processing_sub_layer_id = 0
                processing_layer_id = 0
                user_id = 0
                report_date = ''

                for k, v in data.items():
                    if k == "tenantId":
                        tenant_id = v
                    if k == "groupId":
                        group_id = v
                    if k == "entityId":
                        entity_id = v
                    if k == "mProcessingLayerId":
                        m_processing_layer_id = v
                    if k == "mProcessingSubLayerId":
                        m_processing_sub_layer_id = v
                    if k == "processingLayerId":
                        processing_layer_id = v
                    if k == "userId":
                        user_id = v
                    if  k == "reportDate":
                        report_date = v

                if int(tenant_id) > 0:
                    if int(group_id) > 0:
                        if int(entity_id) > 0:
                            if int(m_processing_layer_id) > 0:
                                if int(m_processing_sub_layer_id) > 0:
                                    if int(processing_layer_id) > 0:
                                        if int(user_id) > 0:
                                            if len(report_date) > 0:

                                                report_generation_1 = ReportGeneration.objects.filter(id = 1)

                                                for report in report_generation_1:
                                                    report.is_report_generating = 1
                                                    report.save()

                                                reco_settings = RecoSettings.objects.filter(
                                                    tenants_id = tenant_id,
                                                    groups_id = group_id,
                                                    entities_id = entity_id,
                                                    m_processing_layer_id = m_processing_layer_id,
                                                    m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                    processing_layer_id = processing_layer_id,
                                                    setting_key = 'brs_report_proc'
                                                )

                                                for setting in reco_settings:
                                                    brs_report_procedure = setting.setting_value

                                                brs_report_procedure_proper = brs_report_procedure.replace("{tenant_id}", str(tenant_id)).\
                                                    replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                    replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                    replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                    replace("{processing_layer_id}", str(processing_layer_id)).\
                                                    replace("{user_id}", str(user_id)).replace("{report_date}", report_date)

                                                brs_report_output = execute_sql_query(brs_report_procedure_proper, object_type="Normal")

                                                reco_settings_rep_gl = RecoSettings.objects.filter(
                                                    tenants_id=tenant_id,
                                                    groups_id=group_id,
                                                    entities_id=entity_id,
                                                    m_processing_layer_id=m_processing_layer_id,
                                                    m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                    processing_layer_id=processing_layer_id,
                                                    setting_key='rep_gl_table'
                                                )

                                                for setting in reco_settings_rep_gl:
                                                    report_gl_query = setting.setting_value

                                                report_gl_query_proper = report_gl_query.replace("{tenant_id}",str(tenant_id)). \
                                                    replace("{group_id}", str(group_id)).replace("{entity_id}",str(entity_id)). \
                                                    replace("{m_processing_layer_id}", str(m_processing_layer_id)). \
                                                    replace("{m_processing_sub_layer_id}",str(m_processing_sub_layer_id)). \
                                                    replace("{processing_layer_id}", str(processing_layer_id)). \
                                                    replace("{user_id}", str(user_id)).replace("{report_date}", report_date)

                                                report_gl_query_output = execute_sql_query(report_gl_query_proper, object_type="Normal")

                                                if brs_report_output == "Success" and report_gl_query_output == "Success":
                                                    m_accounts = MasterBankAccounts.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id
                                                    )

                                                    for account in m_accounts:
                                                        company_name = account.tenant_name
                                                        bank_name = account.bank_name
                                                        relationship = account.processing_layer_name
                                                        branch_location = account.branch_location
                                                        account_type = account.account_type
                                                        account_number = account.bank_account_number
                                                        accpac_code = account.accpac_code

                                                    reco_settings = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='me_rep_gl_debit'
                                                    )

                                                    for setting in reco_settings:
                                                        gl_debits = setting.setting_value

                                                    reco_settings = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='me_rep_bank_debit'
                                                    )

                                                    for setting in reco_settings:
                                                        bank_debits = setting.setting_value

                                                    reco_settings = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='bank_closing_balance'
                                                    )

                                                    for setting in reco_settings:
                                                        bank_closing_balance = setting.setting_value

                                                    reco_settings = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='gl_closing_balance'
                                                    )

                                                    for setting in reco_settings:
                                                        gl_closing_balance = setting.setting_value

                                                    reco_settings_rep_gen = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='report_generation'
                                                    )

                                                    for setting in reco_settings_rep_gen:
                                                        report_generation_count = setting.setting_value

                                                    reco_settings_rep_gl_table = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='rep_gl_query'
                                                    )

                                                    for setting in reco_settings_rep_gl_table:
                                                        rep_gl_table_query = setting.setting_value

                                                    reco_settings_rep_gl_open_bal = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='rep_gl_opening_balance'
                                                    )

                                                    for setting in reco_settings_rep_gl_open_bal:
                                                        rep_gl_opening_balance_query = setting.setting_value

                                                    reco_settings_rep_bank_open_bal = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='rep_bank_opening_balance'
                                                    )

                                                    for setting in reco_settings_rep_bank_open_bal:
                                                        rep_bank_opening_balance_query = setting.setting_value

                                                    reco_settings_rep_bank_table = RecoSettings.objects.filter(
                                                        tenants_id=tenant_id,
                                                        groups_id=group_id,
                                                        entities_id=entity_id,
                                                        m_processing_layer_id=m_processing_layer_id,
                                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                        processing_layer_id=processing_layer_id,
                                                        setting_key='rep_bank_query'
                                                    )

                                                    for setting in reco_settings_rep_bank_table:
                                                        rep_bank_table_query = setting.setting_value

                                                    gl_debits_proper = gl_debits.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month_end_date}", report_date)

                                                    bank_debits_proper = bank_debits.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month_end_date}", report_date)

                                                    bank_closing_balance_proper = bank_closing_balance.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month_end_date}", report_date + " 00:00:00")

                                                    gl_closing_balance_proper = gl_closing_balance.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month_end_date}", report_date + " 00:00:00")

                                                    rep_gl_opening_balance_query_proper = rep_gl_opening_balance_query.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month}", report_date.split("-")[1])

                                                    rep_gl_table_query_proper = rep_gl_table_query.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month}", report_date.split("-")[1])

                                                    rep_bank_opening_balance_query_proper = rep_bank_opening_balance_query.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month}", report_date.split("-")[1])

                                                    rep_bank_table_query_proper = rep_bank_table_query.replace("{tenant_id}", str(tenant_id)).\
                                                        replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)).\
                                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                                        replace("{processing_layer_id}", str(processing_layer_id)).\
                                                        replace("{month}", report_date.split("-")[1]).replace("{month_date}", report_date)

                                                    # gl_debits = "select (@row_number := @row_number + 1 ) as `sl.no`, date_format(int_reference_date_time_1, '%d-%m-%Y') `Document Date`, ifnull(int_reference_text_3, '') as `Batch Number`, ifnull(int_reference_text_4, '') as `Journal Id`, ifnull(int_reference_text_10, '') as `Journal Description`, ifnull(int_reference_text_11, '') as `Transaction Description`, ifnull(int_reference_text_12, '') as `Cheque Number`, ifnull(int_reference_text_13, '') as `Transaction Reference`, ifnull(int_reference_text_14, '') as `Source Ledger`, ifnull(int_reference_text_15, '') as `Source Type`, ifnull(int_debit_amount, 0.00) as `Debit`, ifnull(int_credit_amount, 0.00)*(-1) as `Credit` from recon_one.t_internal_records,(select @row_number := 0) as t where tenants_id = 1 and groups_id = 1 and entities_id = 1 and m_processing_layer_id = 1 and m_processing_sub_layer_id = 1 and processing_layer_id = 1 and int_reference_date_time_1 <= '2021-02-10' order by int_reference_date_time_1 asc;"
                                                    gl_debits_output = execute_sql_query(gl_debits_proper, object_type="")[0]
                                                    bank_debits_output = execute_sql_query(bank_debits_proper, object_type="")[0]
                                                    bank_closing_balance_output = execute_sql_query(bank_closing_balance_proper, object_type="")[0].loc[0,0]
                                                    gl_closing_balance_output = execute_sql_query(gl_closing_balance_proper, object_type="")[0].loc[0,0]
                                                    rep_gl_table_query_output = execute_sql_query(rep_gl_table_query_proper, object_type="")[0]
                                                    rep_gl_opening_balance_query_output = execute_sql_query(rep_gl_opening_balance_query_proper, object_type="")[0].loc[0,0]
                                                    rep_bank_opening_balance_query_output = execute_sql_query(rep_bank_opening_balance_query_proper, object_type="")[0].loc[0,0]
                                                    rep_bank_table_query_output = execute_sql_query(rep_bank_table_query_proper, object_type="")[0]

                                                    data = {
                                                        "company_name": company_name,
                                                        "bank_name": bank_name,
                                                        "relationship": relationship,
                                                        "branch_location": branch_location,
                                                        "account_type": account_type,
                                                        "account_number": account_number,
                                                        "report_generation_date": str(datetime.today()),
                                                        "gl_debits_output": gl_debits_output,
                                                        "bank_debits_output": bank_debits_output,
                                                        "report_date": report_date,
                                                        "accpac_code": accpac_code,
                                                        "bank_code": relationship.split("-")[-1],
                                                        "bank_closing_balance": bank_closing_balance_output,
                                                        "gl_closing_balance": gl_closing_balance_output,
                                                        "report_generation_count": report_generation_count,
                                                        "rep_gl_table_query_output": rep_gl_table_query_output,
                                                        "rep_gl_opening_balance": rep_gl_opening_balance_query_output,
                                                        "rep_bank_opening_balance": rep_bank_opening_balance_query_output,
                                                        "rep_bank_table_query_output": rep_bank_table_query_output
                                                    }

                                                    brs_report_output = get_write_brs_report(data)

                                                    if brs_report_output["Status"] == "Success":
                                                        for setting in reco_settings_rep_gen:
                                                            setting.setting_value = str(int(report_generation_count) + 1)
                                                            setting.save()

                                                        for report in report_generation_1:
                                                            report.is_report_generating = 0
                                                            report.save()

                                                        return JsonResponse({"Status": "Success", "file_generated" : brs_report_output["file_generated"]})
                                                    else:
                                                        for report in report_generation_1:
                                                            report.is_report_generating = 0
                                                            report.save()

                                                        return JsonResponse({"Status": "Error"})

                                                else:
                                                    report_generation_1 = ReportGeneration.objects.filter(id=1)
                                                    for report in report_generation_1:
                                                        report.is_report_generating = 0
                                                        report.save()

                                                    return JsonResponse({"Status": "Error"})
                                            else:
                                                return JsonResponse({"Status": "Error", "Message": "Report Date Not Found!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Report Generating", "Message": "User is Currently Generating Report!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        report_generation_1 = ReportGeneration.objects.filter(id=1)
        for report in report_generation_1:
            report.is_report_generating = 0
            report.save()

        logger.error("Error in Getting BRS Report!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_write_brs_report(data):
    try:
        write_brs_output = write_brs.write_brs_file(data)
        if write_brs_output["Status"] == "Success":
            return {"Status" : "Success", "file_generated": write_brs_output["file_generated"]}
        elif write_brs_output["Status"] == "Error":
            logger.info("Error in Getting Write BRS Report!!!")
            logger.info(write_brs_output["Message"])
    except Exception:
        logger.error("Error in Writing BRS Report!!!", exc_info=True)
        return "Error"

@csrf_exempt
def get_month_close(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    setting_queries = SettingQueries.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        setting_key = 'month_closing_query'
                                    )

                                    for setting in setting_queries:
                                        month_closing_query = setting.setting_value

                                    month_closing_query_proper = month_closing_query.replace("{tenants_id}", str(tenant_id)).\
                                        replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                        replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                        replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                        replace("{processing_layer_id}", str(processing_layer_id))

                                    month_closing_query_output = json.loads(execute_sql_query(month_closing_query_proper, object_type="table"))
                                    month_closing_data = month_closing_query_output["data"]
                                    # print(month_closing_data)

                                    if len(month_closing_data) > 0:
                                        month_closing  = month_closing_data[0]["Closing Month"] + "-" + month_closing_data[0]["Closing Year"]
                                        data = {
                                            "bank_closing_date" : month_closing_data[0]["Bank Closing Date"],
                                            "bank_closing_balance": month_closing_data[0]["Bank Closing Balance"],
                                            "gl_closing_date": month_closing_data[0]["GL Closing Date"],
                                            "gl_closing_balance": month_closing_data[0]["GL Closing balance"],
                                            "month_closing": month_closing
                                        }

                                        return JsonResponse({"Status": "Success", "data": data})
                                    elif len(month_closing_data) == 0:
                                        return JsonResponse({"Status": "Success", "data": "NoMonth"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})

    except Exception:
        logger.error("Error in Getting Month End Closing Month!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def approve_month_close(request, *args, **kwargs):
    try:
        if request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            user_id = 0
            close_month_year = ''

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v
                if k == "closeMonthYear":
                    close_month_year = v
                if k == "userId":
                    user_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if len(close_month_year) > 0:
                                            close_month = calendar_month.get_month_value(close_month_year.split("-")[0])
                                            close_year = close_month_year.split("-")[1]
                                            setting_queries = SettingQueries.objects.filter(
                                                tenants_id=tenant_id,
                                                groups_id=group_id,
                                                entities_id=entity_id,
                                                m_processing_layer_id=m_processing_layer_id,
                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                setting_key='approve_month_close_bank_query'
                                            )

                                            for setting in setting_queries:
                                                mc_bank_query = setting.setting_value

                                            setting_queries = SettingQueries.objects.filter(
                                                tenants_id=tenant_id,
                                                groups_id=group_id,
                                                entities_id=entity_id,
                                                m_processing_layer_id=m_processing_layer_id,
                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                setting_key='approve_month_close_gl_query'
                                            )

                                            for setting in setting_queries:
                                                mc_gl_query = setting.setting_value

                                            mc_bank_query_proper = mc_bank_query.replace("{tenants_id}", str(tenant_id)).\
                                            replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                            replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                            replace("{processing_layer_id}", str(processing_layer_id)).\
                                            replace("{close_month}", close_month).replace("{close_year}", close_year)

                                            mc_gl_query_proper = mc_gl_query.replace("{tenants_id}", str(tenant_id)).\
                                            replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                            replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                            replace("{processing_layer_id}", str(processing_layer_id)).\
                                            replace("{close_month}", close_month).replace("{close_year}", close_year)

                                            mc_bank_query_output = execute_sql_query(mc_bank_query_proper, object_type="")
                                            mc_gl_query_output = execute_sql_query(mc_gl_query_proper, object_type="")

                                            month_close_bank_id_list = list(mc_bank_query_output[0][0])
                                            month_close_gl_id_list = list(mc_gl_query_output[0][0])

                                            DailyBalancesBank.objects.filter(daily_balances_bank_id__in = month_close_bank_id_list).update(
                                                approved_by = int(user_id),
                                                approved_date = timezone.now()
                                            )

                                            DailyBalancesGL.objects.filter(daily_balances_gl_id__in = month_close_gl_id_list).update(
                                                approved_by=int(user_id),
                                                approved_date=timezone.now()
                                            )

                                            closing_balances_bank = ClosingBalancesBank.objects.filter(
                                                tenants_id=tenant_id,
                                                groups_id=group_id,
                                                entities_id=entity_id,
                                                m_processing_layer_id=m_processing_layer_id,
                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                processing_layer_id=processing_layer_id,
                                                bank_closing_month = close_month_year.split("-")[0],
                                                bank_closing_year = close_month_year.split("-")[1]
                                            )

                                            for balance in closing_balances_bank:
                                                balance.approved_by = int(user_id)
                                                balance.approved_date = timezone.now()
                                                balance.save()

                                            closing_balances_gl = ClosingBalancesGL.objects.filter(
                                                tenants_id=tenant_id,
                                                groups_id=group_id,
                                                entities_id=entity_id,
                                                m_processing_layer_id=m_processing_layer_id,
                                                m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                processing_layer_id=processing_layer_id,
                                                gl_closing_month = close_month_year.split("-")[0],
                                                gl_closing_year = close_month_year.split("-")[1]
                                            )

                                            for balance in closing_balances_gl:
                                                balance.approved_by = int(user_id)
                                                balance.approved_date = timezone.now()
                                                balance.save()

                                            # setting_queries = SettingQueries.objects.filter(
                                            #     tenants_id=tenant_id,
                                            #     groups_id=group_id,
                                            #     entities_id=entity_id,
                                            #     m_processing_layer_id=m_processing_layer_id,
                                            #     m_processing_sub_layer_id=m_processing_sub_layer_id,
                                            #     setting_key='new_month_select_query'
                                            # )
                                            #
                                            # for setting in setting_queries:
                                            #     new_month_select_query = setting.setting_value
                                            #
                                            # new_month_select_query_proper = new_month_select_query.replace("{tenants_id}", str(tenant_id)).\
                                            # replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                            # replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                            # replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                            # replace("{processing_layer_id}", str(processing_layer_id))
                                            #
                                            # new_month_select_query_output = json.loads(execute_sql_query(new_month_select_query_proper, object_type="table"))
                                            # new_month_select_query_output_data = new_month_select_query_output["data"]
                                            #
                                            # print(new_month_select_query_output_data)
                                            #
                                            # bank_date = new_month_select_query_output_data[0]["Date"]
                                            # bank_opening_balance = new_month_select_query_output_data[0]["Bank Opening Balance"]
                                            # bank_month_name = calendar_month.get_month_name(bank_date.split("-")[1])
                                            # bank_new_year = bank_date.split("-")[0]

                                            # print(bank_date)
                                            # print(bank_opening_balance)
                                            # print(bank_month_name)
                                            # print(bank_new_year)

                                            # OpeningBalancesBank.objects.create(
                                            #     tenants_id = tenant_id,
                                            #     groups_id = group_id,
                                            #     entities_id = entity_id,
                                            #     m_processing_layer_id = m_processing_layer_id,
                                            #     m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            #     processing_layer_id = processing_layer_id,
                                            #     bank_opening_month = bank_month_name,
                                            #     bank_opening_year = bank_new_year,
                                            #     bank_opening_date = bank_date,
                                            #     bank_opening_balance = bank_opening_balance,
                                            #     approved_by = None,
                                            #     approved_date = None
                                            # )

                                            return JsonResponse({"Status": "Success"})

                                        else:
                                            return  JsonResponse({"Status": "Error", "Message": "Close Month Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})

        return JsonResponse({"Status": "Success"})
    except Exception:
        logger.error("Error in Approving Month Close!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_update_dates(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0
            bank_date = 'No Date'
            gl_date = 'No Date'

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    month_dates = calendar_month.days_cur_month()
                                    month_name = calendar_month.get_month_name(month_dates[0].split("-")[1])
                                    month_year = month_dates[0].split("-")[0]

                                    daily_balances_bank = DailyBalancesBank.objects.filter(
                                        tenants_id=tenant_id,
                                        groups_id=group_id,
                                        entities_id=entity_id,
                                        m_processing_layer_id=m_processing_layer_id,
                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                        processing_layer_id=processing_layer_id,
                                        date=month_dates[0]
                                    )

                                    for date in daily_balances_bank:
                                        bank_date = date.date

                                    daily_balances_gl = DailyBalancesGL.objects.filter(
                                        tenants_id=tenant_id,
                                        groups_id=group_id,
                                        entities_id=entity_id,
                                        m_processing_layer_id=m_processing_layer_id,
                                        m_processing_sub_layer_id=m_processing_sub_layer_id,
                                        processing_layer_id=processing_layer_id,
                                        date=month_dates[0]
                                    )

                                    for date in daily_balances_gl:
                                        gl_date = date.date

                                    if bank_date == "No Date" and gl_date == "No Date":
                                        for month in month_dates:
                                            DailyBalancesBank.objects.create(
                                                tenants_id = tenant_id,
                                                groups_id = group_id,
                                                entities_id = entity_id,
                                                m_processing_layer_id = m_processing_layer_id,
                                                m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                processing_layer_id = processing_layer_id,
                                                date = month,
                                                total_debits_bank = 0.00,
                                                total_credits_bank = 0.00,
                                                bank_opening_balance = 0.00,
                                                bank_closing_balance = 0.00
                                            )

                                            DailyBalancesGL.objects.create(
                                                tenants_id = tenant_id,
                                                groups_id = group_id,
                                                entities_id = entity_id,
                                                m_processing_layer_id = m_processing_layer_id,
                                                m_processing_sub_layer_id = m_processing_sub_layer_id,
                                                processing_layer_id = processing_layer_id,
                                                date = month,
                                                total_debits_gl = 0.00,
                                                total_credits_gl = 0.00,
                                                gl_opening_balance = 0.00,
                                                gl_closing_balance = 0.00
                                            )

                                        ClosingBalancesBank.objects.create(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            bank_closing_month = month_name,
                                            bank_closing_year = month_year,
                                            bank_closing_date = month_dates[-1],
                                            bank_closing_balance = 0.00
                                        )

                                        ClosingBalancesGL.objects.create(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            gl_closing_month = month_name,
                                            gl_closing_year = month_year,
                                            gl_closing_date = month_dates[-1],
                                            gl_closing_balance = 0.00
                                        )

                                    return JsonResponse({"Status": "Success"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return  JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "GET Method not Received!!!"})

    except Exception:
        logger.error("Error in Updating Dates!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

@csrf_exempt
def get_update_gl_balances(request, *args, **kwargs):
    try:
        if request.method == "GET" or request.method == "POST":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:
                                    # Getting the Latest Approved Date from Closing Balances GL Table
                                    closing_balances_gl = ClosingBalancesGL.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        approved_by__isnull = False,
                                        approved_date__isnull = False
                                    ).order_by('-gl_closing_date')[0]

                                    gl_closing_date = closing_balances_gl.gl_closing_date

                                    # print(gl_closing_date)

                                    # Get the list of dates from Daily Balances greater than the GL Closing Date
                                    daily_balances_gl = DailyBalancesGL.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        date__gt = gl_closing_date
                                    )

                                    # Making the List of Dates from the Records Fetched
                                    internal_date_list = []
                                    for record in daily_balances_gl:
                                        internal_date_list.append(str(record.date))

                                    # Loop Through the date and find the sum of debits and credits for the particular date from Internal Records Table and Update in the Daily Balance Gl Table
                                    for date in internal_date_list:
                                        t_internal_debit_amount_query = "SELECT IFNULL(SUM(int_debit_amount), 0.00) AS 'Internal Debit Amount' FROM recon_one.t_internal_records WHERE tenants_id = {tenants_id} AND groups_id = {groups_id} AND entities_id = {entities_id} AND m_processing_layer_id = {m_processing_layer_id} AND m_processing_sub_layer_id = {m_processing_sub_layer_id} AND processing_layer_id = {processing_layer_id} AND int_reference_date_time_1 = '{int_reference_date_time_1}' AND int_debit_amount IS NOT NULL;"
                                        t_internal_debit_amount_query_proper = t_internal_debit_amount_query.replace("{tenants_id}", str(tenant_id)).\
                                            replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                            replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                            replace("{processing_layer_id}", str(processing_layer_id)).\
                                            replace("{int_reference_date_time_1}", str(date))

                                        t_internal_credit_amount_query = "SELECT IFNULL(SUM(int_credit_amount), 0.00) AS 'Internal Credit Amount' FROM recon_one.t_internal_records WHERE tenants_id = {tenants_id} AND groups_id = {groups_id} AND entities_id = {entities_id} AND m_processing_layer_id = {m_processing_layer_id} AND m_processing_sub_layer_id = {m_processing_sub_layer_id} AND processing_layer_id = {processing_layer_id} AND int_reference_date_time_1 = '{int_reference_date_time_1}' AND int_credit_amount IS NOT NULL;"
                                        t_internal_credit_amount_query_proper = t_internal_credit_amount_query.replace("{tenants_id}", str(tenant_id)).\
                                            replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                            replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                            replace("{processing_layer_id}", str(processing_layer_id)).\
                                            replace("{int_reference_date_time_1}", str(date))

                                        t_internal_debit_amount_query_output = execute_sql_query(t_internal_debit_amount_query_proper, object_type="")[0].loc[0,0]
                                        t_internal_credit_amount_query_output = execute_sql_query(t_internal_credit_amount_query_proper, object_type="")[0].loc[0,0]

                                        DailyBalancesGL.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            date = date
                                        ).update(total_debits_gl = t_internal_debit_amount_query_output, total_credits_gl = t_internal_credit_amount_query_output)

                                    # Updating GL Opening Balance and GL Closing Balance in Daily Balances Gl Table

                                    # Step 1 : Taking the list of Dates in the order which was not approved by the user
                                    daily_balances_gl = DailyBalancesGL.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        approved_by__isnull = True,
                                        approved_date__isnull = True
                                    ).order_by('date')

                                    daily_balances_gl_date = []
                                    for date in daily_balances_gl:
                                        daily_balances_gl_date.append(date.date)

                                    # Get the Closing Balance of Last Month
                                    closing_balances_gl_balance = ClosingBalancesGL.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        approved_by__isnull = False,
                                        approved_date__isnull = False,
                                        gl_closing_date = str(gl_closing_date).split("+")[0]
                                    )

                                    for balance in closing_balances_gl_balance:
                                        approved_gl_closing_balance = balance.gl_closing_balance

                                    # Taking the individual date and loop through the order and update the balances in Daily Balances GL Table

                                    for date in daily_balances_gl_date:
                                        # print(date)
                                        particular_date_data = DailyBalancesGL.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            approved_by__isnull = True,
                                            approved_date__isnull = True,
                                            date = date
                                        )

                                        # Update the GL Opening Balance for that date as it is a closing Balance of the last month
                                        for data in particular_date_data:
                                            data.gl_opening_balance = approved_gl_closing_balance
                                            data.save()

                                        particular_date_data = DailyBalancesGL.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            approved_by__isnull = True,
                                            approved_date__isnull = True,
                                            date = date
                                        )

                                        for data in particular_date_data:
                                            data.gl_closing_balance = data.gl_opening_balance + data.total_debits_gl + data.total_credits_gl
                                            approved_gl_closing_balance = data.gl_closing_balance
                                            data.save()

                                        closing_balances_gl_end_balance = ClosingBalancesGL.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            approved_by__isnull = True,
                                            approved_date__isnull = True,
                                            gl_closing_date=date
                                        )

                                        for balance in closing_balances_gl_end_balance:
                                            balance.gl_closing_balance = approved_gl_closing_balance
                                            balance.save()

                                    return JsonResponse({"Status": "Success"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return  JsonResponse({"Status": "Error", "Message": "POST or GET Method Not Received!!!"})
    except Exception:
        logger.error("Error in Updating GL Balances!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_update_bank_balances(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            tenant_id = 0
            group_id = 0
            entity_id = 0
            m_processing_layer_id = 0
            m_processing_sub_layer_id = 0
            processing_layer_id = 0

            for k, v in data.items():
                if k == "tenantId":
                    tenant_id = v
                if k == "groupId":
                    group_id = v
                if k == "entityId":
                    entity_id = v
                if k == "mProcessingLayerId":
                    m_processing_layer_id = v
                if k == "mProcessingSubLayerId":
                    m_processing_sub_layer_id = v
                if k == "processingLayerId":
                    processing_layer_id = v

            if int(tenant_id) > 0:
                if int(group_id) > 0:
                    if int(entity_id) > 0:
                        if int(m_processing_layer_id) > 0:
                            if int(m_processing_sub_layer_id) > 0:
                                if int(processing_layer_id) > 0:

                                    # Getting the Latest Approved Date from Closing Balances Bank Table
                                    closing_balances_bank = ClosingBalancesBank.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        approved_by__isnull = False,
                                        approved_date__isnull = False
                                    ).order_by('-bank_closing_date')[0]

                                    bank_closing_date = closing_balances_bank.bank_closing_date

                                    # Get the list of dates from Daily Balances greater than the Bank Closing Date
                                    daily_balances_bank = DailyBalancesBank.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        date__gt = bank_closing_date
                                    )

                                    # Making the List of Dates from the Records Fetched
                                    external_date_list = []
                                    for record in daily_balances_bank:
                                        external_date_list.append(str(record.date))

                                    # Loop Through the date and find the sum of debits and credits for the particular date from Internal Records Table and Update in the Daily Balance Gl Table
                                    for date in external_date_list:
                                        t_external_debit_amount_query = "SELECT IFNULL(SUM(ext_debit_amount), 0.00) AS 'External Debit Amount' FROM recon_one.t_external_records WHERE tenants_id = {tenants_id} AND groups_id = {groups_id} AND entities_id = {entities_id} AND m_processing_layer_id = {m_processing_layer_id} AND m_processing_sub_layer_id = {m_processing_sub_layer_id} AND processing_layer_id = {processing_layer_id} AND ext_reference_date_time_1 = '{ext_reference_date_time_1}' AND ext_debit_amount IS NOT NULL;"
                                        t_external_debit_amount_query_proper = t_external_debit_amount_query.replace("{tenants_id}", str(tenant_id)).\
                                            replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                            replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                            replace("{processing_layer_id}", str(processing_layer_id)).\
                                            replace("{ext_reference_date_time_1}", str(date))

                                        t_external_credit_amount_query = "SELECT IFNULL(SUM(ext_credit_amount), 0.00) AS 'External Credit Amount' FROM recon_one.t_external_records WHERE tenants_id = {tenants_id} AND groups_id = {groups_id} AND entities_id = {entities_id} AND m_processing_layer_id = {m_processing_layer_id} AND m_processing_sub_layer_id = {m_processing_sub_layer_id} AND processing_layer_id = {processing_layer_id} AND ext_reference_date_time_1 = '{ext_reference_date_time_1}' AND ext_credit_amount IS NOT NULL;"
                                        t_external_credit_amount_query_proper = t_external_credit_amount_query.replace("{tenants_id}", str(tenant_id)).\
                                            replace("{groups_id}", str(group_id)).replace("{entities_id}", str(entity_id)).\
                                            replace("{m_processing_layer_id}", str(m_processing_layer_id)).\
                                            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)).\
                                            replace("{processing_layer_id}", str(processing_layer_id)).\
                                            replace("{ext_reference_date_time_1}", str(date))

                                        t_external_debit_amount_query_output = execute_sql_query(t_external_debit_amount_query_proper, object_type="")[0].loc[0,0]
                                        t_external_credit_amount_query_output = execute_sql_query(t_external_credit_amount_query_proper, object_type="")[0].loc[0,0]

                                        DailyBalancesBank.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            date = date
                                        ).update(total_debits_bank = t_external_debit_amount_query_output, total_credits_bank = t_external_credit_amount_query_output)

                                    # Updating Bank Opening Balance and GL Closing Balance in Daily Balances Gl Table

                                    # Step 1 : Taking the list of Dates in the order which was not approved by the user
                                    daily_balances_bank = DailyBalancesBank.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        approved_by__isnull = True,
                                        approved_date__isnull = True
                                    ).order_by('date')

                                    daily_balances_bank_date = []
                                    for date in daily_balances_bank:
                                        daily_balances_bank_date.append(date.date)

                                    # Get the Closing Balance of Last Month
                                    closing_balances_bank_balance = ClosingBalancesBank.objects.filter(
                                        tenants_id = tenant_id,
                                        groups_id = group_id,
                                        entities_id = entity_id,
                                        m_processing_layer_id = m_processing_layer_id,
                                        m_processing_sub_layer_id = m_processing_sub_layer_id,
                                        processing_layer_id = processing_layer_id,
                                        approved_by__isnull = False,
                                        approved_date__isnull = False,
                                        bank_closing_date = str(bank_closing_date).split("+")[0]
                                    )

                                    for balance in closing_balances_bank_balance:
                                        approved_bank_closing_balance = balance.bank_closing_balance

                                    # Taking the individual date and loop through the order and update the balances in Daily Balances Bank Table

                                    for date in daily_balances_bank_date:
                                        # print(date)
                                        particular_date_data = DailyBalancesBank.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            approved_by__isnull = True,
                                            approved_date__isnull = True,
                                            date = date
                                        )

                                        # Update the Bank Opening Balance for that date as it is a closing Balance of the last month
                                        for data in particular_date_data:
                                            data.bank_opening_balance = approved_bank_closing_balance
                                            data.save()

                                        particular_date_data = DailyBalancesBank.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            approved_by__isnull = True,
                                            approved_date__isnull = True,
                                            date = date
                                        )

                                        for data in particular_date_data:
                                            data.bank_closing_balance = data.bank_opening_balance + data.total_debits_bank + data.total_credits_bank
                                            approved_bank_closing_balance = data.bank_closing_balance
                                            data.save()

                                        closing_balances_bank_end_balance = ClosingBalancesBank.objects.filter(
                                            tenants_id = tenant_id,
                                            groups_id = group_id,
                                            entities_id = entity_id,
                                            m_processing_layer_id = m_processing_layer_id,
                                            m_processing_sub_layer_id = m_processing_sub_layer_id,
                                            processing_layer_id = processing_layer_id,
                                            approved_by__isnull = True,
                                            approved_date__isnull = True,
                                            bank_closing_date = date
                                        )

                                        for balance in closing_balances_bank_end_balance:
                                            balance.bank_closing_balance = approved_bank_closing_balance
                                            balance.save()

                                    return JsonResponse({"Status": "Success"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "Processing Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "GET Method Not Received!!!"})
    except Exception:
        logger.error("Error in Updating Bank Balances!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_update_file_status(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            file_status = ''
            file_uploads_id = 0

            for k,v in data.items():
                if k == "file_uploads_id":
                    file_uploads_id = v
                if  k == "file_status":
                    file_status = v
                if k == "tenants_id":
                    tenants_id = v
                if k == "groups_id":
                    groups_id = v
                if k == "entities_id":
                    entities_id = v
                if k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v

            if file_status == "Loaded":
                status = "LOADED"
                comments = "File Loaded. Waiting For Process!!!"
                is_processing = 0
                is_processed = 0

                recon_file_uploads = ReconFileUploads.objects.filter(id=file_uploads_id)

                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.is_processed = is_processed
                    file.is_processing = is_processing
                    file.save()

            elif file_status == "Loading Error":
                status = "ERROR"
                comments = "Error in Loading Data!!!"
                is_processing = 0
                is_processed = 0

                recon_file_uploads = ReconFileUploads.objects.filter(id=file_uploads_id)

                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.is_processed = is_processed
                    file.is_processing = is_processing
                    file.save()

            elif file_status == "Processing":
                status = "PROCESSING"
                comments = "Processing Data..."
                is_processing = 1
                is_processed = 0

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id = tenants_id, groups_id = groups_id, entities_id = entities_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = processing_layer_id, is_processing = 0, is_processed = 0, status = 'LOADED')

                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.is_processed = is_processed
                    file.is_processing = is_processing
                    file.save()

            elif file_status == "Processed":
                status = "PROCESSED"
                comments = "File Processed Successfully!!!"
                is_processing = 0
                is_processed = 1

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id=tenants_id, groups_id=groups_id, entities_id=entities_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, is_processed = 0, is_processing = 1, status = 'PROCESSING')

                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.is_processed = is_processed
                    file.is_processing = is_processing
                    file.save()

            elif file_status == "Zip Processed":
                status = "COMPLETED"
                comments = "File Extracted Successfully!!!"
                is_processing = 0
                is_processed = 1

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id=tenants_id, groups_id=groups_id, entities_id=entities_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, is_processed = 0, is_processing = 0, status = 'BATCH', id = file_uploads_id)

                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.is_processed = is_processed
                    file.is_processing = is_processing
                    file.save()

            elif file_status == "Balance":
                status = "UPDATE BALANCE"
                comments = "Updating Balances!!!"

                recon_file_uploads = ReconFileUploads.objects.filter(id = file_uploads_id)
                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.save()

            elif file_status == "Balance Updated":
                status = "COMPLETED"
                comments = "File Processing Completed Successfully!!!"

                recon_file_uploads = ReconFileUploads.objects.filter(id = file_uploads_id, status = 'UPDATE BALANCE')
                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.save()

            elif file_status == "Processing Error":
                status = "ERROR"
                comments = "Error in Processing Data!!!"
                is_processing = 0
                is_processed = 1

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id=tenants_id, groups_id=groups_id, entities_id=entities_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, processing_layer_id=processing_layer_id, is_processing = 1, is_processed = 0, status = 'LOADED')

                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.is_processed = is_processed
                    file.is_processing = is_processing
                    file.save()

            elif file_status == "Transfer Error":
                status = "ERROR"
                comments = "Error in Transfer Data!!!"
                is_processing = 0
                is_processed = 1

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id=tenants_id, groups_id=groups_id, entities_id=entities_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, is_processed = 1, is_processing = 0, status = 'PROCESSING')

                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.is_processed = is_processed
                    file.is_processing = is_processing
                    file.save()

            elif file_status == "Balance Error":
                status = "ERROR BALANCE"
                comments = "Error in Updating Balances for the File Uploaded!!!"

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id=tenants_id, groups_id=groups_id, entities_id=entities_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, is_processed = 1, is_processing = 0, status = 'UPDATE BALANCE')
                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.save()

            elif file_status == "Balance Error Bank":
                status = "ERROR BANK BALANCE"
                comments = "Error in Updating Bank Balance for the File Uploaded!!!"

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id=tenants_id, groups_id=groups_id, entities_id=entities_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, is_processed = 1, is_processing = 0, status = 'UPDATE BALANCE')
                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.save()

            elif file_status == "Balance Error GL":
                status = "ERROR GL BALANCE"
                comments = "Error in Updating GL Balance for the File Uploaded!!!"

                recon_file_uploads = ReconFileUploads.objects.filter(tenants_id=tenants_id, groups_id=groups_id, entities_id=entities_id, m_processing_layer_id=m_processing_layer_id, m_processing_sub_layer_id=m_processing_sub_layer_id, is_processed = 1, is_processing = 0, status = 'UPDATE BALANCE')
                for file in recon_file_uploads:
                    file.status = status
                    file.comments = comments
                    file.save()

            return JsonResponse({"Status": "Success"})
    except Exception:
        logger.error("Error in Updating File Status!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})


def get_consolidation_balances(tenant_id, group_id, entity_id, m_processing_layer_id, m_processing_sub_layer_id, processing_layer_id, bank_table_name, gl_table_name, report_date):
    try:
        setting_queries_bank_debit = SettingQueries.objects.filter(
            tenants_id=tenant_id,
            groups_id=group_id,
            entities_id=entity_id,
            m_processing_layer_id=m_processing_layer_id,
            m_processing_sub_layer_id=m_processing_sub_layer_id,
            setting_key='consol_report_bank_debit'
        )

        for setting in setting_queries_bank_debit:
            bank_debit_query = setting.setting_value

        setting_queries_bank_credit = SettingQueries.objects.filter(
            tenants_id=tenant_id,
            groups_id=group_id,
            entities_id=entity_id,
            m_processing_layer_id=m_processing_layer_id,
            m_processing_sub_layer_id=m_processing_sub_layer_id,
            setting_key='consol_report_bank_credit'
        )

        for setting in setting_queries_bank_credit:
            bank_credit_query = setting.setting_value

        setting_queries_gl_debit = SettingQueries.objects.filter(
            tenants_id=tenant_id,
            groups_id=group_id,
            entities_id=entity_id,
            m_processing_layer_id=m_processing_layer_id,
            m_processing_sub_layer_id=m_processing_sub_layer_id,
            setting_key='consol_report_gl_debit'
        )

        for setting in setting_queries_gl_debit:
            gl_debit_query = setting.setting_value

        setting_queries_gl_credit = SettingQueries.objects.filter(
            tenants_id=tenant_id,
            groups_id=group_id,
            entities_id=entity_id,
            m_processing_layer_id=m_processing_layer_id,
            m_processing_sub_layer_id=m_processing_sub_layer_id,
            setting_key='consol_report_gl_credit'
        )

        for setting in setting_queries_gl_credit:
            gl_credit_query = setting.setting_value

        reco_settings_bank = RecoSettings.objects.filter(
            tenants_id=tenant_id,
            groups_id=group_id,
            entities_id=entity_id,
            m_processing_layer_id=m_processing_layer_id,
            m_processing_sub_layer_id=m_processing_sub_layer_id,
            processing_layer_id=processing_layer_id,
            setting_key='bank_closing_balance'
        )
        for setting in reco_settings_bank:
            bank_closing_balance_query = setting.setting_value

        reco_settings_gl = RecoSettings.objects.filter(
            tenants_id=tenant_id,
            groups_id=group_id,
            entities_id=entity_id,
            m_processing_layer_id=m_processing_layer_id,
            m_processing_sub_layer_id=m_processing_sub_layer_id,
            processing_layer_id=processing_layer_id,
            setting_key='gl_closing_balance'
        )

        for setting in reco_settings_gl:
            gl_closing_balance_query = setting.setting_value

        # print(bank_table_name)

        bank_debit_query_proper = bank_debit_query.replace("{table_name}", bank_table_name)
        bank_credit_query_proper = bank_credit_query.replace("{table_name}", bank_table_name)
        gl_debit_query_proper = gl_debit_query.replace("{table_name}", gl_table_name)
        gl_credit_query_proper = gl_credit_query.replace("{table_name}", gl_table_name)

        # print(bank_debit_query_proper)
        # print(bank_credit_query_proper)
        # print(gl_debit_query_proper)
        # print(gl_credit_query_proper)

        bank_closing_balance_proper = bank_closing_balance_query.replace("{tenant_id}", str(tenant_id)). \
            replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)). \
            replace("{m_processing_layer_id}", str(m_processing_layer_id)). \
            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)). \
            replace("{processing_layer_id}", str(processing_layer_id)). \
            replace("{month_end_date}", report_date + " 00:00:00")

        gl_closing_balance_proper = gl_closing_balance_query.replace("{tenant_id}", str(tenant_id)). \
            replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)). \
            replace("{m_processing_layer_id}", str(m_processing_layer_id)). \
            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)). \
            replace("{processing_layer_id}", str(processing_layer_id)). \
            replace("{month_end_date}", report_date + " 00:00:00")

        # print(bank_closing_balance_proper)
        # print(gl_closing_balance_proper)

        bank_debit_query_proper_output = execute_sql_query(bank_debit_query_proper, object_type="")[0].loc[0, 0]
        bank_credit_query_proper_output = execute_sql_query(bank_credit_query_proper, object_type="")[0].loc[0, 0]
        gl_debit_query_proper_output = execute_sql_query(gl_debit_query_proper, object_type="")[0].loc[0, 0]
        gl_credit_query_proper_output = execute_sql_query(gl_credit_query_proper, object_type="")[0].loc[0, 0]
        bank_closing_balance_proper_output = execute_sql_query(bank_closing_balance_proper, object_type="")[0].loc[0, 0]
        gl_closing_balance_proper_output = execute_sql_query(gl_closing_balance_proper, object_type="")[0].loc[0, 0]

        if bank_debit_query_proper_output is None:
            bank_debit_query_proper_output = 0.00
        if bank_credit_query_proper_output is None:
            bank_credit_query_proper_output = 0.00
        if gl_debit_query_proper_output is None:
            gl_debit_query_proper_output = 0.00
        if gl_credit_query_proper_output is None:
            gl_credit_query_proper_output = 0.00
        if bank_closing_balance_proper_output is None:
            bank_closing_balance_proper_output = 0.00
        if gl_closing_balance_proper_output is None:
            gl_closing_balance_proper_output = 0.00

        # print(bank_table_name)

        return {
            "bank_debit" : bank_debit_query_proper_output,
            "bank_credit" : bank_credit_query_proper_output,
            "gl_debit": gl_debit_query_proper_output,
            "gl_credit": gl_credit_query_proper_output,
            "bank_closing_balance": bank_closing_balance_proper_output,
            "gl_closing_balance": gl_closing_balance_proper_output
        }

    except Exception:
        return "Error"


def get_update_balances(tenant_id, group_id, entity_id, m_processing_layer_id, m_processing_sub_layer_id, processing_layer_id, report_date, user_id):
    try:
        reco_settings = RecoSettings.objects.filter(
            tenants_id=tenant_id,
            groups_id=group_id,
            entities_id=entity_id,
            m_processing_layer_id=m_processing_layer_id,
            m_processing_sub_layer_id=m_processing_sub_layer_id,
            processing_layer_id=processing_layer_id,
            setting_key='brs_report_proc'
        )

        for setting in reco_settings:
            brs_report_procedure = setting.setting_value

        brs_report_procedure_proper = brs_report_procedure.replace("{tenant_id}", str(tenant_id)). \
            replace("{group_id}", str(group_id)).replace("{entity_id}", str(entity_id)). \
            replace("{m_processing_layer_id}", str(m_processing_layer_id)). \
            replace("{m_processing_sub_layer_id}", str(m_processing_sub_layer_id)). \
            replace("{processing_layer_id}", str(processing_layer_id)). \
            replace("{user_id}", str(user_id)).replace("{report_date}", report_date)

        execute_sql_query(brs_report_procedure_proper, object_type="Normal")

        return "Success"
    except Exception as e:
        print(e)
        logger.error("Error in Get Update Balances Function!!!")
        return  "Error"


@csrf_exempt
def get_consolidation_report(request, *args, **kwargs):
    try:
        if request.method == "POST":
            report_generation = ReportGeneration.objects.filter(is_report_generating=False)
            if report_generation:

                body = request.body.decode('utf-8')
                data = json.loads(body)

                tenant_id = 0
                group_id = 0
                entity_id = 0
                m_processing_layer_id = 0
                m_processing_sub_layer_id = 0
                user_id = 0
                report_date = ''
                type_id = -1

                for k, v in data.items():
                    if k == "tenantId":
                        tenant_id = v
                    if k == "groupId":
                        group_id = v
                    if k == "entityId":
                        entity_id = v
                    if k == "mProcessingLayerId":
                        m_processing_layer_id = v
                    if k == "mProcessingSubLayerId":
                        m_processing_sub_layer_id = v
                    if k == "userId":
                        user_id = v
                    if  k == "reportDate":
                        report_date = v
                    if k == "typeId":
                        type_id = v

                if int(tenant_id) > 0:
                    if int(group_id) > 0:
                        if int(entity_id) > 0:
                            if int(m_processing_layer_id) > 0:
                                if int(m_processing_sub_layer_id) > 0:
                                    if int(user_id) > 0:
                                        if len(report_date) > 0:
                                            if int(type_id) > 0:
                                                report_generation_1 = ReportGeneration.objects.filter(id=1)

                                                for report in report_generation_1:
                                                    report.is_report_generating = 1
                                                    report.save()

                                                if int(type_id) == 1:

                                                    consol_balance_hdfc062 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 6, bank_table_name = "t_me_bank_hdfc062", gl_table_name = "t_me_gl_hdfc062", report_date = report_date)
                                                    consol_balance_hdfc295 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 9, bank_table_name = "t_me_bank_hdfc295", gl_table_name = "t_me_gl_hdfc295", report_date = report_date)
                                                    consol_balance_axis18294 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 1, bank_table_name = "t_me_bank_axis18294", gl_table_name = "t_me_gl_axis18294", report_date = report_date)
                                                    consol_balance_sbi90642  = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 34, bank_table_name = "t_me_bank_sbi90642", gl_table_name = "t_me_gl_sbi90642", report_date = report_date)
                                                    consol_balance_icici2605 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 23, bank_table_name = "t_me_bank_icici2605", gl_table_name="t_me_gl_icici2605", report_date = report_date)
                                                    consol_balance_hdfc828 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 7, bank_table_name = "t_me_bank_hdfc828", gl_table_name = "t_me_gl_hdfc828", report_date = report_date)
                                                    consol_balance_idbi1946 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 26, bank_table_name = "t_me_bank_idbi1946", gl_table_name = "t_me_gl_idbi1946", report_date = report_date)
                                                    consol_balance_kotak09195 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 30, bank_table_name = "t_me_bank_kotak09195", gl_table_name = "t_me_gl_kotak09195", report_date = report_date)
                                                    consol_balance_fedral6006 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 4, bank_table_name="t_me_bank_fedral6006", gl_table_name="t_me_gl_fedral6006", report_date = report_date)
                                                    consol_balance_axis1710 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 55, bank_table_name = "t_me_bank_axis1710", gl_table_name = "t_me_gl_axis1710", report_date = report_date)
                                                    consol_balance_kotak12521 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 31, bank_table_name = "t_me_bank_kotak12521", gl_table_name = "t_me_gl_kotak12521", report_date = report_date)
                                                    consol_balance_indus33974 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 27, bank_table_name = "t_me_bank_indus33974", gl_table_name = "t_me_gl_indus33974", report_date = report_date)
                                                    consol_balance_fedral5979 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 56, bank_table_name = "t_me_bank_fedral5979", gl_table_name = "t_me_gl_fedral5979", report_date = report_date)
                                                    consol_balance_hdfccms828 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 54, bank_table_name = "t_me_bank_hdfccms828", gl_table_name = "t_me_gl_hdfccms828", report_date = report_date)
                                                    consol_balance_kotak18019 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 32, bank_table_name = "t_me_bank_kotak18019", gl_table_name = "t_me_gl_kotak18019", report_date = report_date)
                                                    consol_balance_axis35274 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 2, bank_table_name = "t_me_bank_axis35274", gl_table_name = "t_me_gl_axis35274", report_date = report_date)
                                                    consol_balance_icici240 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 25, bank_table_name = "t_me_bank_icici240", gl_table_name = "t_me_gl_icici240", report_date = report_date)
                                                    consol_balance_rbl0110 = get_consolidation_balances(tenant_id = tenant_id, group_id = group_id, entity_id = entity_id, m_processing_layer_id = m_processing_layer_id, m_processing_sub_layer_id = m_processing_sub_layer_id, processing_layer_id = 33, bank_table_name="t_me_bank_rbl0110",gl_table_name="t_me_gl_rbl0110", report_date = report_date)

                                                    if consol_balance_hdfc062 != "Error" and consol_balance_axis18294 != "Error" \
                                                            and consol_balance_hdfc295 != "Error" and consol_balance_sbi90642 != "Error"\
                                                            and consol_balance_hdfc828 != "Error" and consol_balance_idbi1946 != "Error"\
                                                            and consol_balance_kotak09195 != "Error" and consol_balance_fedral6006 != "Error"\
                                                            and consol_balance_axis1710 != "Error" and consol_balance_kotak12521 != "Error"\
                                                            and consol_balance_indus33974 != "Error" and consol_balance_icici2605 != "Error"\
                                                            and consol_balance_fedral5979 != "Error" and consol_balance_hdfccms828 != "Error"\
                                                            and consol_balance_kotak18019 != "Error" and consol_balance_axis35274 != "Error"\
                                                            and consol_balance_icici240 != "Error" and consol_balance_rbl0110 != "Error":

                                                        bank_debit_axis18294 = consol_balance_axis18294["bank_debit"]
                                                        bank_credit_axis18294 = consol_balance_axis18294["bank_credit"]
                                                        gl_debit_axis18294 = consol_balance_axis18294["gl_debit"]
                                                        gl_credit_axis18294 = consol_balance_axis18294["gl_credit"]
                                                        bank_closing_balance_axis18294 = consol_balance_axis18294["bank_closing_balance"]
                                                        gl_closing_balance_axis18294 = consol_balance_axis18294["gl_closing_balance"]

                                                        bank_debit_hdfc062 = consol_balance_hdfc062["bank_debit"]
                                                        bank_credit_hdfc062 = consol_balance_hdfc062["bank_credit"]
                                                        gl_debit_hdfc062 = consol_balance_hdfc062["gl_debit"]
                                                        gl_credit_hdfc062 = consol_balance_hdfc062["gl_credit"]
                                                        bank_closing_balance_hdfc062 = consol_balance_hdfc062["bank_closing_balance"]
                                                        gl_closing_balance_hdfc062 = consol_balance_hdfc062["gl_closing_balance"]

                                                        bank_debit_hdfc295 = consol_balance_hdfc295["bank_debit"]
                                                        bank_credit_hdfc295 = consol_balance_hdfc295["bank_credit"]
                                                        gl_debit_hdfc295 = consol_balance_hdfc295["gl_debit"]
                                                        gl_credit_hdfc295 = consol_balance_hdfc295["gl_credit"]
                                                        bank_closing_balance_hdfc295 = consol_balance_hdfc295["bank_closing_balance"]
                                                        gl_closing_balance_hdfc295 = consol_balance_hdfc295["gl_closing_balance"]

                                                        bank_debit_sbi90642 = consol_balance_sbi90642["bank_debit"]
                                                        bank_credit_sbi90642 = consol_balance_sbi90642["bank_credit"]
                                                        gl_debit_sbi90642 = consol_balance_sbi90642["gl_debit"]
                                                        gl_credit_sbi90642 = consol_balance_sbi90642["gl_credit"]
                                                        bank_closing_balance_sbi90642 = consol_balance_sbi90642["bank_closing_balance"]
                                                        gl_closing_balance_sbi90642 = consol_balance_sbi90642["gl_closing_balance"]

                                                        bank_debit_icici2605 = consol_balance_icici2605["bank_debit"]
                                                        bank_credit_icici2605 = consol_balance_icici2605["bank_credit"]
                                                        gl_debit_icici2605 = consol_balance_icici2605["gl_debit"]
                                                        gl_credit_icici2605 = consol_balance_icici2605["gl_credit"]
                                                        bank_closing_balance_icici2605 = consol_balance_icici2605["bank_closing_balance"]
                                                        gl_closing_balance_icici2605 = consol_balance_icici2605["gl_closing_balance"]

                                                        bank_debit_hdfc828 = consol_balance_hdfc828["bank_debit"]
                                                        bank_credit_hdfc828 = consol_balance_hdfc828["bank_credit"]
                                                        gl_debit_hdfc828 = consol_balance_hdfc828["gl_debit"]
                                                        gl_credit_hdfc828 = consol_balance_hdfc828["gl_credit"]
                                                        bank_closing_balance_hdfc828 = consol_balance_hdfc828["bank_closing_balance"]
                                                        gl_closing_balance_hdfc828 = consol_balance_hdfc828["gl_closing_balance"]

                                                        bank_debit_idbi1946 = consol_balance_idbi1946["bank_debit"]
                                                        bank_credit_idbi1946 = consol_balance_idbi1946["bank_credit"]
                                                        gl_debit_idbi1946 = consol_balance_idbi1946["gl_debit"]
                                                        gl_credit_idbi1946 = consol_balance_idbi1946["gl_credit"]
                                                        bank_closing_balance_idbi1946 = consol_balance_idbi1946["bank_closing_balance"]
                                                        gl_closing_balance_idbi1946 = consol_balance_idbi1946["gl_closing_balance"]

                                                        bank_debit_kotak09195 = consol_balance_kotak09195["bank_debit"]
                                                        bank_credit_kotak09195 = consol_balance_kotak09195["bank_credit"]
                                                        gl_debit_kotak09195 = consol_balance_kotak09195["gl_debit"]
                                                        gl_credit_kotak09195 = consol_balance_kotak09195["gl_credit"]
                                                        bank_closing_balance_kotak09195 = consol_balance_kotak09195["bank_closing_balance"]
                                                        gl_closing_balance_kotak09195 = consol_balance_kotak09195["gl_closing_balance"]

                                                        bank_debit_fedral6006 = consol_balance_fedral6006["bank_debit"]
                                                        bank_credit_fedral6006 = consol_balance_fedral6006["bank_credit"]
                                                        gl_debit_fedral6006 = consol_balance_fedral6006["gl_debit"]
                                                        gl_credit_fedral6006 = consol_balance_fedral6006["gl_credit"]
                                                        bank_closing_balance_fedral6006 = consol_balance_fedral6006["bank_closing_balance"]
                                                        gl_closing_balance_fedral6006 = consol_balance_fedral6006["gl_closing_balance"]

                                                        bank_debit_axis1710 = consol_balance_axis1710["bank_debit"]
                                                        bank_credit_axis1710 = consol_balance_axis1710["bank_credit"]
                                                        gl_debit_axis1710 = consol_balance_axis1710["gl_debit"]
                                                        gl_credit_axis1710 = consol_balance_axis1710["gl_credit"]
                                                        bank_closing_balance_axis1710 = consol_balance_axis1710["bank_closing_balance"]
                                                        gl_closing_balance_axis1710 = consol_balance_axis1710["gl_closing_balance"]

                                                        bank_debit_kotak12521 = consol_balance_kotak12521["bank_debit"]
                                                        bank_credit_kotak12521 = consol_balance_kotak12521["bank_credit"]
                                                        gl_debit_kotak12521 = consol_balance_kotak12521["gl_debit"]
                                                        gl_credit_kotak12521 = consol_balance_kotak12521["gl_credit"]
                                                        bank_closing_balance_kotak12521 = consol_balance_kotak12521["bank_closing_balance"]
                                                        gl_closing_balance_kotak12521 = consol_balance_kotak12521["gl_closing_balance"]

                                                        bank_debit_indus33974 = consol_balance_indus33974["bank_debit"]
                                                        bank_credit_indus33974 = consol_balance_indus33974["bank_credit"]
                                                        gl_debit_indus33974 = consol_balance_indus33974["gl_debit"]
                                                        gl_credit_indus33974 = consol_balance_indus33974["gl_credit"]
                                                        bank_closing_balance_indus33974 = consol_balance_indus33974["bank_closing_balance"]
                                                        gl_closing_balance_indus33974 = consol_balance_indus33974["gl_closing_balance"]

                                                        bank_debit_fedral5979 = consol_balance_fedral5979["bank_debit"]
                                                        bank_credit_fedral5979 = consol_balance_fedral5979["bank_credit"]
                                                        gl_debit_fedral5979 = consol_balance_fedral5979["gl_debit"]
                                                        gl_credit_fedral5979 = consol_balance_fedral5979["gl_credit"]
                                                        bank_closing_balance_fedral5979 = consol_balance_fedral5979["bank_closing_balance"]
                                                        gl_closing_balance_fedral5979 = consol_balance_fedral5979["gl_closing_balance"]

                                                        bank_debit_hdfccms828 = consol_balance_hdfccms828["bank_debit"]
                                                        bank_credit_hdfccms828 = consol_balance_hdfccms828["bank_credit"]
                                                        gl_debit_hdfccms828 = consol_balance_hdfccms828["gl_debit"]
                                                        gl_credit_hdfccms828 = consol_balance_hdfccms828["gl_credit"]
                                                        bank_closing_balance_hdfccms828 = consol_balance_hdfccms828["bank_closing_balance"]
                                                        gl_closing_balance_hdfccms828 = consol_balance_hdfccms828["gl_closing_balance"]

                                                        bank_debit_kotak18019 = consol_balance_kotak18019["bank_debit"]
                                                        bank_credit_kotak18019 = consol_balance_kotak18019["bank_credit"]
                                                        gl_debit_kotak18019 = consol_balance_kotak18019["gl_debit"]
                                                        gl_credit_kotak18019 = consol_balance_kotak18019["gl_credit"]
                                                        bank_closing_balance_kotak18019 = consol_balance_kotak18019["bank_closing_balance"]
                                                        gl_closing_balance_kotak18019 = consol_balance_kotak18019["gl_closing_balance"]

                                                        bank_debit_axis35274 = consol_balance_axis35274["bank_debit"]
                                                        bank_credit_axis35274 = consol_balance_axis35274["bank_credit"]
                                                        gl_debit_axis35274 = consol_balance_axis35274["gl_debit"]
                                                        gl_credit_axis35274 = consol_balance_axis35274["gl_credit"]
                                                        bank_closing_balance_axis35274 = consol_balance_axis35274["bank_closing_balance"]
                                                        gl_closing_balance_axis35274 = consol_balance_axis35274["gl_closing_balance"]

                                                        bank_debit_icici240 = consol_balance_icici240["bank_debit"]
                                                        bank_credit_icici240 = consol_balance_icici240["bank_credit"]
                                                        gl_debit_icici240 = consol_balance_icici240["gl_debit"]
                                                        gl_credit_icici240 = consol_balance_icici240["gl_credit"]
                                                        bank_closing_balance_icici240 = consol_balance_icici240["bank_closing_balance"]
                                                        gl_closing_balance_icici240 = consol_balance_icici240["gl_closing_balance"]

                                                        bank_debit_rbl0110 = consol_balance_rbl0110["bank_debit"]
                                                        bank_credit_rbl0110 = consol_balance_rbl0110["bank_credit"]
                                                        gl_debit_rbl0110 = consol_balance_icici240["gl_debit"]
                                                        gl_credit_rbl0110 = consol_balance_icici240["gl_credit"]
                                                        bank_closing_balance_rbl0110 = consol_balance_icici240["bank_closing_balance"]
                                                        gl_closing_balance_rbl0110 = consol_balance_icici240["gl_closing_balance"]

                                                        setting_queries_rep_gen = SettingQueries.objects.filter(
                                                            tenants_id=tenant_id,
                                                            groups_id=group_id,
                                                            entities_id=entity_id,
                                                            m_processing_layer_id=m_processing_layer_id,
                                                            m_processing_sub_layer_id=m_processing_sub_layer_id,
                                                            setting_key='consol_rep_generation_staffing'
                                                        )

                                                        for setting in setting_queries_rep_gen:
                                                            report_generation_count = setting.setting_value

                                                        data = {
                                                            "bank_debit_axis18294": bank_debit_axis18294,
                                                            "bank_credit_axis18294": bank_credit_axis18294,
                                                            "gl_debit_axis18294": gl_debit_axis18294,
                                                            "gl_credit_axis18294": gl_credit_axis18294,
                                                            "bank_closing_balance_axis18294": bank_closing_balance_axis18294,
                                                            "gl_closing_balance_axis18294": gl_closing_balance_axis18294,
                                                            "bank_debit_hdfc062": bank_debit_hdfc062,
                                                            "bank_credit_hdfc062": bank_credit_hdfc062,
                                                            "gl_debit_hdfc062": gl_debit_hdfc062,
                                                            "gl_credit_hdfc062": gl_credit_hdfc062,
                                                            "bank_closing_balance_hdfc062": bank_closing_balance_hdfc062,
                                                            "gl_closing_balance_hdfc062": gl_closing_balance_hdfc062,
                                                            "bank_debit_hdfc295": bank_debit_hdfc295,
                                                            "bank_credit_hdfc295": bank_credit_hdfc295,
                                                            "gl_debit_hdfc295": gl_debit_hdfc295,
                                                            "gl_credit_hdfc295": gl_credit_hdfc295,
                                                            "bank_closing_balance_hdfc295": bank_closing_balance_hdfc295,
                                                            "gl_closing_balance_hdfc295": gl_closing_balance_hdfc295,
                                                            "bank_debit_sbi90642": bank_debit_sbi90642,
                                                            "bank_credit_sbi90642": bank_credit_sbi90642,
                                                            "gl_debit_sbi90642": gl_debit_sbi90642,
                                                            "gl_credit_sbi90642": gl_credit_sbi90642,
                                                            "bank_closing_balance_sbi90642": bank_closing_balance_sbi90642,
                                                            "gl_closing_balance_sbi90642": gl_closing_balance_sbi90642,
                                                            "bank_debit_icici2605": bank_debit_icici2605,
                                                            "bank_credit_icici2605": bank_credit_icici2605,
                                                            "gl_debit_icici2605": gl_debit_icici2605,
                                                            "gl_credit_icici2605": gl_credit_icici2605,
                                                            "bank_closing_balance_icici2605": bank_closing_balance_icici2605,
                                                            "gl_closing_balance_icici2605": gl_closing_balance_icici2605,
                                                            "bank_debit_hdfc828": bank_debit_hdfc828,
                                                            "bank_credit_hdfc828": bank_credit_hdfc828,
                                                            "gl_debit_hdfc828": gl_debit_hdfc828,
                                                            "gl_credit_hdfc828": gl_credit_hdfc828,
                                                            "bank_closing_balance_hdfc828": bank_closing_balance_hdfc828,
                                                            "gl_closing_balance_hdfc828": gl_closing_balance_hdfc828,
                                                            "bank_debit_idbi1946": bank_debit_idbi1946,
                                                            "bank_credit_idbi1946": bank_credit_idbi1946,
                                                            "gl_debit_idbi1946": gl_debit_idbi1946,
                                                            "gl_credit_idbi1946": gl_credit_idbi1946,
                                                            "bank_closing_balance_idbi1946": bank_closing_balance_idbi1946,
                                                            "gl_closing_balance_idbi1946": gl_closing_balance_idbi1946,
                                                            "bank_debit_kotak09195": bank_debit_kotak09195,
                                                            "bank_credit_kotak09195": bank_credit_kotak09195,
                                                            "gl_debit_kotak09195": gl_debit_kotak09195,
                                                            "gl_credit_kotak09195": gl_credit_kotak09195,
                                                            "bank_closing_balance_kotak09195": bank_closing_balance_kotak09195,
                                                            "gl_closing_balance_kotak09195": gl_closing_balance_kotak09195,
                                                            "bank_debit_fedral6006": bank_debit_fedral6006,
                                                            "bank_credit_fedral6006": bank_credit_fedral6006,
                                                            "gl_debit_fedral6006": gl_debit_fedral6006,
                                                            "gl_credit_fedral6006": gl_credit_fedral6006,
                                                            "bank_closing_balance_fedral6006": bank_closing_balance_fedral6006,
                                                            "gl_closing_balance_fedral6006": gl_closing_balance_fedral6006,
                                                            "bank_debit_axis1710": bank_debit_axis1710,
                                                            "bank_credit_axis1710": bank_credit_axis1710,
                                                            "gl_debit_axis1710": gl_debit_axis1710,
                                                            "gl_credit_axis1710": gl_credit_axis1710,
                                                            "bank_closing_balance_axis1710": bank_closing_balance_axis1710,
                                                            "gl_closing_balance_axis1710": gl_closing_balance_axis1710,
                                                            "bank_debit_kotak12521": bank_debit_kotak12521,
                                                            "bank_credit_kotak12521": bank_credit_kotak12521,
                                                            "gl_debit_kotak12521": gl_debit_kotak12521,
                                                            "gl_credit_kotak12521": gl_credit_kotak12521,
                                                            "bank_closing_balance_kotak12521": bank_closing_balance_kotak12521,
                                                            "gl_closing_balance_kotak12521": gl_closing_balance_kotak12521,
                                                            "bank_debit_indus33974": bank_debit_indus33974,
                                                            "bank_credit_indus33974": bank_credit_indus33974,
                                                            "gl_debit_indus33974": gl_debit_indus33974,
                                                            "gl_credit_indus33974": gl_credit_indus33974,
                                                            "bank_closing_balance_indus339740": bank_closing_balance_indus33974,
                                                            "gl_closing_balance_indus33974": gl_closing_balance_indus33974,
                                                            "bank_debit_fedral5979": bank_debit_fedral5979,
                                                            "bank_credit_fedral5979": bank_credit_fedral5979,
                                                            "gl_debit_fedral5979": gl_debit_fedral5979,
                                                            "gl_credit_fedral5979": gl_credit_fedral5979,
                                                            "bank_closing_balance_fedral5979": bank_closing_balance_fedral5979,
                                                            "gl_closing_balance_fedral5979": gl_closing_balance_fedral5979,
                                                            "bank_debit_hdfccms828": bank_debit_hdfccms828,
                                                            "bank_credit_hdfccms828": bank_credit_hdfccms828,
                                                            "gl_debit_hdfccms828": gl_debit_hdfccms828,
                                                            "gl_credit_hdfccms828": gl_credit_hdfccms828,
                                                            "bank_closing_balance_hdfccms828": bank_closing_balance_hdfccms828,
                                                            "gl_closing_balance_hdfccms828": gl_closing_balance_hdfccms828,
                                                            "bank_debit_kotak18019": bank_debit_kotak18019,
                                                            "bank_credit_kotak18019": bank_credit_kotak18019,
                                                            "gl_debit_kotak18019": gl_debit_kotak18019,
                                                            "gl_credit_kotak18019": gl_credit_kotak18019,
                                                            "bank_closing_balance_kotak18019": bank_closing_balance_kotak18019,
                                                            "gl_closing_balance_kotak18019": gl_closing_balance_kotak18019,
                                                            "bank_debit_axis35274": bank_debit_axis35274,
                                                            "bank_credit_axis35274": bank_credit_axis35274,
                                                            "gl_debit_axis35274": gl_debit_axis35274,
                                                            "gl_credit_axis35274": gl_credit_axis35274,
                                                            "bank_closing_balance_axis35274": bank_closing_balance_axis35274,
                                                            "gl_closing_balance_axis35274": gl_closing_balance_axis35274,
                                                            "bank_debit_icici240": bank_debit_icici240,
                                                            "bank_credit_icici240": bank_credit_icici240,
                                                            "gl_debit_icici240": gl_debit_icici240,
                                                            "gl_credit_icici240": gl_credit_icici240,
                                                            "bank_closing_balance_icici240": bank_closing_balance_icici240,
                                                            "gl_closing_balance_icici240": gl_closing_balance_icici240,
                                                            "bank_debit_rbl0110": bank_debit_rbl0110,
                                                            "bank_credit_rbl0110": bank_credit_rbl0110,
                                                            "gl_debit_rbl0110": gl_debit_rbl0110,
                                                            "gl_credit_rbl0110": gl_credit_rbl0110,
                                                            "bank_closing_balance_rbl0110": bank_closing_balance_rbl0110,
                                                            "gl_closing_balance_rbl0110": gl_closing_balance_rbl0110,
                                                            "report_generation_count": report_generation_count,
                                                            "report_date": report_date
                                                        }
                                                        # print(data)
                                                        consolidation_report_output = get_write_consolidation_report(data)

                                                        if consolidation_report_output["Status"] == "Success":
                                                            report_generation_1 = ReportGeneration.objects.filter(id=1)

                                                            for report in report_generation_1:
                                                                report.is_report_generating = 0
                                                                report.save()

                                                            for setting in setting_queries_rep_gen:
                                                                setting.setting_value = str(int(report_generation_count) + 1)
                                                                setting.save()

                                                            return JsonResponse({"Status": "Success", "file_generated": consolidation_report_output["file_generated"]})

                                                    elif consol_balance_axis18294 == "Error" and consol_balance_hdfc062 == "Error"\
                                                            and consol_balance_hdfc295 == "Error" and consol_balance_sbi90642 == "Error"\
                                                            and consol_balance_icici2605 == "Error" and consol_balance_hdfc828 == "Error"\
                                                            and consol_balance_idbi1946 == "Error" and consol_balance_kotak09195 == "Error"\
                                                            and consol_balance_fedral6006 == "Error" and consol_balance_axis1710 == "Error"\
                                                            and consol_balance_kotak12521 == "Error" and consol_balance_indus33974 == "Error"\
                                                            and consol_balance_fedral5979 == "Error" and consol_balance_hdfccms828 == "Error"\
                                                            and consol_balance_kotak18019 == "Error" and consol_balance_axis35274 == "Error"\
                                                            and consol_balance_icici240 == "Error" and consol_balance_rbl0110 == "Error":

                                                        report_generation_1 = ReportGeneration.objects.filter(id=1)

                                                        for report in report_generation_1:
                                                            report.is_report_generating = 0
                                                            report.save()

                                                        return JsonResponse({"Status": "Error"})

                                                elif int(type_id) == 2:
                                                    return JsonResponse({"Status": "Success"})
                                            else:
                                                return JsonResponse({"Status": "Error", "Message": "Type Id Not Found!!!"})
                                        else:
                                            return JsonResponse({"Status": "Error", "Message": "Report Date Not Found!!!"})
                                    else:
                                        return JsonResponse({"Status": "Error", "Message": "User Id Not Found!!!"})
                                else:
                                    return JsonResponse({"Status": "Error", "Message": "M Processing Sub Layer Id Not Found!!!"})
                            else:
                                return JsonResponse({"Status": "Error", "Message": "M Processing Layer Id Not Found!!!"})
                        else:
                            return JsonResponse({"Status": "Error", "Message": "Entity Id Not Found!!!"})
                    else:
                        return JsonResponse({"Status": "Error", "Message": "Group Id Not Found!!!"})
                else:
                    return JsonResponse({"Status": "Error", "Message": "Tenant Id Not Found!!!"})
            else:
                return JsonResponse({"Status": "Report Generating", "Message": "User is Currently Generating Report!!!"})
        else:
            return JsonResponse({"Status": "Error", "Message": "POST Method Not Received!!!"})
    except Exception:
        report_generation_1 = ReportGeneration.objects.filter(id=1)
        for report in report_generation_1:
            report.is_report_generating = 0
            report.save()

        logger.error("Error in Getting Consolidation Report!!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_write_consolidation_report(data):
    try:
        write_brs_output = write_brs.write_consolidation_file(data)
        if write_brs_output["Status"] == "Success":
            return {"Status" : "Success", "file_generated": write_brs_output["file_generated"]}
        elif write_brs_output["Status"] == "Error":
            logger.info("Error in Getting Write Consolidation Report!!!")
            logger.info(write_brs_output["Message"])
    except Exception:
        logger.error("Error in Writing Consolidation Report!!!", exc_info=True)
        return "Error"

def get_update_bank_files(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            for k,v in data.items():
                if k == "file_path":
                    file_path = v
                if  k == "tenants_id":
                    tenants_id = v
                if  k == "groups_id":
                    groups_id = v
                if  k == "entities_id":
                    entities_id = v
                if  k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if  k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if  k == "user_id":
                    user_id = v
                if k == "file_id":
                    file_id = v

            extract_files_output = extract_files.get_extract_bank_files(file_path)

            if extract_files_output["Status"] == "Success":
                extract_path = extract_files_output["path"]

                file_upload_url = "http://localhost:50004/recon/get_file_upload_transactions/"
                file_status_url = "http://localhost:50004/recon/get_update_file_status/"

                for file in os.listdir(extract_path):
                    external_file_name = open(extract_path + "/" + file, "rb")

                    processing_layer_id_output = get_processing_layer_id(file)
                    payload_file = {
                        "externalFileName" : external_file_name,
                    }
                    payload = {
                        "tenantId": tenants_id,
                        "groupId": groups_id,
                        "entityId": entities_id,
                        "processingLayerId": processing_layer_id_output["processing_layer_id"],
                        "mProcessingLayerId": m_processing_layer_id,
                        "mProcessingSubLayerId": m_processing_sub_layer_id,
                        "userId": user_id,
                        "fileUploaded": "EXTERNAL"
                    }
                    requests.post(file_upload_url, files = payload_file, data=payload, verify=False)
                    external_file_name.close()

                # Updating the Zip File Status
                headers = {
                    "Content-Type": "application/json"
                }
                payload_status = {
                    "file_uploads_id": file_id,
                    "file_status": "Zip Processed",
                    "tenants_id": tenants_id,
                    "groups_id": groups_id,
                    "entities_id": entities_id,
                    "m_processing_layer_id": m_processing_layer_id,
                    "m_processing_sub_layer_id": m_processing_sub_layer_id,
                    "processing_layer_id": processing_layer_id
                }
                data = json.dumps(payload_status)
                requests.get(file_status_url, headers=headers, data=data)

                shutil.rmtree(extract_path)

                return JsonResponse({"Status": "Success"})
            elif extract_files_output["Status"] == "Exists":
                return JsonResponse({"Status": "Success", "Message": "Extract Folder Already Exists!!!"})
    except Exception:
        logger.error("Error in Getting Update Bank Files !!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_update_erp_files(request, *args, **kwargs):
    try:
        if request.method == "GET":
            body = request.body.decode('utf-8')
            data = json.loads(body)

            for k,v in data.items():
                if k == "file_path":
                    file_path = v
                if  k == "tenants_id":
                    tenants_id = v
                if  k == "groups_id":
                    groups_id = v
                if  k == "entities_id":
                    entities_id = v
                if  k == "m_processing_layer_id":
                    m_processing_layer_id = v
                if  k == "m_processing_sub_layer_id":
                    m_processing_sub_layer_id = v
                if k == "processing_layer_id":
                    processing_layer_id = v
                if  k == "user_id":
                    user_id = v
                if k == "file_id":
                    file_id = v

            extract_files_output = extract_files.get_extract_erp_files(file_path)

            if extract_files_output["Status"] == "Success":
                extract_path = extract_files_output["path"]

                file_upload_url = "http://localhost:50004/recon/get_file_upload_transactions/"
                file_status_url = "http://localhost:50004/recon/get_update_file_status/"

                for file in os.listdir(extract_path):
                    internal_file_name = open(extract_path + "/" + file, "rb")

                    processing_layer_id_output = get_processing_layer_id(file)
                    payload_file = {
                        "internalFileName" : internal_file_name,
                    }
                    payload = {
                        "tenantId": tenants_id,
                        "groupId": groups_id,
                        "entityId": entities_id,
                        "processingLayerId": processing_layer_id_output["processing_layer_id"],
                        "mProcessingLayerId": m_processing_layer_id,
                        "mProcessingSubLayerId": m_processing_sub_layer_id,
                        "userId": user_id,
                        "fileUploaded": "INTERNAL"
                    }
                    requests.post(file_upload_url, files = payload_file, data=payload, verify=False)
                    internal_file_name.close()

                # Updating the Zip File Status
                headers = {
                    "Content-Type": "application/json"
                }
                payload_status = {
                    "file_uploads_id": file_id,
                    "file_status": "Zip Processed",
                    "tenants_id": tenants_id,
                    "groups_id": groups_id,
                    "entities_id": entities_id,
                    "m_processing_layer_id": m_processing_layer_id,
                    "m_processing_sub_layer_id": m_processing_sub_layer_id,
                    "processing_layer_id": processing_layer_id
                }
                data = json.dumps(payload_status)
                requests.get(file_status_url, headers=headers, data=data)

                shutil.rmtree(extract_path)

            return JsonResponse({"Status": "Success"})
    except Exception:
        logger.error("Error in Getting Update ERP Files !!!", exc_info=True)
        return JsonResponse({"Status": "Error"})

def get_processing_layer_id(file):
    try:
        if re.search('AXIS', file) and re.search('18294', file):
            processing_layer_id = 1
        if re.search('AXIS', file) and re.search('35274', file):
            processing_layer_id = 2
        if re.search('FED', file) and re.search('6006', file):
            processing_layer_id = 4
        if re.search('HDFC', file) and re.search('062', file):
            processing_layer_id = 6
        if re.search('HDFC', file) and re.search('828', file):
            processing_layer_id = 7
        if re.search('HDFC', file) and re.search('295', file):
            processing_layer_id = 9
        if re.search('ICICI', file) and re.search('2605', file):
            processing_layer_id = 23
        if re.search('ICICI', file) and re.search('240', file):
            processing_layer_id = 25
        if re.search('IDBI', file) and re.search('1946', file):
            processing_layer_id = 26
        if re.search('INDUS', file) and re.search('974', file):
            processing_layer_id = 27
        if re.search('KOT', file) and re.search('195', file):
            processing_layer_id = 30
        if re.search('KOT', file) and re.search('521', file):
            processing_layer_id = 31
        if re.search('KOT', file) and re.search('019', file):
            processing_layer_id = 32
        if re.search('RBL', file) and re.search('110', file):
            processing_layer_id = 33
        if re.search('SBI', file) and re.search('642', file):
            processing_layer_id = 34
        if re.search('AXIS', file) and re.search('674', file):
            processing_layer_id = 55
        if re.search('FED', file) and re.search('979', file):
            processing_layer_id = 56

        return {"Status": "Success", "processing_layer_id": processing_layer_id}
    except Exception:
        logger.error("Error in Getting Processing Layer Id!!!")
        return JsonResponse({"Status": "Error"})