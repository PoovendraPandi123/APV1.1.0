import logging
import os
import zipfile
from . import read_relationships as rr
import pandas as pd
from datetime import datetime

logger = logging.getLogger("recon_one")

def get_extract_bank_files(zip_file_path):
    try:
        extract_path = zip_file_path.split("input/")[0] + "extract"

        if not os.path.exists(extract_path):
            os.mkdir(extract_path)

            with zipfile.ZipFile(zip_file_path, 'r') as zip_file:
                zip_file.extractall(extract_path)

            return {"Status": "Success", "path": extract_path}
        else:
            return {"Status": "Exists"}
    except Exception:
        logger.error("Error in Getting Extract Bank Files!!!", exc_info=True)
        return "Error"

def get_proper_date(number):
    '''
    Taking 8 numbers as an input and convert that number to proper date format
    :param self:
    :return:
    '''
    try:
        inp_number = number
        input_number_split = str(inp_number).split(".")[0]
        proper_date = input_number_split[0:4] + "-" + input_number_split[4:6] + "-" + input_number_split[6:8] + " 00:00:00"
        return proper_date
    except Exception as e:
        logger.error("Error in Converting proper date", exc_info=True)
        logger.error(str(e))

def store_erp_file(data_frame, accpac_code_column, accpac_code, erp_file_path, erp_file_name):
    """

    :return:
    """
    try:
        filtered_df = data_frame[data_frame[accpac_code_column] == accpac_code]

        if len(filtered_df) > 0:
            now = datetime.now().strftime("%d_%m_%Y") #"%d_%m_%Y_%H_%M_%S"
            filtered_df.to_excel(erp_file_path + "/" + erp_file_name + "_" + now  + ".xlsx", header=True, index=False)
        else:
            print("No data available in given file :", erp_file_name)
    except Exception as e:
        logger.info("Error in storing the file", exc_info=True)
        logger.info(str(e))

def get_extract_erp_files(file_path):
    try:
        extract_path = file_path.split("input/")[0] + "extract"

        if not os.path.exists(extract_path):
            os.mkdir(extract_path)

        relationship_reco = rr.Relationships("G:/AdventsProduct/V1.0.0/AFS/Reconciliation/recon/packages/relationships.json", "reco")
        reco_properties = relationship_reco.get_relationship()

        # Reading the excel
        erp_data = pd.read_excel(file_path, skiprows=range(0, 3))

        # Creating a string converter in the form of dictionary to read all the data as string
        data_column_converter = {}
        for column in erp_data.columns:
            data_column_converter[column] = str

        # Reading data with all columns a string
        erp_data_proper = pd.read_excel(file_path, converters=data_column_converter, skiprows=range(0, 3))

        # Changing the proper date format
        erp_data_proper[erp_data_proper.columns[0]] = erp_data_proper[erp_data_proper.columns[0]].apply(get_proper_date)

        # ACCPAC Code Column
        accpac_code_column = erp_data_proper.columns[9]

        processing_layer_ids = [1, 6, 9, 7, 25, 34, 23]

        for processing_layer_id in processing_layer_ids:
            relationship_properties = rr.GetRelationshipProperties(reco_properties, processing_layer_id)
            store_erp_file(erp_data_proper, accpac_code_column, relationship_properties.get_accpac_code(), extract_path, relationship_properties.get_erp_file_name())

        return {"Status": "Success", "path": extract_path}
    except Exception:
        logger.error("Error in Getting Extract ERP Files!!!", exc_info=True)
        return "Error"