# Importing the libraries
import json
import os
import sys
import logging

logger = logging.getLogger("recon_one")

class Relationships:
    relationships = ""

    def __init__(self, relationships_file, module_name):
        try:
            if os.path.exists(relationships_file):
                # print("Reading configuration file for module:", module_name)
                self.read_config(relationships_file, module_name)
        except Exception as e:
            print("Error!!! Config file not found", relationships_file)
            logger.error("Error in Config file not found!!!")
            sys.exit()

    def read_config(self, relationships_file, module_name):
        try:
            with open(relationships_file, "r") as f:
                config_items = json.load(f)

            for k, v in config_items.items():
                if k == module_name:
                    module = v

                for k, v in module.items():
                    if k == "relationships":
                        self.relationships = v

        except Exception as e:
            logger.error("Error in Read Config!!!")

    def get_relationship(self):
        return self.relationships

class GetRelationshipProperties:

    accpac_code = ""
    erp_file_name = ""

    def __init__(self, relationships, processingLayerId):
        try:
            for properties in relationships:
                if properties["processingLayerId"] == processingLayerId:
                    credentials = properties["credentials"]
                    self.accpac_code = credentials["accpacCode"]
                    self.erp_file_name = credentials["erpFileName"]

        except Exception as e:
            logger.error("Error in Get Relationships", exc_info=True)
            sys.exit()

    def get_accpac_code(self):
        return self.accpac_code

    def get_erp_file_name(self):
        return self.erp_file_name