import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { BusinesslogiclayerdefinitionService } from '../service/businesslogiclayerdefinition.service';
import { HttpClient  } from '@angular/common/http';
declare const $: any;

@Component({
  selector: 'app-business-logic-layer-definition',
  templateUrl: './business-logic-layer-definition.component.html',
  styleUrls: ['./business-logic-layer-definition.component.css']
})
export class BusinessLogicLayerDefinitionComponent implements OnInit {

  public cardTitle;
  public businesslayerview;
  public processinglayerdata;
  public processinglayerlist;
  public objbusinesslayer;
  public businesslayerlist;
  public rulesetdata;
  public rulesetlist;
  public ruletypelist;
  public rulenamedata;
  public rulenamelist;
  public rulenamelistdata;
  public userdtl;
  public user;
  public doc;
  public newdoc;
  public businesslayermainlist;
  public internallist;
  public externallist

   constructor(private router: Router,private objservice:BusinesslogiclayerdefinitionService,public http:HttpClient) { }


  ngOnInit(): void {

    this.userdtl=JSON.parse(localStorage.getItem('useracess'));
    this.user=JSON.parse(localStorage.getItem('Userdtl'));
    console.log("userdtl",this.user);
    this.businesslayerview=false;
    this.businesslayerlist=[];
    this.objbusinesslayer={"processing_layer_id":0,"rule_set_id":0,"rule_id":0};
    this.newdoc={"factor_type":"","internal_field":0,"external_field":0,"condition":"","date_tolerance":"","amount_tolerance":""};
    this.getbusinesslayer();

  }

  getbusinesslayer(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      }
    console.log("inputbusiness",Indata);
    this.objservice.getbusinesslayerFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourcelistresponse---",tempresponsedata)
      this.processinglayerdata=tempresponsedata;
      this.processinglayerlist=this.processinglayerdata.Data;
     
         });
  }

  list(){
    this.businesslayerview=true;

  }
  backlist(){
    this.businesslayerview=false;

  }

  addFieldValue(data?) {
    
    this.businesslayerlist.push(this.newdoc);
    let getLength = this.businesslayerlist.length - 1;    
    this.newdoc={"factor_type":"","internal_field":0,"external_field":0,"condition":"","date_tolerance":"","amount_tolerance":""};


  }

  deleteFieldValue(index) {
    this.businesslayerlist.splice(index, 1);
    // this.costVendorTypeArray.splice(index, 1);    
  }			
 

  clearbusinesslayerFields(){
    this.newdoc={"factor_type":"","internal_field":0,"external_field":0,"condition":"","date_tolerance":"","amount_tolerance":""};


  }

  cancelEdit(){

  }


  getruleset(param){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "processing_id": param,

      }
    console.log("inputruleset",Indata);
    this.objservice.getbusinessrulesetFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("rulesetlistresponse---",tempresponsedata)
      this.rulesetdata=tempresponsedata;
      this.rulesetlist=this.rulesetdata.Data;
     
         });

  }
  
  getrulename(param){

    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "processing_id": this.objbusinesslayer.processing_layer_id,
      "rule_set_id": param,
      }
    console.log("inputrulename",Indata);
    this.objservice.getbusinessrulenameFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("rulenamelistresponse---",tempresponsedata)
      this.rulenamedata=tempresponsedata;
      this.rulenamelistdata=this.rulenamedata.Data[0];
      this.rulenamelist=this.rulenamelistdata.rule_name_list;
      this.internallist=this.rulenamelistdata.int_attributename_list;
      this.externallist=this.rulenamelistdata.ext_attributename_list;


     
         });
  }

  savebusinesslayerdetails(){

    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "processing_layer_id": this.objbusinesslayer.processing_layer_id,
      "rule_set_name_id":  this.objbusinesslayer.rule_set_id,
      "rule_name_id": this.objbusinesslayer.rule_id,
      "bus_lay_def_list":this.businesslayerlist,
      }
    console.log("inputsavebusinesslayerdefinition",Indata);
    this.objservice.getbusinesslayerdefinitionFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("businesslayerdefinitionsaveresponse---",tempresponsedata)
     
         });
         []
  }

  Editbusinesslayerdetail(param){

  }

}
