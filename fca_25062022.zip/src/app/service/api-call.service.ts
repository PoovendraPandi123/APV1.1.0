import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders  } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiCallService {

  static rootUrl: string = environment.host;
  static cdnUrl = environment.cdnhost;

  constructor(private http: HttpClient) { }

  static authRequest(url)
  {
    let headers = {
      'Content-Type': 'application/json'
    };

    let options = {
      headers: headers
    };

    return {
      url : this.cdnUrl + url,
      headers : options
    }
  }

  public SendToAPI(requestType: string, requestDetails: any, payload: any) : any {
    if (requestType.toLowerCase() == "get")
    {
      this.http.get(requestDetails['url'], requestDetails['headers'])
      .subscribe(
        (data : any) => {
          return data
        },
        (error : any) => {
          return error
        }
      )
    }

    else if (requestType.toLocaleLowerCase() == "post")
    {
      this.http.post(requestDetails['url'], payload, requestDetails['headers'])
      .subscribe(
        (data : any) => {
          return data
        },
        (error : any) => {
          console.log("error", error)
          let err = error;
          return err;
        }
      )
    }

  }


}
