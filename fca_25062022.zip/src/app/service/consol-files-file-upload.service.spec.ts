import { TestBed } from '@angular/core/testing';

import { ConsolFilesFileUploadService } from './consol-files-file-upload.service';

describe('ConsolFilesFileUploadService', () => {
  let service: ConsolFilesFileUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ConsolFilesFileUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
