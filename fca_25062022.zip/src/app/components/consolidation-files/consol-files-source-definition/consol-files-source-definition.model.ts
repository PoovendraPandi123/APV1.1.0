export interface ISourceDefinitions {
    fieldName: string;
    position: number;
    dataType: string;
    dateFormat: string;
    minimumLength: number;
    maximumLength: number;
    fieldUnique: string;
}