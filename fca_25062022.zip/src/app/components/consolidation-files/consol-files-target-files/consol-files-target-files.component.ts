import { Component, OnInit } from '@angular/core';
import { ConsolFilesTargetFilesService } from 'src/app/service/consol-files-target-files.service';
import { NgxUiLoaderService } from "ngx-ui-loader"; // Import NgxUiLoaderService
import { ITargetDefinitions } from './consol-files-target-definition.model';

@Component({
  selector: 'app-consol-files-target-files',
  templateUrl: './consol-files-target-files.component.html',
  styleUrls: ['./consol-files-target-files.component.css']
})
export class ConsolFilesTargetFilesComponent implements OnInit {

  public listButton: boolean = true;
  public createButton: boolean = false;
  public createTargetEnable: boolean = false;
  public listTargetEnable: boolean = false;
  public targetName: string;
  public targetDescription: string;
  public pagination: boolean = false;
  public paginationSize: number;
  public targetRowData: any;
  public targetColumnDefs: any;
  public userModelList: any;
  public userDetails: any;
  public tenantId: number;
  public groupId: number;
  public entityId: number;
  public mProcessingLayerId: number;
  public mProcessingSubLayerId: number;
  public processingLayerId: number;
  public userId: any;
  public targetDefRowData: any;
  public targetDefColumnDefs: any;
  public listTargetDefEnable: boolean = false;
  public targetActionType: string;
  public targetClickedData: any;
  public targetNameClicked: string;
  public targetDefButtonVisible: boolean;
  public targetDefinitions: ITargetDefinitions[];
  public isTargetDefinitionsRequired: boolean[];
  public targetDefCreateVisible: boolean;

  constructor(private targetService: ConsolFilesTargetFilesService, private ngxService: NgxUiLoaderService) { 
    this.targetName = '';
    this.targetDescription = '';
    this.paginationSize = null;
    this.targetRowData = [];
    this.targetColumnDefs = [];
    this.targetDefRowData = [];
    this.targetDefColumnDefs = [];
    this.targetActionType = '';
    this.targetClickedData = [];
    this.targetNameClicked = '';
    this.targetDefButtonVisible = false;
    this.targetDefinitions = [];
    this.isTargetDefinitionsRequired = [];
    this.targetDefCreateVisible = false;
  }

  public ngOnInit(): void {
    this.pagination = true;
    this.paginationSize = 10;
    this.userModelList = JSON.parse(sessionStorage.getItem('user_model_list'));
    this.userDetails = JSON.parse(sessionStorage.getItem('user_details'));
    this.userId = this.userDetails["user_id"];
    this.tenantId = this.userModelList["tenant_id"];
    this.groupId = this.userModelList["group_id"];
    this.entityId = this.userModelList["entity_id"];
    this.mProcessingLayerId = this.userModelList["m_processing_layer_id"];
    this.mProcessingSubLayerId = this.userModelList["m_processing_sub_layer_id"];
    this.processingLayerId = 1000;
    this.setTargetColumns();
    this.setTargetDefColumns();
    this.setTargetDefColumns();
    this.getTargetList();
    this.targetDefinitions = [
      {
        fieldName: "",
        fieldPosition: null
      }
    ];
    this.isTargetDefinitionsRequired = [true];
  }

  public setTargetColumns() : void {
    this.targetColumnDefs = [
      {
        headerName: 'Action',
        width: 100,
        template:
        `
        <a>
          <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
        </a>
        <a>
          <i class='fa fa-angle-double-right' data-action-type="target_def" title="Target Definitions" aria-hidden="true"></i>
        </a>
        `
      },
      {headerName: 'Name', field: 'name', sortable: true, filter: true, resizable: true, width: 200},
      {headerName: 'Description', field: 'description', sortable: true, filter: true, resizable: true, width: 400},
    ]
  }

  public setTargetDefColumns() : void {
    this.targetDefColumnDefs = [
      // {
      //   headerName: 'Action',
      //   width: 100,
      //   template:
      //   `
      //   <a>
      //     <i class='far fa-edit' data-action-type="Edit" title="Edit" aria-hidden="true"></i>
      //   </a>
      //   `
      // },
      {headerName: 'Name', field: 'field_name', sortable: true, filter: true, resizable: true, width: 300},
      {headerName: 'Sequence', field: 'field_sequence', sortable: true, filter: true, resizable: true, width: 200},
    ]
  }

  public getTargetList() : void {
    this.targetDefinitions = [];
    this.isTargetDefinitionsRequired = [];
    this.addButtonClick();

    this.targetDefButtonVisible = false;
    this.listButton = true;
    this.createButton = false;
    this.createTargetEnable = false;
    this.listTargetEnable = true;
    this.targetDefCreateVisible = false;

    this.ngxService.start();
    let data = {
      "tenants_id": this.tenantId,
      "groups_id": this.groupId,
      "entities_id": this.entityId,
      "m_processing_layer_id": this.mProcessingLayerId,
      "m_processing_sub_layer_id": this.mProcessingSubLayerId,
      "processing_layer_id": this.processingLayerId,
      "is_active": "yes"
    };

    this.targetService.getTragetListFromServer(data)
    .subscribe(
      (receivedData : any) => {
        let responseData = receivedData;
        console.log("Get Target List Response ", responseData);
        this.targetRowData = responseData;
        this.ngxService.stop();
      }
    ),
    (error : any) => {
      this.HanlerErrorResponse(error);
      this.ngxService.stop();
    }

  }

  public getCreateTarget() : void {
    this.listButton = false;
    this.createButton = true;
    this.createTargetEnable = true;
    this.listTargetEnable = false;
    this.listTargetDefEnable = false;

  }

  public getTargetDefinitionsList() : void {
    this.targetDefButtonVisible = true;
    this.listTargetDefEnable = true;
    // console.log("Clicked Target Row", this.targetClickedData);
    let targetFileDefinitions = this.targetClickedData["target_file_definitions"];
    this.targetNameClicked = this.targetClickedData["name"];
    this.targetDefRowData = targetFileDefinitions;
  }

  public onSaveButtonClick() : void {

  }

  public onClearButtonClick() : void {
    
  }

  public onTargetGridReady(event : any) : void {

  }

  public onTargetRowClicked(e : any) : void {
    if (e.event.target !== undefined) {
      let data = e.data;
      let actionType = e.event.target.getAttribute("data-action-type");
      this.targetActionType = actionType;
      this.targetClickedData = data;
      switch (actionType) {
        case 'target_def':
          return this.getTargetDefinitionsList();
      }
    }
  }

  public onTargetDefGridReady(event : any) : void {

  }

  public onTargetDefRowClicked(e : any) : void {

  }

  public getCreateTargetDefinitions() : void {
    this.targetDefCreateVisible = true;
    this.listButton = false;
    this.createButton = true;
    this.createTargetEnable = false;
    this.listTargetEnable = false;
    this.listTargetDefEnable = false;
  }

  public targetDefinitionsSaveClick() : void {

  }

  public addButtonClick() : void {
    this.isTargetDefinitionsRequired.push(true);
    this.targetDefinitions.push({
      fieldName: "",
      fieldPosition: null
    })
  }

  public deleteTargetDefClick(index: number) : void {
    this.isTargetDefinitionsRequired[index] = false;
  }

  public HanlerErrorResponse(err : any) : void {
    console.log(err);
  }

}
