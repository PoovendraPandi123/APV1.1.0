import { TestBed } from '@angular/core/testing';

import { BrsMonthCloseService } from './brs-month-close.service';

describe('BrsMonthCloseService', () => {
  let service: BrsMonthCloseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BrsMonthCloseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
