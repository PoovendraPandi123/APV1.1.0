import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { TransformationdefinitionService } from '../service/transformationdefinition.service';
import{Transformationdefinition} from './transformationdefinition.model';
import { HttpClient  } from '@angular/common/http';
declare const $: any;

@Component({
  selector: 'app-transformation-definition',
  templateUrl: './transformation-definition.component.html',
  styleUrls: ['./transformation-definition.component.css']
})
export class TransformationDefinitionComponent implements OnInit {

  public objtranformdefinition;
  public transformationdata;
  public transformationlist;
  public aggregatordata;
  public aggregatorlist;
  public transformview;
  public cardTitle="Transfrom Definition"
  public sourcedata;
  public sourcelist;
  public transformdefinitondata;
  public transformdefinitonlist;
  public transformdefinitonlookuplist;
  public newdoc;
  public newdoclookup;
  public transformdefinitionmainlist;
  public userdtl;
  public user;
  public attributes_names;
  public field_extraction_operators;
  public delimiter_operators;
  public custom_operators;
  public transaction_operators;

  constructor(private router: Router,private objservice:TransformationdefinitionService,public http:HttpClient) { }

  ngOnInit(): void {
    this.objtranformdefinition={"tranformdefinition_name":"","transformation_id":0,"aggregator_id":0,"source_id":0}
    this.userdtl=JSON.parse(localStorage.getItem('useracess'));
    this.user=JSON.parse(localStorage.getItem('Userdtl'));
    console.log("userdtl",this.user);
    this.transformdefinitionmainlist= [];
    this.transformdefinitonlist=[];
    // this.transformdefinitonlist=["field_extraction_operators":{"operator_type":[]},"delimiter_operators":{"operator_type":[]},"custom_operators":{"operator_type":[]},"transaction_operators":{"operator_type":[]},];
    this.newdoc={"source_field":0,"pattern_type":"","pattern_extract":"","seperator":"","inp_no":"","transaction_placed":"","transaction_reference":""};
    this.transformdefinitonlookuplist=[];
    this.newdoclookup={"base_source_name":"","base_lookup_field":"","extraction_source":"","extraction_lookup_field":"","extraction_field":""};

    this.transformview=false;
    this.gettransformationlist();
    this.getaggregatorlist();
  }

  list(){
    this.transformview=true;
  
  }
  backlist(){
    this.transformview=false;
  
  }

  addFieldValue(data?) {
    
    this.transformdefinitonlist.push(this.newdoc);
    let getLength = this.transformdefinitonlist.length - 1;    
    this.newdoc={"source_field":0,"pattern_type":"","pattern_extract":"","seperator":"","inp_no":"","transaction_placed":"","transaction_reference":""};

  }

  deleteFieldValue(index) {
    this.transformdefinitonlist.splice(index, 1);
  }			
  cleartransformationdefinitionFields() {
    this.newdoc={"source_field":0,"pattern_type":"","pattern_extract":"","seperator":"","inp_no":"","transaction_placed":"","transaction_reference":""};
    
  }

  addlookupFieldValue(data?) {
    
    this.transformdefinitonlookuplist.push(this.newdoc);
    let getLength = this.transformdefinitonlookuplist.length - 1;    
    this.newdoclookup={"base_source_name":"","base_lookup_field":"","extraction_source":"","extraction_lookup_field":"","extraction_field":""};


  }

  deletelookupFieldValue(index) {
    this.transformdefinitonlookuplist.splice(index, 1);
  }			
  cleartransformationdefinitionlookupFields() {
    this.newdoclookup={"base_source_name":"","base_lookup_field":"","extraction_source":"","extraction_lookup_field":"","extraction_field":""};
   
  }

  gettransformationlist(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,          
    }
    console.log("inputtransformation",Indata);
    this.objservice.gettransformationFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("transformationlistresponse---",tempresponsedata)
      this.transformationdata=tempresponsedata;
      this.transformationlist=this.transformationdata.Data;
     
    });
  }

  getaggregatorlist(){
    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,
      "operation_flag":"AD"              
    }
    console.log("inputaggregator",Indata);
    this.objservice.getaggregatorFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("aggregatorlistresponse---",tempresponsedata)
      this.aggregatordata=tempresponsedata;
      this.aggregatorlist=this.aggregatordata.Data;
    });
  }



  changeagrregator(param){

    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,          
      "operation_flag":"ADSD",
      "aggregator_id": param,
    }
    console.log("inputsource",Indata);
    this.objservice.getsourceFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      console.log("Sourcelistresponse---",tempresponsedata)
      this.sourcedata=tempresponsedata;
      this.sourcelist=this.sourcedata.sources_list;
    });

  }

  changesource(param){

    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,          
      "aggregator_id":this.objtranformdefinition.aggregator_id,
      "transformation_id":this.objtranformdefinition.transformation_id,
      "source_id": param,
    }
    console.log("inputtransformation",Indata);
    this.objservice.gettransformationfieldextractionFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
      this.transformdefinitondata=tempresponsedata;
      this.transformdefinitionmainlist=this.transformdefinitondata.Data;
      console.log("transformdefinitonlistresponse---", this.transformdefinitionmainlist[0])

      this.attributes_names=this.transformdefinitionmainlist[0].attributes_names;
      this.field_extraction_operators=this.transformdefinitionmainlist[1].field_extraction_operators;
      this.delimiter_operators=this.transformdefinitionmainlist[2].delimiter_operators;
      this.custom_operators=this.transformdefinitionmainlist[3].custom_operators;
      this.transaction_operators=this.transformdefinitionmainlist[4].transaction_operators;      
    });
  }

  changepattern(){
    this.newdoc.pattern_extract=this.newdoc.seperator+this.newdoc.inp_no;
  }


  gettransformationdefinitionlist(){

  }


  cancelEdit(){

  }


  savetransformdefinitiondetails(){

    let Indata={
      "tenant_id": 1,
      "group_id": 1,
      "entity_id": 1,
      "user_id": 1,          
      "m_transformation_id":this.objtranformdefinition.transformation_id,
      "transformation_name":this.objtranformdefinition.tranformdefinition_name,
      "m_aggregator_id":this.objtranformdefinition.aggregator_id,
      "m_source_definition_id": this.objtranformdefinition.source_id,
      "trans_field_extract_list": this.transformdefinitonlist,

    }
    console.log("inputtransformationsave",Indata);
    this.objservice.posttransformationdefinitionFromServer(Indata)
    .subscribe(
    recieveddata  => {
      let tempresponsedata = recieveddata;
     console.log("transformdefinitonlistsaveresponse---", tempresponsedata)
         
    });
    
  }


  Edittransformdefinitiondetail(param){

  }

}
